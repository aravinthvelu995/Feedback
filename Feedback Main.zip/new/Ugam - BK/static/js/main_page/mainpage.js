$(document).ready(function () {
var m_names = ['January', 'February', 'March','April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December']
//
//	d = new Date();
//	document.getElementById("month").value = m_names[d.getMonth()]; 
//
    $('#sidebarCollapse').on('click', function () {
        $('#sidebar').toggleClass('active');
    });

    $("#showdropdown").on('click', function () {
        window.location.replace("/logout")
    });
	
	var msg = 0;
	var mseg = "";
	year_1 = new Date().getFullYear();
//	var m_names = ['01', '02', '03','04', '05', '06', '07', '08', '09', '10', '11', '12'];
	var month_1 = m_names[new Date().getMonth()]; 
	month_1= month_1;
	var month = document.querySelector('input[type="month"]');
	month.max = year_1+"-"+month_1
	

	$.ajax({
        type: "GET",
        url: "/calculation_m",
        success: function(results)
        {
                    var answer =JSON.parse(JSON.stringify(results))
					var values=results["result"]
					len =values.length
					var bar_list = ["Error Accepted %", "Error Rejected %", "Error Clent/Spec %", "Suggestion %", "Marker %", "Logic %" , "PM_confimation %", "CS %"]
					//var bar_list = ["Error Accepted %", "Error Rejected %", "Error Clent/Spec %", "Suggestion %", "Marker %", "Logic %" , "PM_confimation %", "Clarification Sheet  %"]
					//var bar_list = ["E Accepted %", "E Rejected %", "E Clent/Spec %", "Suggestion %", "Marker %", "Logic %" , "PM_confimation %", "Clarification Sheet %"]
					var dought_list_1 = ["Accepted", "Rejected", "Clent / Spec"]
					var bar_data = [values[0][0]['error_acc'], values[0][1]['error_rej'], values[0][2]['error_cs'], values[0][3]['suggition'], values[0][4]['Marker'], values[0][5]['logic'], values[0][6]['pm'], values[0][7]['client']]
					var error_doughnut = [values[1][0]['error_acc_rating'], values[1][1]['error_rej_rating'], values[1][2]['error_cs_rating']]
					var suggestion_doughnut = [values[2][0]["suggition_acc_rating"], values[2][1]["suggition_rej_rating"], values[2][2]["suggition_cs_rating"]]
					var Marker_doughnut_ = [values[3][0]["Marker_acc_rating"], values[3][1]["Marker_rej_rating"], values[3][2]["Marker_cs_rating"]]
					var Logic_doughnut = [values[4][0]["logic_acc_rating"], values[4][1]["logic_rej_rating"], values[4][2]["logic_cs_rating"]]
					var PM_confimation_doughnut =[values[5][0]["pm_acc_rating"], values[5][1]["pm_rej_rating"], values[5][2]["pm_cs_rating"]]
					var Clarification_sheet_doughnut = [values[6][0]["client_acc_rating"], values[6][1]["client_rej_rating"], values[6][2]["client_cs_rating"]]
					len =values.length
			//console.log(values[0][8]['open'])
			if (values[0][0]['error_acc']>=75)
			{
				swal ( "Your Error Accepeted is " +values[0][0]['error_acc']+'% in'+ 'Year : '+year_1 , "you have " + values[0][8]['open']+ " number open queries", "success" )
				//swal ( 'Your '+year_1+' Error Accepeted was '+values[0][0]['error_acc']+'% .' ,  "success" )
			}
			else if (values[0][0]['error_acc']>=50)
			{
				swal ( "Your Error Accepeted is " +values[0][0]['error_acc']+'% in'+ 'Year : '+year_1, "you have " + values[0][8]['open']+ " number open queries", "info" )
				//swal ( 'Your '+year_1+' Error Accepeted was '+values[0][0]['error_acc']+'% .' ,  "info" )
			}
			else
			{
				swal ( "Your Error Accepeted is " +values[0][0]['error_acc']+'% in'+ 'Year : '+year_1, "you have " + values[0][8]['open']+ " number open queries", "error" )
			}

				Chart.defaults.scale.gridLines.display = false;
            new Chart(document.getElementById("Overall"), {
            type: 'bar', //doughnut, bar, polarArea, pie, radar,line
            data: {
            labels: bar_list,
            datasets: [
                {
                backgroundColor: ['#282364', '#c8200e', '#0073c8', '#d97609', '#918aaa', '#28aae1', '#f05f23', '#bfbfbf'],
                data: bar_data
                }
            ]
            },
            options: {
            legend: { display: true },
            title: {
                display: true,
                text: 'Over All %'
            }
            }
        });

		 Error = new Chart(document.getElementById("Error"), {
                type: 'doughnut',
                data: {
                        labels: dought_list_1,
                datasets: [{                    
                    backgroundColor: ["#282364", "#f03723","#f5911e"],
                    data: error_doughnut  
                    }]
                },
                options: {
                    title: {
                    display: true,
                    text: 'Error %'
                    }
                }
            });

		new Chart(document.getElementById("suggestion"), {
                type: 'doughnut',
                data: {
                        labels: dought_list_1,
                datasets: [{                    
                    backgroundColor: ["#282364", "#f03723","#f5911e"],
                    data: suggestion_doughnut
                    }]
                },
                options: {
                    title: {
                    display: true,
                    text:'Suggestion %'
                    }
                }
            });

		new Chart(document.getElementById("Marker"), {
                type: 'doughnut',
                data: {
                        labels: dought_list_1,
                datasets: [{                    
                    backgroundColor: ["#282364", "#f03723","#f5911e"],
                    data: Marker_doughnut_
                    }]
                },
                options: {
                    title: {
                    display: true,
                    text:'Marker %'
                    }
                }
            });

			new Chart(document.getElementById("Q_logic"), {
                type: 'doughnut',
                data: {
                        labels: dought_list_1,
                datasets: [{                    
                    backgroundColor: ["#282364", "#f03723","#f5911e"],
                    data: Logic_doughnut
                    }]
                },
                options: {
                    title: {
                    display: true,
                    text:'Logic %'
                    }
                }
            });

			new Chart(document.getElementById("PM"), {
				type: 'doughnut',
				data: {
					labels: dought_list_1,
					datasets: [{
						backgroundColor: ["#282364", "#f03723","#f5911e"],
						data: PM_confimation_doughnut
					}]
				},
				options: {
					title: {
						display: true,
						text:'PM %'
					}
				}
				});

				new Chart(document.getElementById("client"), {
                type: 'doughnut',
                data: {
					labels: dought_list_1,
					datasets: [{
						label: "Population (millions)",
						backgroundColor: ["#282364", "#f03723","#f5911e"],
						data: Clarification_sheet_doughnut
					}]
				},
                options: {
                    title: {
						display: true,
						text:'Clarification Sheet %'
                    }
                }
			});
        },
        error: function (jqXHR, exception) {
					if (jqXHR.status === 0) {
						mseg = 'Not connect.\n Verify Network.';
					} else if (jqXHR.status == 404) {
						mseg = 'Requested page not found. [404]';
					} else if (jqXHR.status == 500) {
						mseg = 'please select valite month';
					} else if (exception === 'parsererror') {
						mseg = 'Requested JSON parse failed.';
					} else if (exception === 'timeout') {
						mseg = 'Time out error.';
					} else if (exception === 'abort') {
						mseg = 'Ajax request aborted.';
					} else {
						mseg = 'Uncaught Error.\n' + jqXHR.responseText;
					}
					
				}
    });

	$('#submit').on('click',function(){
		document.getElementById("month_1").innerHTML = "";
		var month = document.getElementById("month").value;
		//console.log(month);
		var obj={"month":$("#month").val()};
		//console.log("month "+month);
		var lastItem = month.split("-")
		var dat = 0
			dat = Number(lastItem[1] - 1)
			var month
			month = m_names[dat]; 
		//console.log(dat);
		if (month!==""){
		//	console.log("month "+month +"Teast1- " +obj);
			$.ajax({
                type:'post',
                url:'/calculation_m',
                contentType:'application/json',
                data:JSON.stringify(obj),
                dataType:'json',
                success:function(results){  
                    var answer =JSON.parse(JSON.stringify(results))
					var values=results["result"]
					len =values.length
					var bar_list = ["Error Accepted %", "Error Rejected %", "Error Clent / Spec %", "Suggestion %", "Marker %", "Logic %", "PM_confimation %", "Clarification sheet %"]
					var dought_list_1 = ["Accepted", "Rejected", "Clent / Spec"]
					var bar_data = [values[0][0]['error_acc'], values[0][1]['error_rej'], values[0][2]['error_cs'], values[0][3]['suggition'], values[0][4]['Marker'], values[0][5]['logic'], values[0][6]['pm'], values[0][7]['client']]
					var error_doughnut = [values[1][0]['error_acc_rating'], values[1][1]['error_rej_rating'], values[1][2]['error_cs_rating']]
					var suggestion_doughnut = [values[2][0]["suggition_acc_rating"], values[2][1]["suggition_rej_rating"], values[2][2]["suggition_cs_rating"]]
					var Marker_doughnut_ = [values[3][0]["Marker_acc_rating"], values[3][1]["Marker_rej_rating"], values[3][2]["Marker_cs_rating"]]
					var Logic_doughnut = [values[4][0]["logic_acc_rating"], values[4][1]["logic_rej_rating"], values[4][2]["logic_cs_rating"]]
					var PM_confimation_doughnut =[values[5][0]["pm_acc_rating"], values[5][1]["pm_rej_rating"], values[5][2]["pm_cs_rating"]]
					var Clarification_sheet_doughnut = [values[6][0]["client_acc_rating"], values[6][1]["client_rej_rating"], values[6][2]["client_cs_rating"]]
					len =values.length
					$("#Overall").remove();
					$("#Overall_div").append('<canvas id="Overall" ></canvas>')

					new Chart(document.getElementById("Overall"), {
						type: 'bar', 
						data: {
							labels: bar_list,
							datasets: [{
								backgroundColor: ['#282364', '#c8200e', '#0073c8', '#d97609', '#918aaa', '#28aae1', '#f05f23', '#bfbfbf' ],
								data: bar_data  
							}]
						},
						options: {
							legend: { display: true },
							title: {
								display: true,
								text: m_names[dat] + "  %"
							}
						}
					});
					$("#Error").remove();
					$("#Error_div").append('<canvas id="Error" ></canvas>')
					new Chart(document.getElementById("Error"), {
						type: 'doughnut',
						data: {
							labels: dought_list_1,
							datasets: [{
								backgroundColor: ["#282364", "#f03723","#f5911e"],
								data: error_doughnut  
							}]
						},
						options: {
							title: {
								display: true,
								text: 'Error %'
							}
						}
					});	

					$("#suggestion").remove();
					$("#suggestion_div").append('<canvas id="suggestion" ></canvas>')
					new Chart(document.getElementById("suggestion"), {
						type: 'doughnut',
						data: {
							labels: dought_list_1,
							datasets: [{
								backgroundColor: ["#282364", "#f03723","#f5911e"],
								data: suggestion_doughnut
								}]
							},
						options: {
							title: {
								display: true,
								text:'Suggestion %'
							}
						}
					});
					$("#Marker").remove();
					$("#Marker_div").append('<canvas id="Marker" ></canvas>')
					new Chart(document.getElementById("Marker"), {
						type: 'doughnut',
							data: {
								labels: dought_list_1,
								datasets: [{                    
									backgroundColor: ["#282364", "#f03723","#f5911e"],
									data: Marker_doughnut_
								}]
							},
						options: {
							title: {
								display: true,
								text:'Marker %'
							}
						}
					});

					$("#Q_logic").remove();
					$("#Q_logic_div").append('<canvas id="Q_logic" ></canvas>')
					new Chart(document.getElementById("Q_logic"), {
						type: 'doughnut',
						data: {
							labels: dought_list_1,
							datasets: [{                    
								backgroundColor: ["#282364", "#f03723","#f5911e"],
								data: Logic_doughnut
								}]
							},
						options: {
							title: {
								display: true,
								text:'Logic %'
							}
						}
					});

					$("#PM").remove();
					$("#PM_div").append('<canvas id="PM" ></canvas>')
					new Chart(document.getElementById("PM"), {
						type: 'doughnut',
						data: {
							labels: dought_list_1,
							datasets: [{
								backgroundColor: ["#282364", "#f03723","#f5911e"],
								data: PM_confimation_doughnut
							}]
						},
						options: {
							title: {
								display: true,
								text:'PM %'
							}
						}
					});

					$("#client").remove();
					$("#client_div").append('<canvas id="client" ></canvas>')
					new Chart(document.getElementById("client"), {
						type: 'doughnut',
							data: {
								labels: dought_list_1,
								datasets: [{
									label: "Population (millions)",
									backgroundColor: ["#282364", "#f03723","#f5911e"],
									data: Clarification_sheet_doughnut
								}]
							},
						options: {
								title: {
									display: true,
									text:'Clarification Sheet%'
								}
						}
					});
				},
			error: function (jqXHR, exception) {
				var mseg = '';
				if (jqXHR.status === 0) {
					mseg = 'Not connect.\n Verify Network.';
				} else if (jqXHR.status == 404) {
					mseg = 'Requested page not found. [404]';
				} else if (jqXHR.status == 500) {
					mseg = "please check month.";
				} else if (exception === 'parsererror') {
					mseg = 'Requested JSON parse failed.';
				} else if (exception === 'timeout') {
					mseg = 'Time out error.';
				} else if (exception === 'abort') {
					mseg = 'Ajax request aborted.';
				} else {
					mseg = 'Uncaught Error.\n' + jqXHR.responseText;
				}
					alert(mseg);
				}
			});
				
		}	
		else
			{
					window.location.reload("/mainpage");
			}
		});


});