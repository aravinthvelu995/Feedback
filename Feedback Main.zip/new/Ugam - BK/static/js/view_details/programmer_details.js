$(document).ready(function () {

    $('#sidebarCollapse').on('click', function () {
        $('#sidebar').toggleClass('active');
    });
    $("#showdropdown").on('click', function () {
        window.location.replace("/logout_ad")
    });
	
	$.ajax({
				type:"GET",
				url:"/view",
				contentType:"application/json",
				success:function(results){
					var result =JSON.parse(JSON.stringify(results))
						if(result['result']=='Success'){ 
							window.location.replace('/view')
						}
					},
				error: function (jqXHR, exception) {
					if (jqXHR.status === 0) {
						 msg = 'Not connect.\n Verify Network.';
					} else if (jqXHR.status == 404) {
						 msg = 'Requested page not found. [404]';
					} else if (jqXHR.status == 500) {
						 msg = 'Invalite SID';
					} else if (exception === 'parsererror') {
						msg = 'Requested JSON parse failed.';
					} else if (exception === 'timeout') {
						msg = 'Time out error.';
					} else if (exception === 'abort') {
						msg = 'Ajax request aborted.';
					} else {						
						msg = 'Uncaught Error.\n' + jqXHR.responseText;
					}
					
				}
    				});
	
	$("#search").on("click", function() {
                var value = $(this).val();
                   $("#customershowbychitid1 tr").filter(function() {
                   $(this).toggle($(this).text().indexOf(value) > -1)
                });
    });
    
	$('.table tbody').on('click','.btns',function(){
        var currow =$(this).closest('tr');
        var  col1=currow.find('td:eq(0)').text();
        var  col2=currow.find('td:eq(1)').text();
        var  col3=currow.find('td:eq(2)').text();
        var  col4=currow.find('td:eq(3)').text();
        var  col5=currow.find('td:eq(4)').text();

			$("#serial_no").val(col1);
			$("#serial_no").attr("disabled", "disabled");
			$("#u_emp_id").val(col2);
			$("#u_emp_id").attr("disabled", "disabled");
			$("#u_emp_name").val(col3);			
			$("#u_emp_pass").val(col4);
			$("#u_emp_role").val(col5);
		});
    $("#update").on('click',function(){
		var ex = 0;
		var pass = document.getElementById("u_emp_pass");
		console.log("-pass -"+pass)
		if(pass == ""){
			ex = ex +1;
			document.getElementById("p").value = "please enter minimum  4 digit character";
		}
		if (ex == 0)
		{
				var obj={"serial_no":$("#serial_no").val(),
				"u_emp_name":$("#u_emp_name").val(),
				"u_emp_pass":$("#u_emp_pass").val(),
				"u_emp_role":$("#u_emp_role").val()}
				console.log(obj)	  
				$.ajax({
					type:"POST",
					url:"/update_programmer_details",
					contentType:"application/json",
					data:JSON.stringify(obj),
					dataType:"json",
					success:function(results){
						var result =JSON.parse(JSON.stringify(results))
							if(result['result']=='Success'){ 
								window.location.replace('/view')
							}
							else{
								alert(result['result'])
							}
						}
					});
				}
		
	});
        $('.table tbody').on('click','.btnn',function(){
            
            var currow =$(this).closest('tr');
            var  col1=currow.find('td:eq(0)').text();
            $("#serial_no").val(col1);
            
			
        });

        $("#yesDelete").on('click',function(){

            var obj={"serial_no":$("#serial_no").val()};
			console.log(obj);
			$.ajax({
                type:"POST",
                url:"/delete_programmer_details",
                contentType:"application/json",
                data:JSON.stringify(obj),
                dataType:"json",
                success:function(results){
                    var result =JSON.parse(JSON.stringify(results))
                        if(result['result']=='Success'){
                            window.location.replace("/view");
                        }
//                        else{
//                            alert(result['result'])
//                        }
                
                },
                error: function (jqXHR, exception) {
                    var msg = '';
                    if (jqXHR.status === 0) {
                        msg = 'Not connect.\n Verify Network.';
                    } else if (jqXHR.status == 404) {
                        msg = 'Requested page not found. [404]';
                    } else if (jqXHR.status == 500) {
                        msg = 'Internal error';
                    } else if (exception === 'parsererror') {
                        msg = 'Requested JSON parse failed.';
                    } else if (exception === 'timeout') {
                        msg = 'Time out error.';
                    } else if (exception === 'abort') {
                        msg = 'Ajax request aborted.';
                    } else {
                        msg = 'Uncaught Error.\n' + jqXHR.responseText;
                    }
                    alert(msg);
                } 
            });
            
            
        });

               
   
});
