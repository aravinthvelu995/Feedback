$(document).ready(function () {
    $('#sidebarCollapse').on('click', function () {
        $('#sidebar').toggleClass('active');
    });
    $("#showdropdown").on('click', function () {
        window.location.replace("/logout")
    });

$("#Excel_Sheet").click(function () {
	 var project_number = $('#customershowbychitid tr:nth-child(1) td:nth-child(2)').text();
					 $("#datatocsvtable").tableToCSV({
						separator:',',
						newline:'\n',
						 quoteFields:true,
                        filename:$('#customershowbychitid tr:nth-child(1) td:nth-child(2)').text()
                    });
        });

$(window).on("load resize ", function() {
  var scrollWidth = $('.tbl-content').width() - $('.tbl-content table').width();
  $('.tbl-header').css({'padding-right':scrollWidth});
}).resize();

  
});