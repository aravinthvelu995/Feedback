$(document).ready(function () {
	
	$("#SW_RDG").attr("disabled", "disabled");
	$("#QA_RDG").attr("disabled", "disabled");
	var aa=0;
var refiled				= document.getElementById('refiled').checked;
console.log(refiled);
$("#sid").on("keypress", function(){
		
	if ($(this).val().length == 8)
	{
		refiled		= document.getElementById('refiled').checked;
		var qSID= $(this).val();
		if (refiled==true)
		{
			qSID = qSID+"."
			
		}
		
		var obj={"sid":qSID};
		console.log(qSID);
		$.ajax({
                type:'post',
                url:'/RDG_limt',
                contentType:'application/json',
                data:JSON.stringify(obj),
                dataType:'json',
                success:function(results){  
                    var answer =JSON.parse(JSON.stringify(results))
						console.log(results['results'])
						var values = results['results']

						len =values.length
							var list_of_sid  = []
							var list_of_job_no = []
							var	list_of_bu = []
							var list_of_type = []
							var	list_of_rdg_lim = []
							for (i=0;i<len;i++){
								list_of_sid.push(values[i][0])
								list_of_job_no.push(values[i][1])
								list_of_bu.push(values[i][2])
								list_of_type.push(values[i][3])
								list_of_rdg_lim.push(values[i][4])
							}
						var JOB_NO = values[0][1]
						var BU = values[0][2]
						var type =values[0][3]
						var RDG = "RDG1"

						var RDG_limitation =""//values[0][5]+": "+values[0][4]
						var QA_limitation =""//values[0][5]+": "+values[0][6]
						var checked_J = 0
						var checked_B = 0
						var checked_T = 0
						
						for (i=0;i<len;i++ )
						{
							if (i<(len-1)){
							
								if (JOB_NO != values[i+1][1])
								{
									checked_J = checked_J + 1
								}
							}
							if (i<(len-1)){
							
								if (BU !== values[i+1][2])
								{
									checked_B = checked_B +1
								}
							}
							if (i<(len-1)){
							
								if (type != values[i+1][3])
								{
									checked_T = checked_T +1
								}
								
							}
								if (i<(len)){
									
									if (i==0){
										if (values[i][4] !="")
										{
											RDG_limitation = values[i][5] + ":\t"+values[i][4]+"\n"
										}
										if (values[i][6] !=" ")
										{
											
											QA_limitation= values[i][5] + ":\t"+values[i][6]+"\n"
										}
									}
									else
									{
										if (RDG_limitation.indexOf(values[i][5] + ":\t"+values[i][4])<0)
										{
											RDG_limitation = RDG_limitation + " "+values[i][5] + ":\t"+values[i][4]+"\n"
										}
										if (QA_limitation.indexOf(values[i][5] + ":\t"+values[i][6])<0){
											if (values[i][6] != " ")
											{
												QA_limitation= QA_limitation + " "+ values[i][5] + ":\t"+values[i][6]+"\n"
											}
											
										}
									}
										
								}
						}
						if (checked_J >0)
						{
							alert("Please check with sups for Job Number")
						}
						if (checked_B > 0)
						{
							alert("Please check with sups for BU")
						}
						if (checked_T > 0)
						{
							alert("Please check with sups for type")
						}
						document.getElementById("project_number").value = JOB_NO;
						document.getElementById("region").value = BU;
						document.getElementById("project_type").value = type;
						document.getElementById("SW_RDG").value = RDG_limitation;
						document.getElementById("QA_RDG").value = QA_limitation;
					    },
                error: function (jqXHR, exception) {
                    var msg = '';
                        if (jqXHR.status === 0) {
                            msg = 'Not connect.\n Verify Network.';
                        } else if (jqXHR.status == 404) {
                            msg = 'Requested page not found. [404]';
                        } else if (jqXHR.status == 500) {
                            msg = 'SID not in data base.';
                        } else if (exception === 'parsererror') {
                            msg = 'Requested JSON parse failed.';
                        } else if (exception === 'timeout') {
                            msg = 'Time out error.';
                        } else if (exception === 'abort') {
                            msg = 'Ajax request aborted.';
                        } else {
                            msg = 'Uncaught Error.\n' + jqXHR.responseText;
                        }
                        alert(msg);
                    }
                    
                });
	}
	if ($(this).val().length > 8){
		alert("SID should be 8 digit")
	}
	});
	

	$('#q_category').on('change', function (){
										var SV=document.getElementById("q_category").value;
										var Inp;
										Inp="";
										if (SV == "Skip/Logic - Missing data (With filter)"){
												Inp="We see ### respondents are going blank at QXXXxx even though they qualify below condition. (FILTER as per Qre) \n \n  EG: \n  Kindly check. Please see few sample IDs for your reference.";
										}
										if (SV =="Skip/Logic - Missing data (Ask All)"){	
												Inp="We see ### respondents are going blank at QXXXxx even though there is no filter for this question. \n \n  Kindly check. Please see few sample IDs for your reference.";
										}
										if (SV =="Skip/Logic - Extra data"){
												Inp="We see ### respondents are having data at QXXXxx even though they do not qualify to answer this question as per below condition. (Condition as per Qre) \n \n  EG: \n  Kindly check. Please see few sample IDs for your reference.";
										}
										if (SV == "Script/questionaire Mismatch"){
												Inp="We see ### respondents are selecting options which are not qualified. E.g. Respondent.Serial = XXXxx selected option XXXxx however he does not qualify for below condition. \n  (Condition as per Qre) \n  Kindly check. Please see few sample IDs for your reference.";
										}
										if (SV == "Script/questionaire Mismatch (Numeric)"){
												Inp="We see ### respondents having value at this QXXXxx which is out of range. Range should be Min to Max as per condition XXXxx given in Questionnaire. \n  (Condition as per Qre) \n  Kindly check. Please see few sample IDs for your reference.";
										}
										if (SV == "Incorrect Termination - Should have termed"){
												Inp = "We see ### respondents who should terminate at question QXXXxx as per below but are not terminating at this question. \n  (TERM CONDITION as per Qre) \n  EG: \n  Kindly check. Please see few sample IDs for your reference.";
										}
										if (SV == "Incorrect Termination - Should not have termed"){
												Inp = "We see ### respondents who do not qualify below condition are terminating here.\n  (TERM CONDITION as per Qre) \n  EG: \n  Kindly let us know the reason for this? Please see few sample IDs for your reference.";
										}
										if (SV == "Skip/Logic - Missing data (OE)"){
												Inp = "a. We see ### respondents going blank here even though there is no filter. \n  b. We see ### respondents going blank here even  though they qualify specific condition. \n  (Condition as per Qre) \n  Kindly check. Please see few sample IDs for your reference.";
										}
										if (SV == "Quota - extra data"){
												Inp = "We see ### respondents who do not qualify in Cell XXXxx of this quota but still are getting marked in that cell. Could you please let us know the reason for this? \n  Ex: Give 1 e.g. with cell logic. Please see few sample IDs for your reference.";
										}
										if (SV == "Quota - missing data"){
												Inp = "We see ### respondents who qualify in Cell XXXxx of this quota but still are not getting marked in that cell. Could you please let us know the reason for this? \n  Ex: Give 1 e.g. with cell logic. Please see few sample IDs for your reference.";
										}
										if (SV == "ScreeningTable mismatch"){
												Inp = "We see ### respondents who should terminate at question QXXXxx as per below condition but are terminating at question QYY. Could you please let us know the reason for this? \n  TERM CONDITION. Please see few sample IDs for your reference.";
										}
										if (SV == "Quota - Overquota"){
												Inp = "We see respondents are qualifying to punch at cell XXXxx of Quota QXXXxx. However, same are marked into OverQuota. \n \n  We checked the target for that cell in OSF is not yet MET. Please see few sample IDs for your reference.";
										}
										if (SV == "Quota - Set to incorrect Cells"){
												Inp = "Respondents have punched into cell XXXxx of quota QXXXxx. However, as per OSF target of that cell has already met. Same should have been punched into OverQuota. Please check. Please see few sample IDs for your reference.";
										}
										if (SV == "Missing Response/Attribute"){
												Inp = "We see this question is having an option XXXxx in Questionnaire but that response is missing in MDD.";
												aa= aa+1;
										}
										if (SV == "Missing questions"){
												Inp = "We see this question is present in Questionnaire but it is missing in MDD.";
												aa= aa+1;
										}
										if (SV == "Visual - Other"){
											aa= aa+1;
										}
										if (SV == "Visual - Randomizatrion"){
												Inp = "We see as per Questionnaire,� responses / attributes needs to be randomized but there is no ran keyword in MDD. \n  Could you please check and confirm; if its randomized?";
												aa= aa+1;
										}
										if (SV == "Standard"){
												Inp = "Questions QXXXxx, QXXXxx, QXXXxx are holding same lists as per Questionnaire but we see separate lists are created in MDD. This is not an issue in this wave however in future if at Q1 1 brand is added then there is a chance of missing that in QXXXxx as QXXXxx is on different page and says to use list of QXXXxx.";
												aa= aa+1;
										}
										if (SV == "Incorrect question type"){
												Inp = "Question Type for this variable is not as per Questionnaire, As per Questionnaire It should be XXXxx but in MDD it is defined as XXXxx.";
												aa= aa+1;
										}
										if (SV == "Incorrect text"){
												Inp = "We see textual mismatch at this question. \n  Text in MDD = paste text in MDD \n  Text in Questionnaire = paste text in Questionnaire";
												aa= aa+1;
										}
										if (SV == "Least fill counts"){
												Inp = "We see least fill / random counts are not matching. There is major difference seen in counts. Please check and confirm it is working fine. \n \n  Ex: Give some e.g. of particular brands.Please see few sample IDs for your reference.";
												aa= aa+1;
										}
										if (SV == "Quota - Null Quota"){
												Inp = "We see ### respondent are not qualifying for any of the quota hence we have Null quota scenario, could you check this. Please see few sample IDs for your reference.";
												aa= aa+1;
										}
										if (SV == "Incorrect Calculation"){
												Inp = "Data at this question is not as per Calculation defined in Questionnaire. As per Questionnaire for Respondent serial XXXxx It should be XXXxx but in data we see value XXXxx. Kindly check. Please see few sample IDs for your reference.";
										}										
										if (SV == "Open End/Other Specify Not Collecting Data"){
												Inp = "We see respondents have selected Other option, however, they are blank in Other Specify text box. Please see few sample IDs for your reference.";
										}
										if (SV == "Storedview - Precode not match"){
												Inp = "We see expected categories does not match with the categories displayed on the link for these Questions. \n \n  EG:Respondent.Serial = XXXxx, this respondent eligible categories are {XXXxx} but in link for this respondent only {XXXxx} are shown. \n \n  Kindly Check. Please see few sample IDs for your reference.";
										}

										if (SV == "Storedview - Question missing"){
												Inp = "We see these questions does not have an item in the StoredViewedCategories. \n \n  Kindly Check. Please see few sample IDs for your reference.";
										}

										if (SV == "Marker - Missing data"){
												Inp = "1.We see marker description is �not clear / no label� . Kindly please update the marker label. \n 2.������ As per the marker description we are using for XXXX, but XXX respondents are going blank. Please let us know whether we are using or not. ";
										}
										if (SV == "Marker - Extra data"){
												Inp = "We see ### respondents are having data at QXXXxx even though they do not qualify to answer this marker  as per below marker label (text as per MDD)";
										}
										document.getElementById('q_description').value = Inp; 
				});

$('#phase').on('click', function (){
	var changes = document.getElementById("phase").value;
	if (changes == "Live")
	{
		document.getElementById("version").value = "Live";
	}
	else{
		document.getElementById("version").value = "RDG1";
	}
});

$('#phase').on('change', function (){
	var changes = document.getElementById("phase").value;
	if (changes == "Live")
	{
		document.getElementById("version").value = "Live";
	}
	else{
		document.getElementById("version").value = "RDG1";
	}
});

 $('#q_category').on('click', function (){
										var SV=document.getElementById("q_category").value;
										var Inp;
										Inp="";
										if (SV == "Skip/Logic - Missing data (With filter)"){
												Inp="We see ### respondents are going blank at QXXXxx even though they qualify below condition. (FILTER as per Qre) \n \n  EG: \n  Kindly check. Please see few sample IDs for your reference.";
										}
										if (SV =="Skip/Logic - Missing data (Ask All)"){	
												Inp="We see ### respondents are going blank at QXXXxx even though there is no filter for this question. \n \n  Kindly check. Please see few sample IDs for your reference.";
										}
										if (SV =="Skip/Logic - Extra data"){
												Inp="We see ### respondents are having data at QXXXxx even though they do not qualify to answer this question as per below condition. (Condition as per Qre) \n \n  EG: \n  Kindly check. Please see few sample IDs for your reference.";
										}
										if (SV == "Script/questionaire Mismatch"){
												Inp="We see ### respondents are selecting options which are not qualified. E.g. Respondent.Serial = XXXxx selected option XXXxx however he does not qualify for below condition. \n  (Condition as per Qre) \n  Kindly check. Please see few sample IDs for your reference.";
										}
										if (SV == "Script/questionaire Mismatch (Numeric)"){
												Inp="We see ### respondents having value at this QXXXxx which is out of range. Range should be Min to Max as per condition XXXxx given in Questionnaire. \n  (Condition as per Qre) \n  Kindly check. Please see few sample IDs for your reference.";
										}
										if (SV == "Incorrect Termination - Should have termed"){
												Inp = "We see ### respondents who should terminate at question QXXXxx as per below but are not terminating at this question. \n  (TERM CONDITION as per Qre) \n  EG: \n  Kindly check. Please see few sample IDs for your reference.";
										}
										if (SV == "Incorrect Termination - Should not have termed"){
												Inp = "We see ### respondents who do not qualify below condition are terminating here.\n  (TERM CONDITION as per Qre) \n  EG: \n  Kindly let us know the reason for this? Please see few sample IDs for your reference.";
										}
										if (SV == "Skip/Logic - Missing data (OE)"){
												Inp = "a. We see ### respondents going blank here even though there is no filter. \n  b. We see ### respondents going blank here even  though they qualify specific condition. \n  (Condition as per Qre) \n  Kindly check. Please see few sample IDs for your reference.";
										}
										if (SV == "Quota - extra data"){
												Inp = "We see ### respondents who do not qualify in Cell XXXxx of this quota but still are getting marked in that cell. Could you please let us know the reason for this? \n  Ex: Give 1 e.g. with cell logic. Please see few sample IDs for your reference.";
										}
										if (SV == "Quota - missing data"){
												Inp = "We see ### respondents who qualify in Cell XXXxx of this quota but still are not getting marked in that cell. Could you please let us know the reason for this? \n  Ex: Give 1 e.g. with cell logic. Please see few sample IDs for your reference.";
										}
										if (SV == "ScreeningTable mismatch"){
												Inp = "We see ### respondents who should terminate at question QXXXxx as per below condition but are terminating at question QYY. Could you please let us know the reason for this? \n  TERM CONDITION. Please see few sample IDs for your reference.";
										}
										if (SV == "Quota - Overquota"){
												Inp = "We see respondents are qualifying to punch at cell XXXxx of Quota QXXXxx. However, same are marked into OverQuota. \n \n  We checked the target for that cell in OSF is not yet MET. Please see few sample IDs for your reference.";
										}
										if (SV == "Quota - Set to incorrect Cells"){
												Inp = "Respondents have punched into cell XXXxx of quota QXXXxx. However, as per OSF target of that cell has already met. Same should have been punched into OverQuota. Please check. Please see few sample IDs for your reference.";
										}
										if (SV == "Missing Response/Attribute"){
												Inp = "We see this question is having an option XXXxx in Questionnaire but that response is missing in MDD.";
												aa= aa+1;
										}
										if (SV == "Missing questions"){
												Inp = "We see this question is present in Questionnaire but it is missing in MDD.";
										}
										if (SV == "Visual - Randomizatrion"){
												Inp = "We see as per Questionnaire, responses / attributes needs to be randomized but there is no ran keyword in MDD. \n  Could you please check and confirm; if its randomized?";
												aa= aa+1;
										}
										if (SV == "Standard"){
												Inp = "Questions QXXXxx, QXXXxx, QXXXxx are holding same lists as per Questionnaire but we see separate lists are created in MDD. This is not an issue in this wave however in future if at Q1 1 brand is added then there is a chance of missing that in QXXXxx as QXXXxx is on different page and says to use list of QXXXxx.";
												aa= aa+1;
										}
										if (SV == "Incorrect question type"){
												Inp = "Question Type for this variable is not as per Questionnaire, As per Questionnaire It should be XXXxx but in MDD it is defined as XXXxx.";
												aa= aa+1;
										}
										if (SV == "Incorrect text"){
												Inp = "We see textual mismatch at this question. \n  Text in MDD = paste text in MDD \n  Text in Questionnaire = paste text in Questionnaire";
												aa= aa+1;
										}
										if (SV == "Least fill counts"){
												Inp = "We see least fill / random counts are not matching. There is major difference seen in counts. Please check and confirm it is working fine. \n \n  Ex: Give some e.g. of particular brands.Please see few sample IDs for your reference.";
												aa= aa+1;
										}
										if (SV == "Quota - Null Quota"){
												Inp = "We see ### respondent are not qualifying for any of the quota hence we have Null quota scenario, could you check this. Please see few sample IDs for your reference.";
												aa= aa+1;
										}
										if (SV == "Incorrect Calculation"){
												Inp = "Data at this question is not as per Calculation defined in Questionnaire. As per Questionnaire for Respondent serial XXXxx It should be XXXxx but in data we see value XXXxx. Kindly check. Please see few sample IDs for your reference.";
												aa= aa+1;
										}										
										if (SV == "Open End/Other Specify Not Collecting Data"){
												Inp = "We see respondents have selected Other option, however, they are blank in Other Specify text box. Please see few sample IDs for your reference.";
										}
										if (SV == "Storedview - Precode not match"){
												Inp = "We see expected categories does not match with the categories displayed on the link for these Questions. \n \n  EG:Respondent.Serial = XXXxx, this respondent eligible categories are {XXXxx} but in link for this respondent only {XXXxx} are shown. \n \n  Kindly Check. Please see few sample IDs for your reference.";
										}
										if (SV == "Storedview - Question missing"){
												Inp = "We see these questions does not have an item in the StoredViewedCategories. \n \n  Kindly Check. Please see few sample IDs for your reference.";
										}
										if (SV == "Marker - Missing data"){
												Inp = "1.������ We see marker description is �not clear / no label� . Kindly please update the marker label. \n 2.������ As per the marker description we are using for XXXX, but XXX respondents are going blank. Please let us know whether we are using or not. ";
										}
										if (SV == "Marker - Extra data"){
												Inp = "We see ### respondents are having data at QXXXxx even though they do not qualify to answer this marker  as per below marker label (text as per MDD)";
										}
										document.getElementById('q_description').value = Inp; 
				});

	$('#sidebarCollapse').on('click', function () {
        $('#sidebar').toggleClass('active');
    });

    $("#showdropdown").on('click', function () {
        window.location.replace("/logout")
    });

    $("#add_query").click(function(){
		var d= 0;
		var qBU				= document.getElementById('region').value;
		 refiled	= document.getElementById('refiled').checked;
		var qType			= document.getElementById('project_type').value;
		var qno				= document.getElementById('q_no').value;
		var qcategory	 	= document.getElementById('q_category').value;
		var qdescription 	= document.getElementById('q_description').value;
		var qsampleid	 	= document.getElementById('sample_id').value;
		var qSID			= document.getElementById('sid').value;		
		var qclarification 		= document.getElementById('clarification').value;
		var P_number 		= document.getElementById('project_number').value;
		var qphase			= document.getElementById('phase').value;
		var qversion		= document.getElementById('version').value;
		var SW			= document.getElementById('SW_RDG1').value;
		var QA			= document.getElementById('QA_RDG1').value;
		var qSWresponsible	= document.getElementById('sw_responsible').value;
		//console.log(refiled);

		document.getElementById('qSID').innerHTML = "";
		document.getElementById('project').innerHTML = "";
		document.getElementById('qBU').innerHTML = "";
		document.getElementById('qType').innerHTML = "";
		document.getElementById('qno').innerHTML = "";
		document.getElementById('qcategory').innerHTML = "";
		document.getElementById('qdescription').innerHTML = "";
		document.getElementById('qsampleid').innerHTML = "";
		document.getElementById('qclarification').innerHTML = "";
//		document.getElementById('qresult').innerHTML = "";
		document.getElementById('RDG_SW').innerHTML = "";
		document.getElementById('qphase').innerHTML = "";
		document.getElementById('qversion').innerHTML = "";
		document.getElementById('RDG_QA').innerHTML = "";
		document.getElementById('qSWresponsible').innerHTML = "";
	var d3 = 0;
		if (qSID.trim() == ""){
			document.getElementById('qSID').innerHTML = "*Please enter SID."
			return true;
			d = d + 1 ; 
		}
		if (qSID.length != 8){
			document.getElementById('qSID').innerHTML = "*SID should be 8 Numeric digits."
			return true;
			d = d + 1 ; 
		}
		
		if (qBU != "APAC"){
			if (P_number.length < 3)
			{
				document.getElementById('qBU').innerHTML = "*Please enter valite Job Name.";
				return true;
			d3 = d3 + 1 ; 
			}
		}
		else if (P_number.trim() == ""){
			document.getElementById('qBU').innerHTML = "*Please select BU.";
			return true;
			if (P_number.length < 10){
				d = d + 1 ;
			}
		}
		if (qBU == "0"){
			document.getElementById('qBU').innerHTML = "*Please select BU.";
			return true;
			d = d + 1 ; 
		}
		
		if (qType == "0"){
			document.getElementById('qType').innerHTML = "*Please select Type.";
			return true;
			d = d + 1 ; 
		}
		if (qphase == "Live")
		{
			document.getElementById('SW_RDG1').value = " ";
			if (qSWresponsible == "0")
			{
				document.getElementById('sw_responsible').value= " ";
			}
			
			console.log("Live");
		}
		else{
			if (SW == ""){
				document.getElementById('RDG_SW').innerHTML = "*Please update RDG Issue Sent by SW(if none please enter NA)**.";
				return true;
				d = d + 1 ; 
			}
			if (qSWresponsible == "0"){
			document.getElementById('qSWresponsible').innerHTML = "*Please enter SW responsible name";
			return true;
			d = d + 1 ; 
		}
		}
		if (QA.trim() == ""){
			QA =" " 
		}
		else{
			QA = QA;
		}
		if (qno.trim() == ""){
			document.getElementById('qno').innerHTML = "*Please enter Q. No.";
			return true;
			d = d + 1 ; 
		}
		if (qcategory == "0"){
			document.getElementById('qcategory').innerHTML = "*Please select category.";
			return true;
			d = d + 1 ; 
		}
		if (qdescription == ""){
			document.getElementById('qdescription').innerHTML = "*Please Explain.";
			return true;
			d = d + 1 ; 
		}
		if (qdescription.indexOf("XXX")>0){
			document.getElementById('qdescription').innerHTML = "*Please update XXXXX.";
			return true;
			d = d + 1 ; 
		}
		if (qdescription.indexOf("QXXX")>0){
		document.getElementById('qdescription').innerHTML = "*Please update QXXX.";
		return true;
		d = d + 1 ; 
		}
		if (qdescription.indexOf("###")>0){
		document.getElementById('qdescription').innerHTML = "*Please update ###.";
		return true;
		d = d + 1 ; 
		}
		if (qdescription.indexOf("xxx")>0){
		document.getElementById('qdescription').innerHTML = "*Please update XXXXX.";
		return true;
		d = d + 1 ; 
		}
		if ((qdescription.indexOf("FILTER as per Qre"))>0){
		document.getElementById('qdescription').innerHTML = "*Please FILTER as per Qre update.";
		return true;
		d = d + 1 ; 
		}
		if ((qdescription.indexOf("Condition as per Qre"))>0){
			document.getElementById('qdescription').innerHTML = "*Please Condition as per Qre.";
			return true;
			d = d + 1 ; 
			}
		
		if (qclarification == "0"){
			document.getElementById('qclarification').innerHTML = "*Please select Classification.";
			return true;
			d = d + 1 ; 
		}
		
//		if (qresult == "0"){
//			document.getElementById('qresult').innerHTML = "*Please select category.";
//			return true;
//			d = d + 1 ; 
//		}
						
		if (qphase == "0"){
			document.getElementById('qphase').innerHTML = "*Please select phase.";
			return true;
			d = d + 1 ; 
		}
		
		if (qversion == "0"){
			document.getElementById('qversion').innerHTML = "*Please select RDG version .";
			return true;
			d = d + 1 ; 
		}
		
		if (aa==0)
		{
			if (qsampleid.trim() == ""){
				document.getElementById('qsampleid').innerHTML = "*Please enter sample respondent serial.";
				return true;
				d = d + 1 ; 
			}
					var d2=0;
					var serial
					var ids
					serial= qsampleid.split(',');
					ids = serial.length;
					if (serial.length<3){
						var check = confirm("Please check only one serial in sum_.")
						d2 =d2 + 1;
						//console.log("1212 D2-"+d2);
						if (check == true){
							d = d +1;
						}
						
					}
			}
		var serial=" "
		if (aa>0)
		{
			serial=$("#sample_id").val();
		}
		else{
			serial = $("#sample_id").val(); 
		}
		if (refiled==true)
		{
			qSID	 = qSID+"."
			P_number = P_number+"_Refield"
		}
		
        if (d == 0) {
            var obj={"sid":qSID,
			"project_number":P_number,
			"region":$("#region").val(), 
			"project_type":$("#project_type").val(),
            "q_no":$("#q_no").val(),
			"q_category":$("#q_category").val(), 
			"q_description":$("#q_description").val(),
            "sample_id":serial,
			"clarification":$("#clarification").val(), 
			"result":"Accepted",
			"phase":$("#phase").val(),
			"rdg_version":$("#version").val(),
			 "SW_RDG1":$("#SW_RDG1").val(),
			 "QA_RDG1":QA,
            "status":"Open",
			"sw_responsible":$("#sw_responsible").val()}
            $.ajax({
                type:'post',
                url:'/add_query',
                contentType:'application/json',
                data:JSON.stringify(obj),
                dataType:'json',
                success:function(results){  
                    var answer =JSON.parse(JSON.stringify(results))
                        if(answer['results']=='Success'){                    
							if (d3 == 0)
							{
								swal ( "Data Inserted Successfully... " ,  'Done.' ,  "success" )
							}
							else {
								swal ( "Data Inserted Successfully... " ,  'Done, please updated once JOB NO recived.' ,  "success" )
							}
							document.getElementById('q_no').value = "";
							document.getElementById('q_category').value = "0";
							document.getElementById('q_description').value = "";
							document.getElementById('sample_id').value = "";
							document.getElementById('clarification').value = "0";
							document.getElementById('result').value = "0";
                        }
                        else{
                            alert(answer['results' ]) 
                        }
                },
                error: function (jqXHR, exception) {
                    var msg = '';
                    if (jqXHR.status === 0) {
                        msg = 'Not connect.\n Verify Network.';
                    } else if (jqXHR.status == 404) {
                        msg = 'Requested page not found. [404]';
                    } else if (jqXHR.status == 500) {
                        msg = 'Internal Server Error [500].';
                    } else if (exception === 'parsererror') {
                        msg = 'Requested JSON parse failed.';
                    } else if (exception === 'timeout') {
                        msg = 'Time out error.';
                    } else if (exception === 'abort') {
                        msg = 'Ajax request aborted.';
                    } else {
                        msg = 'Uncaught Error.\n' + jqXHR.responseText;
                    }
                    alert(msg);
                }
            });
        }
    });

    $("#view_query").click(function(){
        var val="";
        var pl="0";
        var d=0;
        var q_d1= "XXX";
        var q_d2= "QXXX";
        var q_d3= "###";
		var qSID 		 	= document.getElementById('sid').value;
		var qBU				= document.getElementById('region').value;
		var qType			= document.getElementById('project_type').value;
		if (qBU == "0"){
			document.getElementById('qBU').innerHTML = "*Please select BU."
			d = d + 1 ; 
		}
		
		if (qType == "0"){
			document.getElementById('qType').innerHTML = "*Please select Type."
			d = d + 1 ; 
		}
		if (d == 0){
        var obj={"sid":$("#sid").val()}
        $.ajax({
                type:'post',
                url:'/view_details_by_sid',
                contentType:'application/json',
                data:JSON.stringify(obj),
                dataType:'json',
                success:function(results){  
                    var answer =JSON.parse(JSON.stringify(results))
                        localStorage.setItem( 'result', JSON.stringify(answer['result']) );
                        //console.log( JSON.parse( localStorage.getItem( 'result' ) ) );
                        window.location.replace("/view_details")

                    },
                    error: function (jqXHR, exception) {
                        var msg = '';
                        if (jqXHR.status === 0) {
                            msg = 'Not connect.\n Verify Network.';
                        } else if (jqXHR.status == 404) {
                            msg = 'Requested page not found. [404]';
                        } else if (jqXHR.status == 500) {
                            msg = 'Internal Server Error [500].';
                        } else if (exception === 'parsererror') {
                            msg = 'Requested JSON parse failed.';
                        } else if (exception === 'timeout') {
                            msg = 'Time out error.';
                        } else if (exception === 'abort') {
                            msg = 'Ajax request aborted.';
                        } else {
                            msg = 'Uncaught Error.\n' + jqXHR.responseText;
                        }
                        alert(msg);
                    }
                    
                });
		}

    });

});