$(document).ready(function(){
	if(navigator.userAgent.indexOf("Chrome") != -1 )
			{
				a= 1;
			}
		else
		{
			alert('Please use Chrome to view better' );
		}
    $("#reset").click(function(){
        $("#emp_id").val("");
        $("#emp_name").val("");
        $("#emp_phone").val("");
        $("#old_pass").val("");
        $("#emp_pass").val("");
        $("#emp_confirm").val("");
        $("#emp_fvr").val("");
      });

   
    $("#submit").click(function(){
        
		if(navigator.userAgent.indexOf("Chrome") != -1 )
			{
				a= 1;
			}
		else
		{
			alert('Please use Chrome to view better' );
		}
    		var  count = "";
			var s1 = 0;
			var r1 = document.getElementById("emp_id").value;
			var r2 = document.getElementById("emp_name").value;
			var r3 = document.getElementById("emp_phone").value;
			var r4 = document.getElementById("emp_pass").value;
			var r5 = document.getElementById("emp_confirm").value;
			var r6 = document.getElementById("emp_fvr").value;
			var r7 = document.getElementById("old_pass").value;
				  if  (r1 == ""){
						count = "Employee ID -";
					}
				  if  (r2 == ""){
					count = count + " Employee Name -";	
					s1 = s1 +0;
					}
				if  (r3 == ""){
					count = count + "  Mobile Number -";		
					s1 = s1 +0;
					}
				if  (r7 == ""){
					count = count + "  Old Password -";		
					s1 = s1 +0;
					}
				if  (r4 == ""){
					count = count + "  New Password -";		
					s1 = s1 +0;
					}
				if  (r5 == ""){
					count = count + "  Confirm Password -";		
					s1 = s1 +0;
					}
				if  (r6 == ""){
					count = count + "  Favorite -";		
					s1 = s1 +0;
				}
					
				if (s1>0)  {
					alert("PLEASE ENTER" + count);	
				}
	if(s1==0){
			var obj={"emp_id":$("#emp_id").val(),"emp_name":$("#emp_name").val(), "emp_phone":$("#emp_phone").val(),"old_pass":$("#old_pass").val(),"emp_pass":$("#emp_pass").val(),"emp_confirm":$("#emp_confirm").val(),"emp_fvr":$("#emp_fvr").val()};
			console.log(obj);
			$.ajax({
				type:'post',
				url:'/forget',
				contentType:'application/json',
				data:JSON.stringify(obj),
				dataType:'json',
				success:function(results){
					var result =JSON.parse(JSON.stringify(results))
					if(result['result']=='Success'){
						
						window.location.replace("/index");
										  
					}
					else{
						$("#result").html("invalite old password, please check your Team lead or Manager");
					}
				},
				error: function (jqXHR, exception) {
					var msg = '';
					if (jqXHR.status === 0) {
						msg = 'Not connect.\n Verify Network.';
					} else if (jqXHR.status == 404) {
						msg = 'Requested page not found. [404]';
					} else if (jqXHR.status == 500) {
						msg = 'invalite old password, please check your Team lead or Manager.';
					} else if (exception === 'parsererror') {
						msg = 'Requested JSON parse failed.';
					} else if (exception === 'timeout') {
						msg = 'Time out error.';
					} else if (exception === 'abort') {
						msg = 'Ajax request aborted.';
					} else {
						msg = 'Uncaught Error.\n' + jqXHR.responseText;
					}
					alert(msg);
				}

			});
		
		}
    });

    $(document).keypress(function(event){
        var keycode = (event.keyCode ? event.keyCode : event.which);
        if(keycode == '13'){
            $("#submit").click();
        }
    });

});