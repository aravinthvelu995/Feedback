$(document).ready(function(){
	if(navigator.userAgent.indexOf("Chrome") != -1 )
			{
				a= 1;
			}
	else
	{
		alert('Please use Chrome to view better' );
	}

	 $('#sidebarCollapse').on('click', function () {
        $('#sidebar').toggleClass('active');
    });
    $("#showdropdown").on('click', function () {
        window.location.replace("/logout_ad")
    });

    $("#reset").click(function(){
        $("#emp_id").val("");
        $("#emp_name").val("");
        $("#emp_phone").val("");
        $("#emp_pass").val("");
        $("#role").val("0");
      });

   
    $("#add").on('click',function(){
        
		if(navigator.userAgent.indexOf("Chrome") != -1 )
			{
				a= 1;
			}
		else
		{
			alert('Please use Chrome to view better' );
		}
			var  count = "";
			var  s1= 0;
			var  r1 = document.getElementById("emp_id").value;
			var  r2 = document.getElementById("emp_name").value;
			var  r4 = document.getElementById("emp_pass").value;
			var  r5 = document.getElementById("role").value;
			console.log("r1-",r1,"r2 - ",r2,"r4-",r4,"r5-", r5);
			if (r5 == "SW Programmer")
			{
				if (r2 == ""){
						count = count + " Employee Name -";	
						s1 = s1 +1;
						}
				
			}
			else{
				if (r1 == ""){
							count = "Employee ID -";
							s1 = s1 +1;
							console.log("super ra dei",s1);
						}
				if (r2 == ""){
						count = count + " Employee Name -";	
						s1 = s1 +1;
						}
				if (r4 == ""){
						count = count + "  Password -";		
						s1 = s1 +1;
						}
				if (r5 == "0"){
						count = count + "  role -";		
						s1 = s1 +1;
						}
			}
			if (s1>0){
					alert("PLEASE ENTER" + count);	
			}
			
	if(s1==0){
			var obj={"emp_id":$("#emp_id").val(),"emp_name":$("#emp_name").val(),"emp_pass":$("#emp_pass").val(),"role":$("#role").val()};
			console.log(obj);
			$.ajax({
				type:'post',
				url:'/register',
				contentType:'application/json',
				data:JSON.stringify(obj),
				dataType:'json',
				success:function(results){
					var result =JSON.parse(JSON.stringify(results))
					//console.log(result);
					if(result['result']=='Success'){
							
						swal ( "Programmer Added .. " ,  'Done.' ,  "success" )
						$("#emp_id").val("");
						$("#emp_name").val("");
						$("#emp_phone").val("");
						$("#emp_pass").val("");
						$("#role").val("0");
					}
					
				},
				error: function (jqXHR, exception) {
					var msg = '';
					if (jqXHR.status === 0) {
						msg = 'Not connect.\n Verify Network.';
					} else if (jqXHR.status == 404) {
						msg = 'Requested page not found. [404]';
					} else if (jqXHR.status == 500) {
						msg = 'internal error.';
					} else if (exception === 'parsererror') {
						msg = 'Requested JSON parse failed.';
					} else if (exception === 'timeout') {
						msg = 'Time out error.';
					} else if (exception === 'abort') {
						msg = 'Ajax request aborted.';
					} else {
						msg = 'Uncaught Error.\n' + jqXHR.responseText;
					}
					if (msg.length >0)
					{
						alert(msg);
					}
					
				}

			});
		
		}
    });

   
});