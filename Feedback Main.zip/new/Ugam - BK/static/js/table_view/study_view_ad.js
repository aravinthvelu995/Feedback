$(document).ready(function () {
    $('#sidebarCollapse').on('click', function () {
        $('#sidebar').toggleClass('active');
    });
    $("#showdropdown").on('click', function () {
        window.location.replace("/logout")
    });
    
    $("#view_query").click(function(){
		var v3 = document.getElementById("BU").value;
		var v4 = document.getElementById("study_status").value;
		var ee ="";
		if (v3 !="")	{
			ee = ee + 1;

		}
		if (v4 !="")	{
			ee = ee + 1;
		}
		if (ee>0)
		{
				var obj={"BU":v3, "study_status":v4}
				$.ajax({
					type:'post',
					url:'/study_status',
					contentType:'application/json',
					data:JSON.stringify(obj),
					dataType:'json',
					success:function(results){  
						var answer =JSON.parse(JSON.stringify(results))
							localStorage.setItem( 'result', JSON.stringify(answer['result']) );
							window.location.replace("/study_status_view")
						},
						error: function (jqXHR, exception) {
							var msg = '';
							if (jqXHR.status === 0) {
								msg = 'Not connect.\n Verify Network.';
							} else if (jqXHR.status == 404) {
								msg = 'Requested page not found. [404]';
							} else if (jqXHR.status == 500) {
								msg = 'Please check filter.';
							} else if (exception === 'parsererror') {
								msg = 'Requested JSON parse failed.';
							} else if (exception === 'timeout') {
								msg = 'Time out error.';
							} else if (exception === 'abort') {
								msg = 'Ajax request aborted.';
							} else {
								msg = 'Uncaught Error.\n' + jqXHR.responseText;
							}
							alert(msg);
						}
						
					});
			}
			else{
				alert("Please select filtter");
			}
//		   $.ajax({
//				type:'post',
//					url:'/view_details_by_sid',
//					contentType:'application/json',
//					data:JSON.stringify(obj),
//					dataType:'json',
//					success:function(results){  
//					var answer =JSON.parse(JSON.stringify(results))
//					console.log( JSON.parse( localStorage.getItem( 'results' ) ) );
//				if(result['results']=='Success'){
//						
//						window.location.replace("/view_details_by_sid");
//										  
//					}
//					else{
//						$("#result").html("Invalid SID");
//					}    
//				}
//						
//					});

		
    });
});