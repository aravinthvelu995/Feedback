$(document).ready(function () {
    $('#sidebarCollapse').on('click', function () {
        $('#sidebar').toggleClass('active');
    });
    $("#showdropdown").on('click', function () {
        window.location.replace("/logout_ad")
    });
    
    $("#view_query").click(function(){
		var qualify =0;
		var v1 = document.getElementById("sid").value.length;
		var sart = document.getElementById("start").value.length;
		var end = document.getElementById("end").value.length;
		var bu = document.getElementById("region").value;
		console.log(sart);
		console.log(end);
        var d1 = 0;
		if (sart==0 && v1==0 && end==0 && bu=="" )
		{
			alert("please give SID or Date or BU.")
		}
		else 
		{
			if (v1>0)
			{
				if (v1<8)
				{
					alert("SID should be 8 digits.")
					qualify = qualify +1;
					return true;
					d1 = d1 +1;

				}
				
			}
			else if (sart>0)
			{
				if (end == 0)
				{
					alert("Please select end date.")
					qualify = qualify +1;
					return true;
					d1 = d1 +1;
				}
			}
			else if (bu=="0")
			{
				alert ("Please select BU.")
				return true;
				d1 = d1 +1;
			}
			if (d1==0)
			{
				var	obj={"sid":$("#sid").val(), "start":$("#start").val(), "end":$("#end").val(), "region":$("#region").val()};
				console.log(obj);
			$.ajax({
                type:'post',
                url:'/view_details_by_sid_ad',
                contentType:'application/json',
                data:JSON.stringify(obj),
                dataType:'json',
                success:function(results){  
                    var answer =JSON.parse(JSON.stringify(results))
                        localStorage.setItem( 'result', JSON.stringify(answer['result']) );
//                        console.log( JSON.parse( localStorage.getItem( 'result' ) ) );
                        window.location.replace("/view_details_ad")

                    },
                    error: function (jqXHR, exception) {
                        var msg = '';
                        if (jqXHR.status === 0) {
                            msg = 'Not connect.\n Verify Network.';
                        } else if (jqXHR.status == 404) {
                            msg = 'Requested page not found. [404]';
                        } else if (jqXHR.status == 500) {
                            msg = 'please cehck your selection.';
                        } else if (exception === 'parsererror') {
                            msg = 'Requested JSON parse failed.';
                        } else if (exception === 'timeout') {
                            msg = 'Time out error.';
                        } else if (exception === 'abort') {
                            msg = 'Ajax request aborted.';
                        } else {
                            msg = 'Uncaught Error.\n' + jqXHR.responseText;
                        }
                        alert(msg);
                    }
			
			
                    
                });

		}
		
	//	else{
//		   $.ajax({
//				type:'post',
//					url:'/view_details_by_sid',
//					contentType:'application/json',
//					data:JSON.stringify(obj),
//					dataType:'json',
//					success:function(results){  
//					var answer =JSON.parse(JSON.stringify(results))
//					console.log( JSON.parse( localStorage.getItem( 'results' ) ) );
//				if(result['results']=='Success'){
//						
//						window.location.replace("/view_details_by_sid");
//										  
//					}
//					else{
//						$("#result").html("Invalid SID");
//					}    
//				}
//						
//					});
		}
		
    });
});