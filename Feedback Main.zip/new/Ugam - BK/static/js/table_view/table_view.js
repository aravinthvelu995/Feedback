$(document).ready(function () {
    $('#sidebarCollapse').on('click', function () {
        $('#sidebar').toggleClass('active');
    });
    $("#showdropdown").on('click', function () {
        window.location.replace("/logout")
    });
    
    $("#view_query").click(function(){
		var v1 = document.getElementById("sid").value.length;
		var v2 = document.getElementById("sid").value;
		var r = document.getElementById("r").checked;
        
		if (v1 != 8){
			alert("SID should be 8 Digit")
		}
		else{
			
			if (r==true)
			{
				v2 = v2+"."
			}
			var obj={"sid":v2}
			console.log(v2);
			$.ajax({
                type:'post',
                url:'/view_details_by_sid',
                contentType:'application/json',
                data:JSON.stringify(obj),
                dataType:'json',
                success:function(results){  
                    var answer =JSON.parse(JSON.stringify(results))
                        localStorage.setItem( 'result', JSON.stringify(answer['result']) );
                        window.location.replace("/view_details")

                    },
                    error: function (jqXHR, exception) {
                        var msg = '';
                        if (jqXHR.status === 0) {
                            msg = 'Not connect.\n Verify Network.';
                        } else if (jqXHR.status == 404) {
                            msg = 'Requested page not found. [404]';
                        } else if (jqXHR.status == 500) {
                            msg = 'Invalid SID.';
                        } else if (exception === 'parsererror') {
                            msg = 'Requested JSON parse failed.';
                        } else if (exception === 'timeout') {
                            msg = 'Time out error.';
                        } else if (exception === 'abort') {
                            msg = 'Ajax request aborted.';
                        } else {
                            msg = 'Uncaught Error.\n' + jqXHR.responseText;
                        }
                        alert(msg);
                    }
                    
                });
//		   $.ajax({
//				type:'post',
//					url:'/view_details_by_sid',
//					contentType:'application/json',
//					data:JSON.stringify(obj),
//					dataType:'json',
//					success:function(results){  
//					var answer =JSON.parse(JSON.stringify(results))
//					console.log( JSON.parse( localStorage.getItem( 'results' ) ) );
//				if(result['results']=='Success'){
//						
//						window.location.replace("/view_details_by_sid");
//										  
//					}
//					else{
//						$("#result").html("Invalid SID");
//					}    
//				}
//						
//					});
		}
		
    });
});