$(document).ready(function(){
	if(navigator.userAgent.indexOf("Chrome") != -1 )
			{
				a= 1;
			}
		else
		{
			alert('Please use Chrome to view better' );
		}
    $("#reset").click(function(){
        $("#email").val("");
        $("#password").val("");
    });

    $("#submit").click(function(){
        
		if(navigator.userAgent.indexOf("Chrome") != -1 )
			{
				a= 1;
			}
		else
		{
			alert('Please use Chrome to view better' );
		}
		var  count = "";					
					var name = document.getElementById("email").value;
					var msex = document.getElementById("password").value;
				  if  (name == ""){
						count = "- USERNAME ";					 
					}
				  if  (msex == ""){
					count = count + "  PASSWORD -";		
					}
					var s1 =0;
					s1=count.length;
				if (s1>0)  {
				alert("PLEASE ENTER" + count);	
			}
		var obj={"username":$("#email").val(),"password":$("#password").val()}
		if(s1==0){
			$.ajax({
				type:'POST',
				url:'/login',
				contentType:'application/json',
				data:JSON.stringify(obj),
				dataType:'json',
				success:function(results){
					var result =JSON.parse(JSON.stringify(results))
					if(results['result']=='Success'){
						
						window.location.replace("/mainpage_ad");
										  
					}
					else if (results['result']=='SWSuccess')
					{
						window.location.replace("/table_view_AD");
					}
					else{
						$("#result").html("invalite Log in ");
					}
				},
				error: function (jqXHR, exception) {
					var msg = '';
					if (jqXHR.status === 0) {
						msg = 'Not connect.\n Verify Network.';
					} else if (jqXHR.status == 404) {
						msg = 'Requested page not found. [404]';
					} else if (jqXHR.status == 500) {
						msg = 'invalite Log in .';
					} else if (exception === 'parsererror') {
						msg = 'invalite user.';
					} else if (exception === 'timeout') {
						msg = 'Time out error.';
					} else if (exception === 'abort') {
						msg = 'Ajax request aborted.';
					} else {
						msg = 'Uncaught Error.\n' + jqXHR.responseText;
					}
					alert(msg);
				}

			});
		
		}
    });

    $(document).keypress(function(event){
        var keycode = (event.keyCode ? event.keyCode : event.which);
        if(keycode == '13'){
            $("#submit").click();
        }
    });
});