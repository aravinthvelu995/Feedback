$(document).ready(function () {
	
var refiled				= document.getElementById('refiled').checked;
console.log(refiled);
$("#sid").on("keypress", function(){
		
	if ($(this).val().length == 8)
	{
		refiled		= document.getElementById('refiled').checked;
		var qSID= $(this).val();
		if (refiled==true)
		{
			qSID = qSID+"."
			
		}
		
		var obj={"sid":qSID};
		console.log(qSID);
		$.ajax({
                type:'post',
                url:'/RDG_limt',
                contentType:'application/json',
                data:JSON.stringify(obj),
                dataType:'json',
                success:function(results){  
                    var answer =JSON.parse(JSON.stringify(results))
						console.log(results['results'])
						var values = results['results']

						len =values.length
							var list_of_sid  = []
							var list_of_job_no = []
							var	list_of_bu = []
							var list_of_type = []
							var	list_of_rdg_lim = []
							for (i=0;i<len;i++){
								list_of_sid.push(values[i][0])
								list_of_job_no.push(values[i][1])
								list_of_bu.push(values[i][2])
								list_of_type.push(values[i][3])
								list_of_rdg_lim.push(values[i][4])
							}
						var JOB_NO = values[0][1]
						var BU = values[0][2]
						var type =values[0][3]
						var RDG = "RDG1"

						for (i=0;i<len;i++ )
						{
							if (i<(len-1)){
							
								if (JOB_NO != values[i+1][1])
								{
									checked_J = checked_J + 1
								}
							}
							if (i<(len-1)){
							
								if (BU !== values[i+1][2])
								{
									checked_B = checked_B +1
								}
							}
						if (checked_J >0)
						{
							alert("Please check with sups for Job Number")
						}
						if (checked_B > 0)
						{
							alert("Please check with sups for BU")
						}
						document.getElementById("project_number").value = JOB_NO;
						document.getElementById("region").value = BU;
					    },
                error: function (jqXHR, exception) {
                    var msg = '';
                        if (jqXHR.status === 0) {
                            msg = 'Not connect.\n Verify Network.';
                        } else if (jqXHR.status == 404) {
                            msg = 'Requested page not found. [404]';
                        } else if (jqXHR.status == 500) {
                            msg = 'SID not in data base.';
                        } else if (exception === 'parsererror') {
                            msg = 'Requested JSON parse failed.';
                        } else if (exception === 'timeout') {
                            msg = 'Time out error.';
                        } else if (exception === 'abort') {
                            msg = 'Ajax request aborted.';
                        } else {
                            msg = 'Uncaught Error.\n' + jqXHR.responseText;
                        }
                        alert(msg);
                    }
                    
                });
	}
	if ($(this).val().length > 8){
		alert("SID should be 8 digit")
	}
	});

	$('#sidebarCollapse').on('click', function () {
        $('#sidebar').toggleClass('active');
    });

    $("#showdropdown").on('click', function () {
        window.location.replace("/logout")
    });

    $("#add_query").click(function(){
		var d= 0;
		var qBU				= document.getElementById('region').value;
		 refiled	= document.getElementById('refiled').checked;
		var qSID			= document.getElementById('sid').value;		
		var P_number 		= document.getElementById('project_number').value;
		//console.log(refiled);

		document.getElementById('qSID').innerHTML = "";
		document.getElementById('project').innerHTML = "";
		document.getElementById('qBU').innerHTML = "";
	var d3 = 0;
		if (qSID.trim() == ""){
			document.getElementById('qSID').innerHTML = "*Please enter SID."
			return true;
			d = d + 1 ; 
		}
		if (qSID.length != 8){
			document.getElementById('qSID').innerHTML = "*SID should be 8 Numeric digits."
			return true;
			d = d + 1 ; 
		}
		
		
		if (qBU == "0"){
			document.getElementById('qBU').innerHTML = "*Please select BU.";
			return true;
			d = d + 1 ; 
		}

		if (refiled==true)
		{
			qSID	 = qSID+"."
			P_number = P_number+"_Refield"
		}
		
        if (d == 0) {
            var obj={"sid":qSID,
			"project_number":P_number,
			"region":$("#region").val(), 
}
            $.ajax({
                type:'post',
                url:'/add_status',
                contentType:'application/json',
                data:JSON.stringify(obj),
                dataType:'json',
                success:function(results){  
                    var answer =JSON.parse(JSON.stringify(results))
                        if(answer['results']=='Success'){                    
							if (d3 == 0)
							{
								swal ( "Updated Successfully... " ,  'Done.' ,  "success" )
							}
							document.getElementById('q_no').value = "";
							document.getElementById('q_category').value = "0";
							document.getElementById('q_description').value = "";
							document.getElementById('sample_id').value = "";
							document.getElementById('clarification').value = "0";
							document.getElementById('result').value = "0";
                        }
                        else{
                            alert(answer['results' ]) 
                        }
                },
                error: function (jqXHR, exception) {
                    var msg = '';
                    if (jqXHR.status === 0) {
                        msg = 'Not connect.\n Verify Network.';
                    } else if (jqXHR.status == 404) {
                        msg = 'Requested page not found. [404]';
                    } else if (jqXHR.status == 500) {
                        msg = 'Internal Server Error [500].';
                    } else if (exception === 'parsererror') {
                        msg = 'Requested JSON parse failed.';
                    } else if (exception === 'timeout') {
                        msg = 'Time out error.';
                    } else if (exception === 'abort') {
                        msg = 'Ajax request aborted.';
                    } else {
                        msg = 'Uncaught Error.\n' + jqXHR.responseText;
                    }
                    alert(msg);
                }
            });
        }
    });

    $("#view_query").click(function(){
		var qSID 		 	= document.getElementById('sid').value;
		var qBU				= document.getElementById('region').value;
		if (qBU == "0"){
			document.getElementById('qBU').innerHTML = "*Please select BU."
			d = d + 1 ; 
		}

		if (d == 0){
        var obj={"sid":$("#sid").val()}
        $.ajax({
                type:'post',
                url:'/view_details_study_status_by_sid',
                contentType:'application/json',
                data:JSON.stringify(obj),
                dataType:'json',
                success:function(results){  
                    var answer =JSON.parse(JSON.stringify(results))
                        localStorage.setItem( 'result', JSON.stringify(answer['result']) );
                        //console.log( JSON.parse( localStorage.getItem( 'result' ) ) );
                        window.location.replace("/view_details")

                    },
                    error: function (jqXHR, exception) {
                        var msg = '';
                        if (jqXHR.status === 0) {
                            msg = 'Not connect.\n Verify Network.';
                        } else if (jqXHR.status == 404) {
                            msg = 'Requested page not found. [404]';
                        } else if (jqXHR.status == 500) {
                            msg = 'Internal Server Error [500].';
                        } else if (exception === 'parsererror') {
                            msg = 'Requested JSON parse failed.';
                        } else if (exception === 'timeout') {
                            msg = 'Time out error.';
                        } else if (exception === 'abort') {
                            msg = 'Ajax request aborted.';
                        } else {
                            msg = 'Uncaught Error.\n' + jqXHR.responseText;
                        }
                        alert(msg);
                    }
                    
                });
		}

    });

});