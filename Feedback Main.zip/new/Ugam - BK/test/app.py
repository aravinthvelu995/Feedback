from flask import Flask,request,render_template,jsonify,redirect,url_for,session,app
#import mysql.connector
import simplejson as json
import os
#from passlib.hash import sha256_crypt
from functools import wraps
import datetime
import random
from datetime import timedelta
import requests
import csv
#import mysql.connector
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import calendar
import pyodbc

app=Flask(__name__)
app.secret_key = "kl2j343j5#$%#%34534%#$%$%^&**&*^*$%ERTertertert@#$@$frewer$@#$@#$"
app.config['PERMANENT_SESSION_LIFETIME'] =  timedelta(minutes=540)
APP_ROOT=os.path.dirname(os.path.abspath(__file__))


username=""

"Login Page"
@app.route("/ugam_MG_login")
def index():
    return render_template("index.html")

@app.route("/ugam_MG_ad_login")
def index_ad():
    return render_template("index _ad.html")

def login_required(f):
    @wraps(f)
    def wrap(*args, **kwargs):
        if 'logged_in':
            return f(*args, **kwargs)
        else:
            return  render_template("index.html")
    return wrap


@app.route("/logout")
@login_required
def logout():
    session.clear()
    return  render_template("index.html")

@app.route("/register",methods=['post'])
def register():
    try:
        data = request.get_json()
        print(data)
        db = pyodbc.connect(r'Driver={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=C:\Mani\new\Ugam\User.accdb;')
        mycursor=db.cursor()
        #sql = "SELECT * FROM admin WHERE [emp_id]=?"%(emp_id)
        #mycursor.execute(sql)
        #a = mycursor.fetchall()
        #print(a)
        #if a[1] ==emp_id:
        sql='''INSERT INTO admin ([emp_id],[username], [password], [phone],[role]) VALUES (?, ?, ?, ?, ?)'''
        val = (data["emp_id"],data["emp_name"], data["emp_pass"],data["emp_phone"],data["role"])
        mycursor.execute(sql,val)
        db.commit()
        db.close()
    except Exception as e:
        #print(e)
        return jsonify({"results":str(e)})

view_programmer, details=[],[]
@app.route("/programmer_view",methods=['GET'])
def programmer_view():
    try:
        global view_programmer
        #db=mysql.connector.connect(user="root",passwd="",host="localhost",database="mani")
        db = pyodbc.connect(r'Driver={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=C:\Mani\new\Ugam\User.accdb;')
        mycursor=db.cursor()
        #sql="select s_no, date,query_no, query_categories, query_description, serial, clarification, result, explain1, explain2, phase, rdg_version, qa_responsible, status, sw_responsible from query_sheet where sid='%s'"%(data["sid"])
        sql="select * from admin"
		#sql="select [ID], [emp_id],[username], [password],[phone],[role] from admin"
#sql="select * from query_sheet where sid='%s'"%(data["sid"])
        mycursor.execute(sql)
        view_programmer=mycursor.fetchall()
        db.commit()
        db.close()
        return jsonify({"result":details})


    except Exception as e:
        return jsonify({"result":str(e)})

@app.route("/update_programmer_details",methods=['post'])
def update_programmer_details():
    try:
        data=request.get_json()
        print(data)
        db = pyodbc.connect(r'Driver={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=C:\Mani\new\Ugam\User.accdb;')
#db=mysql.connector.connect(user="root",passwd="",host="localhost",database="mani")
        mycursor=db.cursor()
        sql='UPDATE admin SET [password]=?, [phone]=?,[role]=? WHERE [emp_id]=?'
        val =(data["u_emp_pass"],data["u_emp_phone"],data["u_emp_role"],data["u_emp_id"])
        mycursor.execute(sql,val)
        #print(mycursor.execute(sql,val))
        db.commit()
        db.close()
        return jsonify({"result":"Success"});
    except Exception as e:
        return jsonify({"result":str(e)});

@app.route("/delete_programmer_details",methods=["post"])
def delete_programmer_details():
    try:
        data=request.get_json()
        id = ""
        id =data["u_emp_id"]
        print(id)
        db = pyodbc.connect(r'Driver={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=C:\Mani\new\Ugam\QA_Querysheet.accdb;')
#db=mysql.connector.connect(user="root",passwd="",host="localhost",database="mani")
        mycursor=db.cursor()
        sql="DELETE  FROM  admin WHERE  [emp_id]=?"
        val = (data["u_emp_id"])
#        sql="delete from query_sheet where s_no='%s' "%(data["serial_no"])
        mycursor.execute(sql,id)
        db.commit()
        db.close()
        return jsonify({"result":"Success"});
    except Exception as e:
        return jsonify({"result":str(e)})

@app.route("/login", methods=['post'])
def login():
    try:
        global username
        global password
        data=request.get_json()
        print("user data ",data)
        username = data["username"]
        password= data["password"]
        print(username)
        print(password)
        db = pyodbc.connect(r'Driver={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=C:\Mani\new\Ugam\User.accdb;')
        #db = mysql.connector.connect(user='root',passwd='',host='localhost',database='mani')
        mycursor = db.cursor()
        sql ="select username , password from admin where username ='%s'"%(username)
        mycursor.execute(sql)
        a = mycursor.fetchone()
        #if sha256_crypt.verify(data["username"],a[0]) and sha256_crypt.verify(data["password"],a[1])==True:
        if (len(username)>0 and len(password)>0) and (username == a[0] and password==a[1]): 
            session["logged_in"] = True
            session.permanent = True
            session["username"]=username
            return jsonify({"result":"Success"})
        else:
            return jsonify({"result":"Failiure"})
            db.commit()
            db.close()
		  
    except Exception as e:
        return str(e)
def calculation():
    global username
    #print(request.method+"asasas as asa asawe")
    if request.method == "POST":
        data=request.get_json()
        print("data sd - ", data[0])
        c_month = data["month"]
        #c_year  = data["year"]
        c_filter =c_month+"-"+c_year
        #print("c_month -", c_month, "\tc_year-", c_year, "\tc_filter-", c_filter)
    #db = mysql.connector.connect(user='root',passwd='',host='localhost',database='mani')
    db = pyodbc.connect(r'Driver={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=C:\Mani\new\Ugam\QA_Querysheet.accdb;')
    mycursor = db.cursor()
    if request.method == "POST":
        sql ="select phase, clarification, result, status,type from query_sheet where qa_responsible =? and acm=?" %(username, c_filter)
        mycursor.execute(sql)
        print("nallavane")
    if request.method == "GET":
        #sql ="select phase, clarification, result, status,type from query_sheet where qa_responsible ='%s'" %(username)
        sql ="select phase, clarification, result, status,type from query_sheet where qa_responsible =?"
        mycursor.execute(sql,username)
    a = mycursor.fetchall()
    db.commit()
    db.close()
    #print(a)
    error_acc_rating,suggition_acc_rating, Marker_acc_rating, logic_acc_rating, pm_acc_rating, client_acc_rating=0,0,0,0,0,0
    error_rej_rating, suggition_rej_rating,Marker_rej_rating, logic_rej_rating, pm_rej_rating, client_rej_rating=0,0,0,0,0,0
    error_cs_rating, suggition_cs_rating,Marker_cs_rating, logic_cs_rating, pm_cs_rating, client_cs_rating=0,0,0,0,0,0
    
    for i in a:
        #print(i[0],i[1],i[2],i[3],i[4])
        if i[4] == "Ugam" and i[0] == "First link delivery" and i[3] =="Close":
            if i[2] == "Accepted":
                if (i[1]  == "Error"):
                    error_acc_rating = error_acc_rating +1
                if (i[1]  == "Suggestion"):
                    suggition_acc_rating = suggition_acc_rating +1
                if (i[1]  == "Question - Marker"):
                    Marker_acc_rating = Marker_acc_rating +1
                if (i[1]  == "Question - Logical"):
                    logic_acc_rating = logic_acc_rating +1
                if (i[1]  == "PM Confirmation Required"):
                    pm_acc_rating = pm_acc_rating +1
                if (i[1]  == "Clarification sheet point"):
                    client_acc_rating = client_acc_rating +1

            if (i[2] == "Rejected"):
                #print("suppero super adaandk adhbn")
                if (i[1]  == "Error"):
                    #print("suppero super adaandk error")
                    error_rej_rating = error_rej_rating +1
                if (i[1]  == "Suggestion"):
                    #print("suppero super adaandk suggstion")
                    suggition_rej_rating = suggition_rej_rating +1
                if (i[1]  == "Question - Marker"):
                    #print("suppero super adaandk marker")
                    Marker_rej_rating = Marker_rej_rating +1
                    #print("Marker_rej_rating", Marker_rej_rating)
                if (i[1]  == "Question - Logical"):
                    #print("suppero super adaandk logic")
                    logic_rej_rating = logic_rej_rating +1
                if (i[1]  == "PM Confirmation Required"):
                    #print("suppero super adaandk pm")
                    pm_rej_rating = pm_rej_rating +1
                if (i[1]  == "Clarification sheet point"):
                    #print("suppero super adaandk cs")
                    client_rej_rating = client_rej_rating +1

            if (i[2] == "Client / Sep"):
                if (i[1]  == "Error"):
                    error_cs_rating = error_cs_rating +1
                if (i[1]  == "Suggestion"):
                    suggition_cs_rating = suggition_cs_rating +1
                if (i[1]  == "Question - Marker"):
                    Marker_cs_rating = Marker_cs_rating +1
                if (i[1]  == "Question - Logical"):
                    logic_cs_rating = logic_cs_rating +1
                if (i[1]  == "PM Confirmation Required"):
                    pm_cs_rating = pm_cs_rating +1
                if (i[1]  == "Clarification sheet point"):
                    client_cs_rating = client_cs_rating +1
    #print("Error value ",error_rating)
    #print("Suggestion value ",suggition_rating)
    bar_error_rating = error_acc_rating + error_rej_rating + error_cs_rating
    bar_suggition_rating = suggition_acc_rating + suggition_rej_rating + suggition_cs_rating
    bar_Marker_rating = Marker_acc_rating + Marker_rej_rating + Marker_cs_rating
    bar_logic_rating = logic_acc_rating + logic_rej_rating + logic_cs_rating
    bar_pm_rating = pm_acc_rating + pm_rej_rating + pm_cs_rating
    bar_client_rating = client_acc_rating + client_rej_rating + client_cs_rating
    tt = bar_error_rating +  bar_suggition_rating + bar_Marker_rating + bar_logic_rating + bar_pm_rating + bar_client_rating
    #print(tt)
    if tt > 0:
        error_acc = round((error_acc_rating / tt) * 100)
        error_rej = round((error_rej_rating / tt) * 100)
        error_cs = round((error_cs_rating / tt) * 100)
        suggition= round((bar_suggition_rating / tt) * 100)
        Marker = round((bar_Marker_rating / tt) * 100)
        logic = round((bar_logic_rating / tt) * 100)
        pm = round((bar_pm_rating / tt) * 100)
        client = round((bar_client_rating / tt) * 100)
    
    bar_chart = [{'error_acc':error_acc}, {'error_rej':error_rej}, {'error_cs':error_cs},{'suggition':suggition},{'Marker':Marker}, {'logic':logic},{'pm':pm},{'client':client}]
    #print("bar_error_rating - ",bar_error_rating, "\nerror_acc_rating-",error_acc_rating)
    if bar_error_rating>0:
        error_acc_rating     = (error_acc_rating/bar_error_rating) * 100
        error_rej_rating     = (error_rej_rating/bar_error_rating) * 100
        error_cs_rating      = (error_cs_rating/bar_error_rating) * 100
        #print("error_acc_rating",error_acc_rating,"error_rej_rating",error_rej_rating,"error_cs_rating",error_cs_rating)
    if bar_suggition_rating>0:
        suggition_acc_rating     = (suggition_acc_rating  / bar_suggition_rating) * 100
        suggition_rej_rating     = (suggition_rej_rating /  bar_suggition_rating) * 100
        suggition_cs_rating      = (suggition_cs_rating / bar_suggition_rating) * 100
    if bar_Marker_rating>0:
        Marker_acc_rating     = (Marker_acc_rating  / bar_Marker_rating) * 100
        Marker_rej_rating     = (Marker_rej_rating /  bar_Marker_rating) * 100
        Marker_cs_rating      = (Marker_cs_rating / bar_Marker_rating) * 100 
    if bar_logic_rating>0:
        logic_acc_rating     = (logic_acc_rating  / bar_logic_rating) * 100
        logic_rej_rating     = (logic_rej_rating /  bar_logic_rating) * 100
        logic_cs_rating      = (logic_cs_rating / bar_logic_rating) * 100
    if bar_pm_rating>0:
        pm_acc_rating     = (pm_acc_rating  / bar_pm_rating) * 100
        pm_rej_rating     = (pm_rej_rating /  bar_pm_rating) * 100
        pm_cs_rating      = (pm_cs_rating / bar_pm_rating) * 100
    if bar_client_rating>0:
        client_acc_rating     = (client_acc_rating  / bar_client_rating) * 100
        client_rej_rating     = (client_rej_rating /  bar_client_rating) * 100
        client_cs_rating      = (client_cs_rating / bar_client_rating) * 100
        
    error_doughnut    = [{'error_acc_rating':error_acc_rating},{'error_rej_rating':error_rej_rating},{'error_cs_rating':error_cs_rating}]
    sugition_doughnut = [{'suggition_acc_rating':suggition_acc_rating},{'suggition_rej_rating':suggition_rej_rating},{'suggition_cs_rating':suggition_cs_rating}]
    Marker_doughnut   = [{'Marker_acc_rating':Marker_acc_rating},{'Marker_rej_rating':Marker_rej_rating},{'Marker_cs_rating':Marker_cs_rating}]
    logic_doughnut    = [{'logic_acc_rating':logic_acc_rating},{'logic_rej_rating':logic_rej_rating},{'logic_cs_rating':logic_cs_rating}]
    pm_rating         = [{'pm_acc_rating':pm_acc_rating},{'pm_rej_rating':pm_rej_rating},{'pm_cs_rating':pm_cs_rating}]    
    client_doughnut   = [{'client_acc_rating':client_acc_rating},{'client_rej_rating':client_rej_rating},{'client_cs_rating':client_cs_rating}]
    total_result = [bar_chart,error_doughnut,sugition_doughnut, Marker_doughnut, logic_doughnut, pm_rating,client_doughnut]
    #print(error_doughnut)
    return total_result        

@app.route("/mainpage")
def mainpage():
    try:
        if session["logged_in"]:
            return render_template("main_page/mainpage.html")
    except KeyError:    
        return redirect(url_for("index"))



@app.route("/mainpage_ad")
def mainpage_ad():
    try:
        if session["logged_in"]:
            return render_template("query_table/programer_ad.html")
    except KeyError:    
        return redirect(url_for("index_ad"))


@app.route("/view")
def view():
    try:
        if session["logged_in"]:
#            for i in  view_programmer:
#                print("printed -",i)
#            print(view_programmer)
            return render_template("view_details/programmer_details.html",data=view_programmer)

    except KeyError:    
        return redirect(url_for("index_ad"))

@app.route("/mainpage_1",methods=['post'])
def mainpage_1():
    try:

        if session["logged_in"]:
            print("vasa")
            return render_template("main_page/mainpage_post.html")        
    except KeyError:    
        return redirect(url_for("index"))



@app.route("/add_Excel")
def add_Excel():
    try:
        if session["logged_in"]:
            return render_template("add_excel/add_Excel.html")
    except KeyError:
        return redirect(url_for("index"))

@app.route("/bargetJson")
def bargetJson():
    result = calculation()
    a =[{'y':result[0][0]["error_acc"], 'label':"Error Accepted %"},{'y':result[0][1]["error_rej"], 'label':"Error Rejected %"},{'y':result[0][2]["error_cs"], 'label':"Error Clent / Spec"}, {'y':result[0][3]["suggition"], 'label':"Suggition"}, {'y':result[0][4]["Marker"], 'label':"Marker"}, {'y':result[0][5]["logic"], 'label': "Logic"}, {'y':result[0][6]["pm"], 'label':"PM_confimation"}, {'y':result[0][7]["client"], 'label':"Client"}]
    # a =[{'y':123, 'label': "Error"}, {'y':231, 'label': "Suggition"}, {'y': 342, 'label': "Logic"},{'y': 342, 'label': "Client"}]
    return jsonify({"result":a})

@app.route("/bar_getJson")
def bar_getJson():
    result = calculation()
    a =[{'y':result[0][0]["error_acc"], 'label':"Error Accepted %"},{'y':result[0][1]["error_rej"], 'label':"Error Rejected %"},{'y':result[0][2]["error_cs"], 'label':"Error Clent / Spec"}, {'y':result[0][3]["suggition"], 'label':"Suggition"}, {'y':result[0][4]["Marker"], 'label':"Marker"}, {'y':result[0][5]["logic"], 'label': "Logic"}, {'y':result[0][6]["pm"], 'label':"PM_confimation"}, {'y':result[0][7]["client"], 'label':"Client"}]
    # a =[{'y':123, 'label': "Error"}, {'y':231, 'label': "Suggition"}, {'y': 342, 'label': "Logic"},{'y': 342, 'label': "Client"}]
    return jsonify({"result":a})
@app.route("/errorgetJson",methods=['get'])
def errorgetJson():
    result = calculation()
    a =[{'y':result[1][0]["error_acc_rating"], 'label':"Accepted"}, {'y':result[1][1]["error_rej_rating"], 'label': "Rejected"}, {'y':result[1][2]["error_cs_rating"], 'label': "Clent / Spec"}]
    # a =[{'y': 80, 'label': "Accept"}, {'y':100, 'label': "Rejected"}]
    return jsonify({"result":a})

@app.route("/suggitiongetJson",methods=['get'])
def suggitiongetJson():
    result = calculation()
    a =[{'y':result[2][0]["suggition_acc_rating"], 'label':"Accepted"}, {'y':result[2][1]["suggition_rej_rating"], 'label': "Rejected"},{'y':result[2][2]["suggition_cs_rating"], 'label': "Clent / Spec"}]
    # a =[{'y': 80, 'label': "Accept"}, {'y':100, 'label': "Rejected"}]
    return jsonify({"result":a})

@app.route("/markergetJson",methods=['get'])
def markergetJson():
    result = calculation()
    a =[{'y':result[3][0]["Marker_acc_rating"], 'label':"Accepted"}, {'y':result[3][1]["Marker_rej_rating"], 'label': "Rejected"},{'y':result[3][2]["Marker_cs_rating"], 'label' : "Clent / Spec"}]
    # a =[{'y': 80, 'label': "Accept"}, {'y':100, 'label': "Rejected"}]
    return jsonify({"result":a})

@app.route("/logicgetJson",methods=['get'])
def logicgetJson():
    result = calculation()
    a =[{'y':result[4][0]["logic_acc_rating"], 'label':"Accepted"}, {'y':result[4][1]["logic_rej_rating"], 'label': "Rejected"},{'y':result[4][2]["logic_cs_rating"], 'label' : "Clent / Spec"}]
    # a =[{'y': 80, 'label': "Accept"}, {'y':100, 'label': "Rejected"}]
    return jsonify({"result":a})

@app.route("/pm_getJson",methods=['get'])
def pm_getJson():
    result = calculation()
    a =[{'y':result[5][0]["pm_acc_rating"], 'label':"Accepted"}, {'y':result[5][1]["pm_rej_rating"], 'label': "Rejected"},{'y':result[5][2]["pm_cs_rating"], 'label' : "Clent / Spec"}]
    # a =[{'y': 80, 'label': "Accept"}, {'y':100, 'label': "Rejected"}]
    return jsonify({"result":a})


@app.route("/clientgetJson",methods=['get'])
def clientgetJson():
    result = calculation()
    a =[{'y':result[6][0]["client_acc_rating"], 'label':"Accepted"}, {'y':result[6][1]["client_rej_rating"], 'label':"Rejected"},{'y':result[6][2]["client_cs_rating"], 'label' : "Clent / Spec"}]
    # a =[{'y': 80, 'label': "Accept"}, {'y':100, 'label': "Rejected"}]
    return jsonify({"result":a})

@app.route("/table_view" )
def table_view():
    try:
        if session["logged_in"]:
            return render_template("table_view/table_view.html")
    except KeyError:
        return redirect(url_for("index"))

@app.route("/create_api")
def create_api():
    try:
        if session["logged_in"]:
            return render_template("createapi.html")
    except KeyError:
        return redirect(url_for("index"))


@app.route("/query_table")
def quer_table():
    try:
        if session["logged_in"]:
            return render_template("query_table/query_table.html")
    except KeyError:
            return redirect(url_for("index"))


@app.route("/add_query", methods=['post'])
def add_query():
    try:
        global username
        #print(username)
        data=request.get_json()
        db = pyodbc.connect(r'Driver={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=C:\Mani\new\Ugam\QA_Querysheet.accdb;')
        #db=mysql.connector.connect(user="root",passwd="",host="localhost",database="mani")
        mycursor=db.cursor()
        date = datetime.datetime.now()
        year  = date.year
        month = date.month
        for month_idx in range(1, 13):
            if month_idx == month:
            #print (calendar.month_name[month_idx])
                month = calendar.month_abbr[month_idx]
        acm = str(month)+"-"+str(year)
        #print(date)
        sql = "INSERT INTO query_sheet ([sid], [region], [type], [date],[query_no], [query_categories], [query_description], [serial], [clarification],[result],[explain1],[phase],[rdg_version], [qa_responsible], [status], [sw_responsible], [acm]) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
	#sql = "INSERT INTO query_sheet (sid, region, type, date,query_no, query_categories, query_description, serial, clarification, result, explain1, phase, rdg_version, qa_responsible, status, sw_responsible, acm) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"
        val=(data["sid"],data["region"],data["project_type"], date,data["q_no"],data["q_category"],data["q_description"],data["sample_id"],data["clarification"],data["result"], " " ,data["phase"],data["rdg_version"],username,data["status"],data["sw_responsible"],acm)
        mycursor.execute(sql,val)
        db.commit()
        db.close()
        return jsonify({"results":"Success"})
    except Exception as e:
        print(e)
        return jsonify({"results":str(e)})


details=[]
@app.route("/view_details_by_sid", methods=['post'])
def view_details_by_sid():
    try:
        global username
        #print(username)
        global details
        # details=request.args.get('user')  < Get query Parameter using> 
        data=request.get_json()
        #db=mysql.connector.connect(user="root",passwd="",host="localhost",database="mani")
        db = pyodbc.connect(r'Driver={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=C:\Mani\new\Ugam\QA_Querysheet.accdb;')
        mycursor=db.cursor()
        #sql="select s_no, date,query_no, query_categories, query_description, serial, clarification, result, explain1, explain2, phase, rdg_version, qa_responsible, status, sw_responsible from query_sheet where sid='%s'"%(data["sid"])
        sql="select * from query_sheet where [sid]=?"
        val = data["sid"]
#sql="select * from query_sheet where sid='%s'"%(data["sid"])
        mycursor.execute(sql,val)
        details=mycursor.fetchall()
        db.commit()
        db.close()
        #print(details)
        if len(details)>0:
            return jsonify({"result":details})
        
        
    except Exception as e:
        return jsonify({"result":str(e)})


details=[]
@app.route("/QA_Query_details/<int:sid>")
def get_details_by_sid(sid):
    try:
        global details
        #print(sid)
        # details=request.args.get('user')  < Get query Parameter using>
        #db=mysql.connector.connect(user="root",passwd="",host="localhost",database="mani")
        db = pyodbc.connect(r'Driver={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=C:\Mani\new\Ugam\QA_Querysheet.accdb;')
        mycursor=db.cursor()
        sql="select * from query_sheet where sid=?"
#sql="select * from query_sheet where sid='%s'"%(sid)
        mycursor.execute(sql,str(sid))
        details=mycursor.fetchall()
        #print(details)
        return render_template("api_show_html_table/api_show_html_table.html",data=details)
        
    except Exception as e:
        return jsonify({"result":str(e)})


@app.route("/view_details")
def view_details():
    try:
        if session["logged_in"]:
#            for i in details:
#                print(i)
            return render_template("view_details/view_details.html",data=details)
    except KeyError:
        return redirect(url_for("index"))
		
@app.route("/viewSW_details")
def viewSW_details():
	try:
		if session["logged_in"]:
			return render_template("view_details/viewSW_details.html",data = details)
	except	keyError:
		return redirect(url_for("index"))



update_sid =""
@app.route("/new_view_details_by_sid")
def new_view_details_by_sid():
    try:
        if session["logged_in"]:
            try:
                global update_sid
                # details=request.args.get('user')  < Get query Parameter using>
                db = pyodbc.connect(r'Driver={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=C:\Mani\new\Ugam\QA_Querysheet.accdb;')
#db=mysql.connector.connect(user="root",passwd="",host="localhost",database="mani")
                mycursor=db.cursor()
                #sql="select s_no, date,query_no, query_categories, query_description, serial, clarification, result, explain1,  phase, rdg_version, qa_responsible, status, sw_responsible from query_sheet where sid='%s'"%(update_sid)
                sql="select * from query_sheet where sid=?"
#sql="select * from query_sheet where sid='%s'"%(update_sid)
                mycursor.execute(sql,update_sid)
                details=mycursor.fetchall()
                return render_template("view_details/view_details.html",data=details)
                
            except Exception as e:
                return jsonify({"result":str(e)})
            
    except KeyError:
        return redirect(url_for("index"))
   

@app.route("/update_query_details",methods=["post"])
def update_query_details():
    try:
        global update_sid
        global username
        data=request.get_json()
        print(data)
        #print(username)
        if len(data["explain2"])>0:
            explain = data["explain1"]+"\n\n("+username+"):\t"+data["explain2"]
        else :
            explain = data["explain1"]
        db = pyodbc.connect(r'Driver={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=C:\Mani\new\Ugam\QA_Querysheet.accdb;')
#db=mysql.connector.connect(user="root",passwd="",host="localhost",database="mani")
        mycursor=db.cursor()
        sql='''UPDATE query_sheet SET  [sid]=?, [query_no]=?, [query_categories]=?, [query_description]=?, [serial]=?,
            [clarification]=?, [result]=?, [explain1]=?,  [phase]=?,
            [rdg_version]=?, [qa_responsible]=?, [status]=?, [sw_responsible]=?
            WHERE [s_no]=?'''
        val =(data["sid"],data["query_no"],data["quert_categories"],data["query_description"],data["serial"],
            data["clarification"],data["result"],explain,data["phase"],
            data["version"],data["responsible"],data["status"],data["sw_responsible"],data["serial_no"])
#        sql='''update query_sheet set  sid='%s', query_no='%s', query_categories='%s', query_description='%s', serial='%s',
#            clarification='%s', result='%s', explain1='%s',  phase='%s',
#            rdg_version='%s', qa_responsible='%s', status='%s', sw_responsible='%s'
#            where s_no="%s" '''%(data["sid"],data["query_no"],data["quert_categories"],data["query_description"],data["serial"],
#            data["clarification"],data["result"],explain,data["phase"],
#            data["version"],data["responsible"],data["status"],data["sw_responsible"],data["serial_no"])
        update_sid=data["sid"]
        mycursor.execute(sql,val)
        #print(mycursor.execute(sql,val))
        db.commit()
        db.close()
        return jsonify({"result":"Success"});
    except Exception as e:
        return jsonify({"result":str(e)});

@app.route("/updateSW_query_details",methods=["post"])
def updateSW_query_details():
    try:
        global update_sid
        data=request.get_json()
        #print(data)
        db = pyodbc.connect(r'Driver={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=C:\Mani\new\Ugam\QA_Querysheet.accdb;')
#db=mysql.connector.connect(user="root",passwd="",host="localhost",database="mani")
        mycursor=db.cursor()
        sql='''update query_sheet set sid= ?, clarification=?, result=?, explain1=?,
             sw_responsible=? where s_no=? '''
        val=(data["sid"],data["clarification"],data["result"],data["explain1"],data["sw_responsible"],data["serial_no"])
#       sql='''update query_sheet set sid= %s, clarification='%s', result='%s', explain1='%s',
#             sw_responsible='%s' where s_no="%s" '''%(data["sid"],data["clarification"],data["result"],data["explain1"],data["sw_responsible"],data["serial_no"])
        update_sid=data["sid"]
        mycursor.execute(sql,val)
        db.commit()
        db.close()
        return jsonify({"result":"Success"});
    except Exception as e:
        return jsonify({"result":str(e)});		

@app.route("/delete_query_details",methods=["post"])
def delete_query_details():
    try:
        data=request.get_json()
        global update_sid
        update_sid =data["sid"]
        #print(update_sid)
        db = pyodbc.connect(r'Driver={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=C:\Mani\new\Ugam\QA_Querysheet.accdb;')
#db=mysql.connector.connect(user="root",passwd="",host="localhost",database="mani")
        mycursor=db.cursor()
        sql="delete from query_sheet where s_no=? "
        val = (data["serial_no"])
#        sql="delete from query_sheet where s_no='%s' "%(data["serial_no"])
        mycursor.execute(sql,val)
        db.commit()
        db.close()
        return jsonify({"result":"Success"});
    except Exception as e:
        return jsonify({"result":str(e)})



if __name__== '__main__':
    app.run(debug=True)
    app.run(port=5000)
    
