$(document).ready(function () {

	 $("#search").on("click", function() {
                var value = $(this).val();
                   $("#customershowbychitid1 tr").filter(function() {
                   $(this).toggle($(this).text().indexOf(value) > -1)
                });
    });
    $('.table tbody').on('click','.btns',function(){
        
		//console.log( JSON.parse( localStorage.getItem( 'result' ) ) );
        var currow =$(this).closest('tr');
		var check = currow.find('td:eq(13)').text(); 
		if (check == "Open")
		{
		var  col1=currow.find('td:eq(0)').text();
        var  col2=currow.find('td:eq(1)').text();
        var  col3=currow.find('td:eq(2)').text();
        var  col4=currow.find('td:eq(3)').text();
        var  col5=currow.find('td:eq(4)').text();
        var  col6=currow.find('td:eq(5)').text();
        var  col7=currow.find('td:eq(6)').text();
        var  col8=currow.find('td:eq(7)').text();
        var  col9=currow.find('td:eq(8)').text();
        var  col10=currow.find('td:eq(9)').text();
        var  col11=currow.find('td:eq(10)').text();
        var  col12=currow.find('td:eq(11)').text();
        var  col13=currow.find('td:eq(12)').text();
        var  col14=currow.find('td:eq(13)').text();
        var  col15=currow.find('td:eq(14)').text();
        var  col16=currow.find('td:eq(15)').text();
        var  col17=currow.find('td:eq(16)').text();
        
        
        //$("#sid").attr("disabled", "disabled"); 
        //$("#project_type").val(col3);
        //$("#project_type").attr("disabled", "disabled"); 
        $("#serial_no").val(col1);
        $("#serial_no").attr("disabled", "disabled"); 
		$("#sid").val(col2);
		$("#sid").attr("disabled", "disabled"); 
        //$("#region").val(col2);
        //$("#date").val(col5);
        //$("#date").attr("disabled", "disabled"); 
        //$("#query_no").val(col6);
        //$("#query_no").attr("disabled", "disabled"); 
        //$("#quert_categories").val(col7);
        //$("#quert_categories").attr("disabled", "disabled"); 
        //$("#query_description").val(col8);
        //$("#query_description").attr("disabled", "disabled");  
        //$("#serial").val(col13);
        //$("#serial").attr("disabled", "disabled");
	    $("#clarification").val(col8);
        $("#clarification").attr("disabled", "disabled"); 
        $("#result").val(col9);
        $("#explain1").val(col10);
		$("#explain1").attr("disabled", "disabled"); 
        //$("#phase").val(col3);
        //$("#phase").attr("disabled", "disabled"); 
        //$("#version").val(col4);
        //$("#version").attr("disabled", "disabled"); 
        //$("#responsible").val(col5);
        //$("#responsible").attr("disabled", "disabled"); 
        //$("#status").val(col6);
        //$("#status").attr("disabled", "disabled"); 
        $("#sw_responsible").val(col15); 
        $("#sw_responsible").attr("disabled", "disabled"); 
		}
    });

    $("#update").on('click',function(){
		var  ex = document.getElementById("explain2").value;
		if (ex == "") {
			document.getElementById('ex').innerHTML = "please enter the responseText";
		}
		if (ex != "")
		{
		
			var exampl1 = ($("#explain1").val()+"\n"+$("#explain2").val())
			var obj={"serial_no":$("#serial_no").val(),
			"sid":$("#sid").val(),
			"clarification" :$("#clarification").val(),
			"result": $("#result").val(),
			"explain1": exampl1,
			"sw_responsible": $("#sw_responsible").val()}
			
			
			$.ajax({
				type:"post",
				url:"/updateSW_query_details",
				contentType:"application/json",
				data:JSON.stringify(obj),
				dataType:"json",
				success:function(results){
					var result =JSON.parse(JSON.stringify(results))
						if(result['result']=='Success'){ 
							window.location.replace('/QA_Query_details/'+obj["sid"])     
							
						}
						else{
							alert(result['result'])
						}
					},
					error: function (jqXHR, exception) {
						var msg = '';
						if (jqXHR.status === 0) {
							msg = 'Not connect.\n Verify Network.';
						} else if (jqXHR.status == 404) {
							msg = 'Requested page not found. [404]';
						} else if (jqXHR.status == 500) {
							msg = 'Please Enter the valite SID.';
						} else if (exception === 'parsererror') {
							msg = 'Requested JSON parse failed.';
						} else if (exception === 'timeout') {
							msg = 'Time out error.';
						} else if (exception === 'abort') {
							msg = 'Ajax request aborted.';
						} else {
							msg = 'Uncaught Error.\n' + jqXHR.responseText;
						}
						alert(msg);
					} 
				});
			}
		});
	});