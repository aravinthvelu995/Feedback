$(document).ready(function(){
	if(navigator.userAgent.indexOf("Chrome") != -1 )
			{
				a= 1;
			}
		else
		{
			alert('Please use Chrome to view better' );
		}
    $("#reset").click(function(){
        $("#username").val("");
        $("#password1").val("");
    });

   
    $("#submit").click(function(){
        
		if(navigator.userAgent.indexOf("Chrome") != -1 )
			{
				a= 1;
			}
		else
		{
			alert('Please use Chrome to view better' );
		}
    $("#reset").click(function(){
        $("#username").val("");
        $("#password1").val("");
    });
		var  count = "";					
					var name = document.getElementById("username").value;
					var msex = document.getElementById("password1").value;
				  if  (name == ""){
						count = "- USERNAME ";					 
					}
				  if  (msex == ""){
					count = count + "  PASSWORD -";		
					}
					var s1 = count.length;
				if (s1>0)  {
				alert("PLEASE ENTER" + count);	
			}
		var obj={"username":$("#username").val(),"password":$("#password1").val()}
		console.log("user data "+obj)
		
		if(s1==0){
			$.ajax({
				type:'post',
				url:'/login',
				contentType:'application/json',
				data:JSON.stringify(obj),
				dataType:'json',
				success:function(results){
					var result =JSON.parse(JSON.stringify(results))
					if(result['result']=='Success'){
						
						window.location.replace("/mainpage_ad");
										  
					}
					else{
						$("#result").html("invalite Log in ");
					}
				},
				error: function (jqXHR, exception) {
					var msg = '';
					if (jqXHR.status === 0) {
						msg = 'Not connect.\n Verify Network.';
					} else if (jqXHR.status == 404) {
						msg = 'Requested page not found. [404]';
					} else if (jqXHR.status == 500) {
						msg = 'invalite Log in .';
					} else if (exception === 'parsererror') {
						msg = 'Requested JSON parse failed.';
					} else if (exception === 'timeout') {
						msg = 'Time out error.';
					} else if (exception === 'abort') {
						msg = 'Ajax request aborted.';
					} else {
						msg = 'Uncaught Error.\n' + jqXHR.responseText;
					}
					alert(msg);
				}

			});
		
		}
    });

    $(document).keypress(function(event){
        var keycode = (event.keyCode ? event.keyCode : event.which);
        if(keycode == '13'){
            $("#submit").click();
        }
    });

});