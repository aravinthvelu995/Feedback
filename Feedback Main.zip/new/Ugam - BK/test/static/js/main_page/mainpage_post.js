$(document).ready(function () {
	var msg = 0;
	var mseg = '';
    $('#sidebarCollapse').on('click', function () {
        $('#sidebar').toggleClass('active');
    });

    $("#showdropdown").on('click', function () {
        window.location.replace("/logout")
    });

$('#year').each(function() {

  var year = (new Date()).getFullYear();
  var current = 2019;
 
  for (var i = 0; i < 3; i++) {
    if ((year+i) == current)
      $(this).append('<option selected value="' + (year + i) + '">' + (year + i) + '</option>');
    else
      $(this).append('<option value="' + (year + i) + '">' + (year + i) + '</option>');
  }

});

$.ajax({
        type: "GET",
        url: "/bar_getJson",
        success: function(result)
        {
            var values=result["result"]
            len =values.length
            var list_of_data= []
            var list_of_label = []
            for (i=0;i<len;i++){
                list_of_label.push(values[i]["label"])
                list_of_data.push(values[i]["y"])
				//console.log(values[i]["label"]+":"+values[i]["y"])

            }
			Chart.defaults.scale.gridLines.display = false;
            new Chart(document.getElementById("Overall"), {
            type: 'line', //doughnut, bar, polarArea, pie, radar,line
            data: {
            labels: list_of_label,
            datasets: [
                {
				backgroundColor : 'rgb(255, 255, 255)',
                //backgroundColor: ["#3e95cd", "#8e5ea2","#3cba9f","#e8c3b9","#c45850","#6c600F","#8e4ea8"],
				borderColor: ['#14d3fd'],
                data: list_of_data  
                }
            ]
            },

			  
            options: {
            legend: { display: true },
            title: {
                display: true,
                text: 'Total %'
            }
            }
        });
        },
        error: function (jqXHR, exception) {
					if (jqXHR.status === 0) {
						msg = 1;
					} else if (jqXHR.status == 404) {
						msg = 2;
					} else if (jqXHR.status == 500) {
						msg = 3;
					} else if (exception === 'parsererror') {
						msg = 4;
					} else if (exception === 'timeout') {
						msg = 5;
					} else if (exception === 'abort') {
						msg = 6;
					} else {
						msg =7;
						mseg = 'Uncaught Error.\n' + jqXHR.responseText;
					}
					
				}
    });          

//    $.ajax({
//        type: "GET",
//        url: "/errorgetJson",
//        success: function(result)
//        {
//            var values=result["result"]
//            len =values.length
//            var list_of_data= []
//            var list_of_label = []
//            for (i=0;i<len;i++){
//                list_of_label.push(values[i]["label"])
//                list_of_data.push(values[i]["y"])
//            }
//            new Chart(document.getElementById("Error"), {
//                type: 'doughnut',
//                data: {
//                        labels: list_of_label,
//                datasets: [{                    
//                    backgroundColor: ["#3e95cd", "#8e5ea2","#3cba9f"],
//                    data: list_of_data  
//                    }]
//                },
//                options: {
//                    title: {
//                    display: true,
//                    text: 'Error %'
//                    }
//                }
//            });
//        },
//        error: function (jqXHR, exception) {
//					if (jqXHR.status === 0) {
//						msg = 1;
//					} else if (jqXHR.status == 404) {
//						msg = 2;
//					} else if (jqXHR.status == 500) {
//						msg = 3;
//					} else if (exception === 'parsererror') {
//						msg = 4;
//					} else if (exception === 'timeout') {
//						msg = 5;
//					} else if (exception === 'abort') {
//						msg = 6;
//					} else {
//						msg =7;
//						mseg = 'Uncaught Error.\n' + jqXHR.responseText;
//					}
//					
//				}
//        
//    });
//
//
//    $.ajax({
//        type: "GET",
//        url: "/suggitiongetJson",
//        success: function(result)
//        {
//            var values=result["result"]
//            len =values.length
//            var list_of_data= []
//            var list_of_label = []
//            for (i=0;i<len;i++){
//                list_of_label.push(values[i]["label"])
//                list_of_data.push(values[i]["y"])
//            }
//            new Chart(document.getElementById("suggestion"), {
//                type: 'pie',
//                data: {
//                        labels: list_of_label,
//                datasets: [{                    
//                    backgroundColor: ["#3e95cd", "#8e5ea2","#3cba9f"],
//                    data: list_of_data
//                    }]
//                },
//                options: {
//                    title: {
//                    display: true,
//                    text:'Suggestion %'
//                    }
//                }
//            });
//        },
//        error: function (jqXHR, exception) {
//					if (jqXHR.status === 0) {
//						msg = 1;
//					} else if (jqXHR.status == 404) {
//						msg = 2;
//					} else if (jqXHR.status == 500) {
//						msg = 3;
//					} else if (exception === 'parsererror') {
//						msg = 4;
//					} else if (exception === 'timeout') {
//						msg = 5;
//					} else if (exception === 'abort') {
//						msg = 6;
//					} else {
//						msg =7;
//						mseg = 'Uncaught Error.\n' + jqXHR.responseText;
//					}
//					
//				}
//    });
//
//
//    $.ajax({
//        type: "GET",
//        url: "/markergetJson",
//        success: function(result)
//        {
//            var values=result["result"]
//            len =values.length
//            var list_of_data= []
//            var list_of_label = []
//            for (i=0;i<len;i++){
//                list_of_label.push(values[i]["label"])
//                list_of_data.push(values[i]["y"])
//				
//            }
//            new Chart(document.getElementById("Marker"), {
//                type: 'pie',
//                data: {
//                        labels: list_of_label,
//                datasets: [{                    
//                    backgroundColor: ["#3e95cd", "#8e5ea2","#3cba9f"],
//                    data: list_of_data
//                    }]
//                },
//                options: {
//                    title: {
//                    display: true,
//                    text:'Marker %'
//                    }
//                }
//            });
//        },
//        error: function (jqXHR, exception) {
//					if (jqXHR.status === 0) {
//						msg = 1;
//					} else if (jqXHR.status == 404) {
//						msg = 2;
//					} else if (jqXHR.status == 500) {
//						msg = 3;
//					} else if (exception === 'parsererror') {
//						msg = 4;
//					} else if (exception === 'timeout') {
//						msg = 5;
//					} else if (exception === 'abort') {
//						msg = 6;
//					} else {
//						msg =7;
//						mseg = 'Uncaught Error.\n' + jqXHR.responseText;
//					}
//					
//				}
//        
//    });
//
//
//    $.ajax({
//        type: "GET",
//        url: "/logicgetJson",
//        success: function(result)
//        {
//            var values=result["result"]
//            len =values.length
//            var list_of_data= []
//            var list_of_label = []
//            for (i=0;i<len;i++){
//                list_of_label.push(values[i]["label"])
//                list_of_data.push(values[i]["y"])
//            }
//            new Chart(document.getElementById("Q_logic"), {
//                type: 'doughnut',
//                data: {
//                        labels: list_of_label,
//                datasets: [{                    
//                    backgroundColor: ["#3e95cd", "#8e5ea2","#3cba9f"],
//                    data: list_of_data
//                    }]
//                },
//                options: {
//                    title: {
//                    display: true,
//                    text:'Logic %'
//                    }
//                }
//            });
//        },
//        error: function (jqXHR, exception) {
//					if (jqXHR.status === 0) {
//						msg = 1;
//					} else if (jqXHR.status == 404) {
//						msg = 2;
//					} else if (jqXHR.status == 500) {
//						msg = 3;
//					} else if (exception === 'parsererror') {
//						msg = 4;
//					} else if (exception === 'timeout') {
//						msg = 5;
//					} else if (exception === 'abort') {
//						msg = 6;
//					} else {
//						msg =7;
//						mseg = 'Uncaught Error.\n' + jqXHR.responseText;
//					}
//					
//				}
//    });
//
//
//	$.ajax({
//        type: "GET",
//        url: "/pm_getJson",
//        success: function(result)
//        {
//            var values=result["result"]
//            len =values.length
//            var list_of_data= []
//            var list_of_label = []
//            for (i=0;i<len;i++){
//                list_of_label.push(values[i]["label"])
//                list_of_data.push(values[i]["y"])
//            }
//            new Chart(document.getElementById("PM"), {
//                type: 'doughnut',
//                data: {
//                        labels: list_of_label,
//                datasets: [{
//                    
//                    backgroundColor: ["#3e95cd", "#8e5ea2","#3cba9f"],
//                    data: list_of_data
//                    }]
//                },
//                options: {
//                    title: {
//                    display: true,
//                    text:'PM %'
//                    }
//                }
//            });
//        },
//        error: function (jqXHR, exception) {
//					if (jqXHR.status === 0) {
//						msg = 1;
//					} else if (jqXHR.status == 404) {
//						msg = 2;
//					} else if (jqXHR.status == 500) {
//						msg = 3;
//					} else if (exception === 'parsererror') {
//						msg = 4;
//					} else if (exception === 'timeout') {
//						msg = 5;
//					} else if (exception === 'abort') {
//						msg = 6;
//					} else {
//						msg =7;
//						mseg = 'Uncaught Error.\n' + jqXHR.responseText;
//					}
//					
//				}
//    });
//    $.ajax({
//        type: "GET",
//        url: "/clientgetJson",
//        success: function(result)
//        {
//            var values=result["result"]
//            len =values.length
//            var list_of_data= []
//            var list_of_label = []
//            for (i=0;i<len;i++){
//                list_of_label.push(values[i]["label"])
//                list_of_data.push(values[i]["y"])
//            }
//            new Chart(document.getElementById("client"), {
//                type: 'doughnut',
//                data: {
//                        labels: list_of_label,
//                datasets: [{
//                    label: "Population (millions)",
//                    backgroundColor: ["#3e95cd", "#8e5ea2","#3cba9f"],
//                    data: list_of_data
//                    }]
//                },
//                options: {
//                    title: {
//                    display: true,
//                    text:'Client%'
//                    }
//                }
//            });
//
//        },  
//			error: function (jqXHR, exception) {
//					if (jqXHR.status === 0) {
//						msg = 1;
//					} else if (jqXHR.status == 404) {
//						msg = 2;
//					} else if (jqXHR.status == 500) {
//						msg = 3;
//					} else if (exception === 'parsererror') {
//						msg = 4;
//					} else if (exception === 'timeout') {
//						msg = 5;
//					} else if (exception === 'abort') {
//						msg = 6;
//					} else {
//						msg =7;
//						mseg = 'Uncaught Error.\n' + jqXHR.responseText;
//					}
//					
//				}
//			
//    
//    });
//          
//	$('#submit').on('click',function(){
//		
//		var month = document.getElementById("month").value;
//		var year  =  document.getElementById("year").value;
//		var obj={"month":$("#month").val(),"year":$("#year").val()};
//		//var mani={'mani':20, 'Sanjay':100};
//		//console.log("month "+month +"\t year"+year+"Teast1- " +obj['year']);
//		console.log(obj);
//		if (month!=="0")
//		{
//			console.log("month "+month +"\t year"+year+"Teast1- " +obj);
//			$.ajax({				
//                type:'POST',
//                url:'/mainpage_1',
//                contentType:'application/json',
//                data:JSON.stringify(obj),
//                dataType:'jsonp',
//                success:function(results){  
//                    var answer =JSON.parse(JSON.stringify(results));
//					console.log(answer[resulits]);
//                        if(answer['results']=='Success'){                    
//                            window.location.replace("/mainpage_post");
//                        }
//                        else{
//                            $("#month").html("Chart for all data ");
//                        }
//
//                },
//                error: function (jqXHR, exception) {
//                    
//                    if (jqXHR.status === 0) {
//                        msg = 1;
//                    } else if (jqXHR.status == 404) {
//                        msg = 2;
//                    } else if (jqXHR.status == 500) {
//                        msg = 3;
//                    } else if (exception === 'parsererror') {
//                        msg = 4;
//                    } else if (exception === 'timeout') {
//                        msg = 5;
//                    } else if (exception === 'abort') {
//                        msg = 6;
//                    } else {
//                        msg =7; 
//						mseg ='Uncaught Error.\n' + jqXHR.responseText;
//                    }
//                    
//                }
//
//            });
//		}
//		else
//			{
//				 $("#month").innerHTML("Chart for all data ");
//			}
//		});
	 if (msg == 1) {
                msg = 'Not connect.\n Verify Network.';
            } else if (msg ==2) {
                msg = 'Requested page not found. [404]';
            } else if (msg== 3) {
                msg = 'Internal Server Error [500].';
            } else if (msg ==4) {
                msg = 'Requested JSON parse failed.';
            } else if (msg==5) {
                msg = 'Time out error.';
            } else if (msg ==6) {
                msg = 'Ajax request aborted.';
            } else if (msg == 7){
                msg = 'Uncaught Error.\n' + jqXHR.responseText;
            }
		if (msg >0)
		{
			alert(mseg);
		}
});