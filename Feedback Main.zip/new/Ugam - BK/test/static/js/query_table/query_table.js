$(document).ready(function () {

    $('#q_category').on('change', function (){
										var SV=document.getElementById("q_category").value;
										var Inp;
										Inp="";
										//console.log(SV);
										//console.log(Inp);	
										if (SV == "Skip/Logic - Missing data (With filter)"){
												Inp="We see ### respondents are going blank at Qxxxxx even though they qualify below condition. (FILTER as per Qre) \n \n  EG: \n  Kindly check. Please see few sample IDs for your reference.";
										}
										if (SV =="Skip/Logic - Missing data (Ask All)"){	
												Inp="We see ### respondents are going blank at Qxxxxx even though there is no filter for this question. \n \n  Kindly check. Please see few sample IDs for your reference.";
										}
										if (SV =="Skip/Logic - Extra data"){
												Inp="We see ### respondents are having data at Qxxxxx even though they do not qualify to answer this question as per below condition. (Condition as per Qre) \n \n  EG: \n  Kindly check. Please see few sample IDs for your reference.";
										}
										if (SV == "Script/questionaire Mismatch"){
												Inp="We see ### respondents are selecting options which are not qualified. E.g. Respondent.Serial = xxxxx selected option xxxxx however he does not qualify for below condition. \n  (Condition as per Qre) \n  Kindly check. Please see few sample IDs for your reference.";
										}
										if (SV == "Script/questionaire Mismatch (Numeric)"){
												Inp="We see ### respondents having value at this Qxxxxx which is out of range. Range should be Min to Max as per condition xxxxx given in Questionnaire. \n  (Condition as per Qre) \n  Kindly check. Please see few sample IDs for your reference.";
										}
										if (SV == "Incorrect Termination - Should have termed"){
												Inp = "We see ### respondents who should terminate at question Qxxxxx as per below but are not terminating at this question. \n  (TERM CONDITION as per Qre) \n  EG: \n  Kindly check. Please see few sample IDs for your reference.";
										}
										if (SV == "Incorrect Termination - Should not have termed"){
												Inp = "We see ### respondents who do not qualify below condition are terminating here.\n  (TERM CONDITION as per Qre) \n  EG: \n  Kindly let us know the reason for this? Please see few sample IDs for your reference.";
										}
										if (SV == "Skip/Logic - Missing data (OE)"){
												Inp = "a. We see ### respondents going blank here even though there is no filter. \n  b. We see ### respondents going blank here even  though they qualify specific condition. \n  (Condition as per Qre) \n  Kindly check. Please see few sample IDs for your reference.";
										}
										if (SV == "Quota - extra data"){
												Inp = "We see ### respondents who do not qualify in Cell xxxxx of this quota but still are getting marked in that cell. Could you please let us know the reason for this? \n  Ex: Give 1 e.g. with cell logic. Please see few sample IDs for your reference.";
										}
										if (SV == "Quota - missing data"){
												Inp = "We see ### respondents who qualify in Cell xxxxx of this quota but still are not getting marked in that cell. Could you please let us know the reason for this? \n  Ex: Give 1 e.g. with cell logic. Please see few sample IDs for your reference.";
										}
										if (SV == "ScreeningTable mismatch"){
												Inp = "We see ### respondents who should terminate at question Qxxxxx as per below condition but are terminating at question QYY. Could you please let us know the reason for this? \n  TERM CONDITION. Please see few sample IDs for your reference.";
										}
										if (SV == "Quota - Overquota"){
												Inp = "We see respondents are qualifying to punch at cell xxxxx of Quota Qxxxxx. However, same are marked into OverQuota. \n \n  We checked the target for that cell in OSF is not yet MET. Please see few sample IDs for your reference.";
										}
										if (SV == "Quota - Set to incorrect Cells"){
												Inp = "Respondents have punched into cell xxxxx of quota Qxxxxx. However, as per OSF target of that cell has already met. Same should have been punched into OverQuota. Please check. Please see few sample IDs for your reference.";
										}
										if (SV == "Missing Response/Attribute"){
												Inp = "We see this question is having an option xxxxx in Questionnaire but that response is missing in MDD.";
										}
										if (SV == "Missing questions"){
												Inp = "We see this question is present in Questionnaire but it is missing in MDD.";
										}
										if (SV == "Visual - Randomizatrion"){
												Inp = "We see as per Questionnaire,� responses / attributes needs to be randomized but there is no ran keyword in MDD. \n  Could you please check and confirm; if its randomized?";
										}
										if (SV == "Standard"){
												Inp = "Questions Qxxxxx, Qxxxxx, Qxxxxx are holding same lists as per Questionnaire but we see separate lists are created in MDD. This is not an issue in this wave however in future if at Q1 1 brand is added then there is a chance of missing that in Qxxxxx as Qxxxxx is on different page and says to use list of Qxxxxx.";
										}
										if (SV == "Incorrect question type"){
												Inp = "Question Type for this variable is not as per Questionnaire, As per Questionnaire It should be xxxxx but in MDD it is defined as xxxxx.";
										}
										if (SV == "Incorrect text"){
												Inp = "We see textual mismatch at this question. \n  Text in MDD = paste text in MDD \n  Text in Questionnaire = paste text in Questionnaire";
										}
										if (SV == "Least fill counts"){
												Inp = "We see least fill / random counts are not matching. There is major difference seen in counts. Please check and confirm it is working fine. \n \n  Ex: Give some e.g. of particular brands.Please see few sample IDs for your reference.";
										}
										if (SV == "Quota - Null Quota"){
												Inp = "We see ### respondent are not qualifying for any of the quota hence we have Null quota scenario, could you check this. Please see few sample IDs for your reference.";
										}
										if (SV == "Incorrect Calculation"){
												Inp = "Data at this question is not as per Calculation defined in Questionnaire. As per Questionnaire for Respondent serial xxxxx It should be xxxxx but in data we see value xxxxx. Kindly check. Please see few sample IDs for your reference.";
										}										
										if (SV == "Open End/Other Specify Not Collecting Data"){
												Inp = "We see respondents have selected Other option, however, they are blank in Other Specify text box. Please see few sample IDs for your reference.";
										}
										if (SV == "Storedview - Precode not match"){
												Inp = "We see expected categories does not match with the categories displayed on the link for these Questions. \n \n  EG:Respondent.Serial = xxxxx, this respondent eligible categories are {xxxxx} but in link for this respondent only {xxxxx} are shown. \n \n  Kindly Check. Please see few sample IDs for your reference.";
										}

										if (SV == "Storedview - Question missing"){
												Inp = "We see these questions does not have an item in the StoredViewedCategories. \n \n  Kindly Check. Please see few sample IDs for your reference.";
										}

//										if (SV == "Marker - Missing data"){
//												Inp = "1.������ We see marker description is �not clear / no label� . Kindly please update the marker label. \n 2.������ As per the marker description we are using for XXXX, but XXX respondents are going blank. Please let us know whether we are using or not. ";
//										}
//										if (SV == "Marker - Extra data"){
//												Inp = "We see ### respondents are having data at Qxxxxx even though they do not qualify to answer this marker  as per below marker label (text as per MDD)";
//										}

										document.getElementById('q_description').value = Inp; 
				});

$('#phase').on('click', function (){
	var changes = document.getElementById("phase").value;
	if (changes == "Live")
	{
		document.getElementById("version").value = "Live";
	}
	else{
		document.getElementById("version").value = "RDG1";
	}
});

$('#phase').on('change', function (){
	var changes = document.getElementById("phase").value;
	if (changes == "Live")
	{
		document.getElementById("version").value = "Live";
	}
	else{
		document.getElementById("version").value = "RDG1";
	}
});
 $('#q_category').on('click', function (){
										var SV=document.getElementById("q_category").value;
										var Inp;
										Inp="";
										//console.log(SV);
										//console.log(Inp);	
										if (SV == "Skip/Logic - Missing data (With filter)"){
												Inp="We see ### respondents are going blank at Qxxxxx even though they qualify below condition. (FILTER as per Qre) \n \n  EG: \n  Kindly check. Please see few sample IDs for your reference.";
										}
										if (SV =="Skip/Logic - Missing data (Ask All)"){	
												Inp="We see ### respondents are going blank at Qxxxxx even though there is no filter for this question. \n \n  Kindly check. Please see few sample IDs for your reference.";
										}
										if (SV =="Skip/Logic - Extra data"){
												Inp="We see ### respondents are having data at Qxxxxx even though they do not qualify to answer this question as per below condition. (Condition as per Qre) \n \n  EG: \n  Kindly check. Please see few sample IDs for your reference.";
										}
										if (SV == "Script/questionaire Mismatch"){
												Inp="We see ### respondents are selecting options which are not qualified. E.g. Respondent.Serial = xxxxx selected option xxxxx however he does not qualify for below condition. \n  (Condition as per Qre) \n  Kindly check. Please see few sample IDs for your reference.";
										}
										if (SV == "Script/questionaire Mismatch (Numeric)"){
												Inp="We see ### respondents having value at this Qxxxxx which is out of range. Range should be Min to Max as per condition xxxxx given in Questionnaire. \n  (Condition as per Qre) \n  Kindly check. Please see few sample IDs for your reference.";
										}
										if (SV == "Incorrect Termination - Should have termed"){
												Inp = "We see ### respondents who should terminate at question Qxxxxx as per below but are not terminating at this question. \n  (TERM CONDITION as per Qre) \n  EG: \n  Kindly check. Please see few sample IDs for your reference.";
										}
										if (SV == "Incorrect Termination - Should not have termed"){
												Inp = "We see ### respondents who do not qualify below condition are terminating here.\n  (TERM CONDITION as per Qre) \n  EG: \n  Kindly let us know the reason for this? Please see few sample IDs for your reference.";
										}
										if (SV == "Skip/Logic - Missing data (OE)"){
												Inp = "a. We see ### respondents going blank here even though there is no filter. \n  b. We see ### respondents going blank here even  though they qualify specific condition. \n  (Condition as per Qre) \n  Kindly check. Please see few sample IDs for your reference.";
										}
										if (SV == "Quota - extra data"){
												Inp = "We see ### respondents who do not qualify in Cell xxxxx of this quota but still are getting marked in that cell. Could you please let us know the reason for this? \n  Ex: Give 1 e.g. with cell logic. Please see few sample IDs for your reference.";
										}
										if (SV == "Quota - missing data"){
												Inp = "We see ### respondents who qualify in Cell xxxxx of this quota but still are not getting marked in that cell. Could you please let us know the reason for this? \n  Ex: Give 1 e.g. with cell logic. Please see few sample IDs for your reference.";
										}
										if (SV == "ScreeningTable mismatch"){
												Inp = "We see ### respondents who should terminate at question Qxxxxx as per below condition but are terminating at question QYY. Could you please let us know the reason for this? \n  TERM CONDITION. Please see few sample IDs for your reference.";
										}
										if (SV == "Quota - Overquota"){
												Inp = "We see respondents are qualifying to punch at cell xxxxx of Quota Qxxxxx. However, same are marked into OverQuota. \n \n  We checked the target for that cell in OSF is not yet MET. Please see few sample IDs for your reference.";
										}
										if (SV == "Quota - Set to incorrect Cells"){
												Inp = "Respondents have punched into cell xxxxx of quota Qxxxxx. However, as per OSF target of that cell has already met. Same should have been punched into OverQuota. Please check. Please see few sample IDs for your reference.";
										}
										if (SV == "Missing Response/Attribute"){
												Inp = "We see this question is having an option xxxxx in Questionnaire but that response is missing in MDD.";
										}
										if (SV == "Missing questions"){
												Inp = "We see this question is present in Questionnaire but it is missing in MDD.";
										}
										if (SV == "Visual - Randomizatrion"){
												Inp = "We see as per Questionnaire, responses / attributes needs to be randomized but there is no ran keyword in MDD. \n  Could you please check and confirm; if its randomized?";
										}
										if (SV == "Standard"){
												Inp = "Questions Qxxxxx, Qxxxxx, Qxxxxx are holding same lists as per Questionnaire but we see separate lists are created in MDD. This is not an issue in this wave however in future if at Q1 1 brand is added then there is a chance of missing that in Qxxxxx as Qxxxxx is on different page and says to use list of Qxxxxx.";
										}
										if (SV == "Incorrect question type"){
												Inp = "Question Type for this variable is not as per Questionnaire, As per Questionnaire It should be xxxxx but in MDD it is defined as xxxxx.";
										}
										if (SV == "Incorrect text"){
												Inp = "We see textual mismatch at this question. \n  Text in MDD = paste text in MDD \n  Text in Questionnaire = paste text in Questionnaire";
										}
										if (SV == "Least fill counts"){
												Inp = "We see least fill / random counts are not matching. There is major difference seen in counts. Please check and confirm it is working fine. \n \n  Ex: Give some e.g. of particular brands.Please see few sample IDs for your reference.";
										}
										if (SV == "Quota - Null Quota"){
												Inp = "We see ### respondent are not qualifying for any of the quota hence we have Null quota scenario, could you check this. Please see few sample IDs for your reference.";
										}
										if (SV == "Incorrect Calculation"){
												Inp = "Data at this question is not as per Calculation defined in Questionnaire. As per Questionnaire for Respondent serial xxxxx It should be xxxxx but in data we see value xxxxx. Kindly check. Please see few sample IDs for your reference.";
										}										
										if (SV == "Open End/Other Specify Not Collecting Data"){
												Inp = "We see respondents have selected Other option, however, they are blank in Other Specify text box. Please see few sample IDs for your reference.";
										}
										if (SV == "Storedview - Precode not match"){
												Inp = "We see expected categories does not match with the categories displayed on the link for these Questions. \n \n  EG:Respondent.Serial = xxxxx, this respondent eligible categories are {xxxxx} but in link for this respondent only {xxxxx} are shown. \n \n  Kindly Check. Please see few sample IDs for your reference.";
										}

										if (SV == "Storedview - Question missing"){
												Inp = "We see these questions does not have an item in the StoredViewedCategories. \n \n  Kindly Check. Please see few sample IDs for your reference.";
										}

//										if (SV == "Marker - Missing data"){
//												Inp = "1.������ We see marker description is �not clear / no label� . Kindly please update the marker label. \n 2.������ As per the marker description we are using for XXXX, but XXX respondents are going blank. Please let us know whether we are using or not. ";
//										}
//										if (SV == "Marker - Extra data"){
//												Inp = "We see ### respondents are having data at Qxxxxx even though they do not qualify to answer this marker  as per below marker label (text as per MDD)";
//										}

										document.getElementById('q_description').value = Inp; 
				});

    $('#sidebarCollapse').on('click', function () {
        $('#sidebar').toggleClass('active');
    });

    $("#showdropdown").on('click', function () {
        window.location.replace("/logout")
    });
    
    $("#add_query").click(function(){
        var num=/^[0-9]+$/;
        var val="";
        var pl="0";
        var d=0;
        var q_d1= "XXX";
        var q_d2= "QXXX";
        var q_d3= "###";
		
		var qSID 		 	= document.getElementById('sid').value;
		var qBU				= document.getElementById('region').value;
		var qType			= document.getElementById('project_type').value;
		var qno				= document.getElementById('q_no').value;
		var qcategory	 	= document.getElementById('q_category').value;
		var qdescription 	= document.getElementById('q_description').value;
		var qsampleid	 	= document.getElementById('sample_id').value;
				
		var qresult 		= document.getElementById('result').value;
//		var qexplain 		= document.getElementById('explain').value;
		var qphase			= document.getElementById('phase').value;
		var qversion		= document.getElementById('version').value;
//		var qstatus			= document.getElementById('status').value;
		var qSWresponsible	= document.getElementById('sw_responsible').value;
		//console.log(qSID)
		document.getElementById('qSID').innerHTML = "";
		document.getElementById('qBU').innerHTML = "";
		document.getElementById('qType').innerHTML = "";
		document.getElementById('qno').innerHTML = "";
		document.getElementById('qcategory').innerHTML = "";
		document.getElementById('qdescription').innerHTML = "";
		document.getElementById('qsampleid').innerHTML = "";
		document.getElementById('qclarification').innerHTML = "";
		document.getElementById('qresult').innerHTML = "";
//		document.getElementById('qexplain').innerHTML = "";
		document.getElementById('qphase').innerHTML = "";
		document.getElementById('qversion').innerHTML = "";
//		document.getElementById('qstatus').innerHTML = "";
		document.getElementById('qSWresponsible').innerHTML = "";
		if (qSID.length == ""){
			document.getElementById('qSID').innerHTML = "*Please enter SID."
			return true;
			d = d + 1 ; 
			
		}

		if (qSID.length != 6){
			document.getElementById('qSID').innerHTML = "*SID should be 6 Numeric digits."
			return true;
			d = d + 1 ; 
			
		}
		
		if (qBU == "0"){
			document.getElementById('qBU').innerHTML = "*Please select BU.";
			return true;
			d = d + 1 ; 
		}
		
		if (qType == "0"){
			document.getElementById('qType').innerHTML = "*Please select Type.";
			return true;
			d = d + 1 ; 
		}
		
		if (qno == ""){
			document.getElementById('qno').innerHTML = "*Please enter Q. No.";
			return true;
			d = d + 1 ; 
		}
		
		if (qcategory == "0"){
			document.getElementById('qcategory').innerHTML = "*Please select category.";
			return true;
			d = d + 1 ; 
		}
		
		if (qdescription == ""){
			document.getElementById('qdescription').innerHTML = "*Please Explain.";
			return true;
			d = d + 1 ; 
		}
		
			if (qdescription.indexOf("xxx")>0){
			document.getElementById('qdescription').innerHTML = "*Please xxx update.";
			return true;
			d = d + 1 ; 
			}		
			if (qdescription.indexOf("Qxxx")>0){
			document.getElementById('qdescription').innerHTML = "*Please Qxxx update.";
			return true;
			d = d + 1 ; 
			}
			if (qdescription.indexOf("###")>0){
			document.getElementById('qdescription').innerHTML = "*Please ### update.";
			return true;
			d = d + 1 ; 
			}
			if (qdescription.indexOf("XXX")>0){
			document.getElementById('qdescription').innerHTML = "*Please XXX update.";
			return true;
			d = d + 1 ; 
			}
			if ((qdescription.indexOf("FILTER as per Qre"))>0){
			document.getElementById('qdescription').innerHTML = "*Please FILTER as per Qre update.";
			return true;
			d = d + 1 ; 
			}
		if ((qdescription.indexOf("Condition as per Qre"))>0){
			document.getElementById('qdescription').innerHTML = "*Please Condition as per Qre.";
			return true;
			d = d + 1 ; 
			}
			
		

		if (qsampleid == ""){
			document.getElementById('qsampleid').innerHTML = "*Please enter sample respondent serial.";
			return true;
			d = d + 1 ; 
		}
		
		if (qclarification == "0"){
			document.getElementById('qclarification').innerHTML = "*Please select Classification.";
			return true;
			d = d + 1 ; 
		}
		
		if (qresult == "0"){
			document.getElementById('qresult').innerHTML = "*Please select category.";
			return true;
			d = d + 1 ; 
		}
						
		if (qphase == "0"){
			document.getElementById('qphase').innerHTML = "*Please select phase.";
			return true;
			d = d + 1 ; 
		}
		
		if (qversion == "0"){
			document.getElementById('qversion').innerHTML = "*Please select RDG version .";
			return true;
			d = d + 1 ; 
		}
		
//		if (qstatus == "0"){
//			document.getElementById('qstatus').innerHTML = "*Please select Status.";
//			return true;
//			d = d + 1 ; 
//		}
		
		if (qSWresponsible == "0"){
			document.getElementById('qSWresponsible').innerHTML = "*Please enter SW responsible name";
			return true;
			d = d + 1 ; 
		}
		
		
		// var s1
        // s1= document.getElementById("sid")
        if (d == 0) {
            var obj={"sid":$("#sid").val(), 
			"region":$("#region").val(), 
			"project_type":$("#project_type").val(),
            "q_no":$("#q_no").val(),
			"q_category":$("#q_category").val(), 
			"q_description":$("#q_description").val(),
            "sample_id":$("#sample_id").val(),
			"clarification":$("#clarification").val(), 
			"result":$("#result").val(),            
			"phase":$("#phase").val(),
			"rdg_version":$("#version").val(),
			// "qa_responsible":$("#qa_responsible").val(),
            "status":"Open",
			"sw_responsible":$("#sw_responsible").val()}
			console.log(obj);
            $.ajax({
                type:'post',
                url:'/add_query',
                contentType:'application/json',
                data:JSON.stringify(obj),
                dataType:'json',
                success:function(results){  
                    var answer =JSON.parse(JSON.stringify(results))
					//console.log(answer['results'])
                        if(answer['results']=='Success'){                    
                            alert("Data Inserted Successfully")
							
							document.getElementById('q_no').value = "";
							document.getElementById('q_category').value = "0";
							document.getElementById('q_description').value = "";
							document.getElementById('sample_id').value = "";
							document.getElementById('clarification').value = "0";
							document.getElementById('result').value = "0";
							
							
                        }
                        else{
                            alert(answer['results' ]) 
                        }

                },
                error: function (jqXHR, exception) {
                    var msg = '';
                    if (jqXHR.status === 0) {
                        msg = 'Not connect.\n Verify Network.';
                    } else if (jqXHR.status == 404) {
                        msg = 'Requested page not found. [404]';
                    } else if (jqXHR.status == 500) {
                        msg = 'Internal Server Error [500].';
                    } else if (exception === 'parsererror') {
                        msg = 'Requested JSON parse failed.';
                    } else if (exception === 'timeout') {
                        msg = 'Time out error.';
                    } else if (exception === 'abort') {
                        msg = 'Ajax request aborted.';
                    } else {
                        msg = 'Uncaught Error.\n' + jqXHR.responseText;
                    }
                    alert(msg);
                }

            });
        }
		
                
    });

    $("#view_query").click(function(){
		 var num=/^[0-9]+$/;
        var val="";
        var pl="0";
        var d=0;
        var q_d1= "XXX";
        var q_d2= "QXXX";
        var q_d3= "###";
		
		var qSID 		 	= document.getElementById('sid').value;
		var qBU				= document.getElementById('region').value;
		var qType			= document.getElementById('project_type').value;
//		var qno				= document.getElementById('q_no').value;
//		var qcategory	 	= document.getElementById('q_category').value;
//		var qdescription 	= document.getElementById('q_description').value;
//		var qsampleid	 	= document.getElementById('sample_id').value;
//		var qclarification 	= document.getElementById('clarification').value;		
//		var qresult 		= document.getElementById('result').value;
////		var qexplain 		= document.getElementById('explain').value;
//		var qphase			= document.getElementById('phase').value;
//		var qversion		= document.getElementById('version').value;
////		var qstatus			= document.getElementById('status').value;
//		var qSWresponsible	= document.getElementById('sw_responsible').value;
		
		if (qSID == ""){
			document.getElementById('qSID').innerHTML = "*Please enter SID and SID should be 6 Numeric digits."
			d = d + 1 ; 
		}
		if (qSID.length != 6){
			document.getElementById('qSID').innerHTML = "*SID should be 6 Numeric digits."
			d = d + 1 ; 
		}
		
		if (qBU == "0"){
			document.getElementById('qBU').innerHTML = "*Please select BU."
			d = d + 1 ; 
		}
		
		if (qType == "0"){
			document.getElementById('qType').innerHTML = "*Please select Type."
			d = d + 1 ; 
		}
		
//		if (qno == ""){
//			document.getElementById('qno').innerHTML = "*Please enter Q. No."
//			d = d + 1 ; 
//		}
//		
//		if (qcategory == "0"){
//			document.getElementById('qcategory').innerHTML = "*Please select category."
//			d = d + 1 ; 
//		}
//		
//		if (qdescription == ""){
//			document.getElementById('qdescription').innerHTML = "*Please Explain."
//			d = d + 1 ; 
//		}
//		
//		if (qsampleid == ""){
//			document.getElementById('qsampleid').innerHTML = "*Please enter sample respondent serial."
//			d = d + 1 ; 
//		}
//		
//		if (qclarification == "0"){
//			document.getElementById('qclarification').innerHTML = "*Please select Classification."
//			d = d + 1 ; 
//		}
//		
//		if (qresult == "0"){
//			document.getElementById('qresult').innerHTML = "*Please select category."
//			d = d + 1 ; 
//		}
//		
//		
//		
//		if (qphase == "0"){
//			document.getElementById('qphase').innerHTML = "*Please select phase."
//			d = d + 1 ; 
//		}
//		
//		if (qversion == "0"){
//			document.getElementById('qversion').innerHTML = "*Please select RDG version ."
//			d = d + 1 ; 
//		}
//		
//		if (qstatus == "0"){
//			document.getElementById('qstatus').innerHTML = "*Please select Status."
//			d = d + 1 ; 
//		}
//		
//		if (qSWresponsible == ""){
//			document.getElementById('qSWresponsible').innerHTML = "*Please enter SW responsible name"
//			d = d + 1 ; 
//		}
		
		if (d == 0){
        var obj={"sid":$("#sid").val()}
        $.ajax({
                type:'post',
                url:'/view_details_by_sid',
                contentType:'application/json',
                data:JSON.stringify(obj),
                dataType:'json',
                success:function(results){  
                    var answer =JSON.parse(JSON.stringify(results))
                        localStorage.setItem( 'result', JSON.stringify(answer['result']) );
                        console.log( JSON.parse( localStorage.getItem( 'result' ) ) );
                        window.location.replace("/view_details")

                    },
                    error: function (jqXHR, exception) {
                        var msg = '';
                        if (jqXHR.status === 0) {
                            msg = 'Not connect.\n Verify Network.';
                        } else if (jqXHR.status == 404) {
                            msg = 'Requested page not found. [404]';
                        } else if (jqXHR.status == 500) {
                            msg = 'Internal Server Error [500].';
                        } else if (exception === 'parsererror') {
                            msg = 'Requested JSON parse failed.';
                        } else if (exception === 'timeout') {
                            msg = 'Time out error.';
                        } else if (exception === 'abort') {
                            msg = 'Ajax request aborted.';
                        } else {
                            msg = 'Uncaught Error.\n' + jqXHR.responseText;
                        }
                        alert(msg);
                    }
                    
                });
		}

    });

});