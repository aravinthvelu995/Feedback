$(document).ready(function(){
	if(navigator.userAgent.indexOf("Chrome") != -1 )
			{
				a= 1;
			}
	else
	{
		alert('Please use Chrome to view better' );
	}

	 $('#sidebarCollapse').on('click', function () {
        $('#sidebar').toggleClass('active');
    });
    $("#showdropdown").on('click', function () {
        window.location.replace("/logout")
    });

    $("#reset").click(function(){
        $("#emp_id").val("");
        $("#emp_name").val("");
        $("#emp_phone").val("");
        $("#emp_pass").val("");
        $("#role").val("0");
      });

   
    $("#submit").on('click',function(){
        
		if(navigator.userAgent.indexOf("Chrome") != -1 )
			{
				a= 1;
			}
		else
		{
			alert('Please use Chrome to view better' );
		}
    		var  count = "";
			var  s1= 0;
			var  r1 = document.getElementById("emp_id").value;
			var  r2 = document.getElementById("emp_name").value;
			var  r3 = document.getElementById("emp_phone").value;
			var  r4 = document.getElementById("emp_pass").value;
			var  r5 = document.getElementById("role").value;
			console.log("r1-",r1,"r2 - ",r2,"r3-", r3,"r4-",r4,"r5-", r5);
			if (r1 == ""){
						count = "Employee ID -";
						s1 = s1 +1;
						console.log("super ra dei",s1);
					}
			if (r2 == ""){
					count = count + " Employee Name -";	
					s1 = s1 +1;
					}
			if (r3 == ""){
					count = count + "  Mobile Number -";		
					s1 = s1 +1;
					}
			if (r4 == ""){
					count = count + "  Password -";		
					s1 = s1 +1;
					}
			if (r5 == "0"){
					count = count + "  role -";		
					s1 = s1 +1;
					}
			if (s1>0)  {
					alert("PLEASE ENTER" + count);	
				}
	if(s1==0){
			var obj={"emp_id":$("#emp_id").val(),"emp_name":$("#emp_name").val(), "emp_phone":$("#emp_phone").val(),"emp_pass":$("#emp_pass").val(),"role":$("#role").val()};
			console.log(obj);
			$.ajax({
				type:'post',
				url:'/register',
				contentType:'application/json',
				data:JSON.stringify(obj),
				dataType:'json',
				success:function(results){
					var result =JSON.parse(JSON.stringify(results))
//					if(result['results']=='Success'){
//							
//						alert("Data inserted");
//						$("#emp_id").val("");
//						$("#emp_name").val("");
//						$("#emp_phone").val("");
//						$("#emp_pass").val("");
//						$("#role").val("0");
//					}
					
				},
				error: function (jqXHR, exception) {
					var msg = '';
					if (jqXHR.status === 0) {
						msg = 'Not connect.\n Verify Network.';
					} else if (jqXHR.status == 404) {
						msg = 'Requested page not found. [404]';
					} else if (jqXHR.status == 500) {
//						msg = 'internal server error';
					} else if (exception === 'parsererror') {
						msg = 'Requested JSON parse failed.';
					} else if (exception === 'timeout') {
						msg = 'Time out error.';
					} else if (exception === 'abort') {
						msg = 'Ajax request aborted.';
					} else {
						msg = 'Uncaught Error.\n' + jqXHR.responseText;
					}
					if (msg.length >0)
					{
						alert(msg);
					}
					
				}

			});
		
		}
    });

    $(document).keypress(function(event){
        var keycode = (event.keyCode ? event.keyCode : event.which);
        if(keycode == '13'){
            $("#submit").click();
        }
    });

});