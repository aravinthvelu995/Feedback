$(document).ready(function () {
    
    $('#sidebarCollapse').on('click', function () {
        $('#sidebar').toggleClass('active');
    });
    $("#showdropdown").on('click', function () {
        window.location.replace("/logout")
    });
	
	$.ajax({
				type:"GET",
				url:"/programmer_view",
				contentType:"application/json",
				success:function(results){
					var result =JSON.parse(JSON.stringify(results))
						if(result['results']=='Success'){ 
							document.location.replace('/view')
						}
					},error: function (jqXHR, exception) {
					if (jqXHR.status === 0) {
						 msg = 'Not connect.\n Verify Network.';
					} else if (jqXHR.status == 404) {
						 msg = 'Requested page not found. [404]';
					} else if (jqXHR.status == 500) {
						 msg = 'Invalite SID';
					} else if (exception === 'parsererror') {
						msg = 'Requested JSON parse failed.';
					} else if (exception === 'timeout') {
						msg = 'Time out error.';
					} else if (exception === 'abort') {
						msg = 'Ajax request aborted.';
					} else {						
						msg = 'Uncaught Error.\n' + jqXHR.responseText;
					}
					
				}
    
				});
	
	$("#search").on("click", function() {
                var value = $(this).val();
                   $("#customershowbychitid1 tr").filter(function() {
                   $(this).toggle($(this).text().indexOf(value) > -1)
                });
    });
    
	$('.table tbody').on('click','.btns',function(){
        var currow =$(this).closest('tr');
        var  col1=currow.find('td:eq(0)').text();
        var  col2=currow.find('td:eq(1)').text();
        var  col3=currow.find('td:eq(2)').text();
        var  col4=currow.find('td:eq(3)').text();
        var  col5=currow.find('td:eq(4)').text();
		var  col6=currow.find('td:eq(5)').text();
//        var  col7=currow.find('td:eq(6)').text();

			$("#serial_no").val(col1);
			$("#serial_no").attr("disabled", "disabled");
			$("#u_emp_id").val(col2);
			$("#u_emp_id").attr("disabled", "disabled");
			$("#u_emp_name").val(col3);			
			$("#u_emp_name").attr("disabled", "disabled");
			$("#u_emp_phone").val(col4);
			$("#u_emp_pass").val(col5);
			$("#u_emp_role").val(col6);
		});

    $("#update_details").on('click',function(){
		
//		console.log(col15);
		var ex = 0;
		var text = "";
		var phone = document.getElementById("u_emp_phone");
		var pass = document.getElementById("u_emp_pass");
		var role = document.getElementById("u_emp_role");
		console.log("phone - "+phone +"-pass -"+pass+"-role -"+role)
		if(phone == ""){
			ex = ex +1;
			text = "  Mobile number -"
		}
		if(pass == ""){
			ex = ex +1;
			text = "  Password -"
		}
		if(role == ""){
			ex = ex +1;
			text = "  Role-"
		}
		if (text.lengrh>0)
		{
			alert("Please Enter"+text)
		}
		
		if (ex == 0)
		{
			
				//var example1 = ($("#explain1").val() + "\n\n"+$("#explain2").val());
				var obj={"u_emp_id":$("#u_emp_id").val(),
				"u_emp_phone":$("#u_emp_phone").val(),
				"u_emp_pass":$("#u_emp_pass").val(),
				"u_emp_role":$("#u_emp_role").val()}
				console.log(obj)	  
				$.ajax({
					type:"POST",
					url:"/update_programmer_details",
					contentType:"application/json",
					data:JSON.stringify(obj),
					dataType:"json",
					success:function(results){
						var result =JSON.parse(JSON.stringify(results))
							if(result['result']=='Success'){ 
								document.location.replace('/view')
							}
							else{
								alert(result['result'])
							}
						}
					});
				}
			});
		
        $('.table tbody').on('click','.btnn',function(){
            
            var currow =$(this).closest('tr');
            var  col4=currow.find('td:eq(1)').text();
            $("#serial_no").val(col1);
            $("#u_emp_id").val(col4);
			$.ajax({
                type:"post",
                url:"/delete_programmer_details",
                contentType:"application/json",
                data:JSON.stringify(obj),
                dataType:"json",
                success:function(results){
					console.log(obj);
                    var result =JSON.parse(JSON.stringify(results))
                        if(result['result']=='Success'){
							console.log("SUCCESS -- "+obj);
                            window.location.reload(true)
                        }
//                        else{
//                            alert(result['result'])
//                        }
                
                },
                error: function (jqXHR, exception) {
                    var msg = '';
                    if (jqXHR.status === 0) {
                        msg = 'Not connect.\n Verify Network.';
                    } else if (jqXHR.status == 404) {
                        msg = 'Requested page not found. [404]';
                    } else if (jqXHR.status == 500) {
                        msg = 'Internal error';
                    } else if (exception === 'parsererror') {
                        msg = 'Requested JSON parse failed.';
                    } else if (exception === 'timeout') {
                        msg = 'Time out error.';
                    } else if (exception === 'abort') {
                        msg = 'Ajax request aborted.';
                    } else {
                        msg = 'Uncaught Error.\n' + jqXHR.responseText;
                    }
                    alert(msg);
                } 
            });
        });

        $("#yesDelete").on('click',function(){

            var obj={"u_emp_id":$("#u_emp_id").val()}

            
            
        });

               
   
});
