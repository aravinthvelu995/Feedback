
$(document).ready(function () {
    console.log( JSON.parse( localStorage.getItem( 'result' ) ) );
	var  col16;
   
    $('#sidebarCollapse').on('click', function () {
        $('#sidebar').toggleClass('active');
    });
    $("#showdropdown").on('click', function () {
        window.location.replace("/logout")
    });
    
	$("#search").on("click", function() {
                var value = $(this).val();
                   $("#customershowbychitid1 tr").filter(function() {
                   $(this).toggle($(this).text().indexOf(value) > -1)
                });
    });

    $('.table tbody').on('click','.btns',function(){
        
        var currow =$(this).closest('tr');
        var  col1=currow.find('td:eq(8)').text();
        var  col2=currow.find('td:eq(9)').text();
        var  col3=currow.find('td:eq(10)').text();
		col16=currow.find('td:eq(15)').text();
       /*  var  col4=currow.find('td:eq(3)').text();
        var  col5=currow.find('td:eq(4)').text();
        var  col6=currow.find('td:eq(5)').text();
        var  col7=currow.find('td:eq(6)').text();
        var  col8=currow.find('td:eq(7)').text();
        var  col9=currow.find('td:eq(8)').text();
        var  col10=currow.find('td:eq(9)').text();
        var  col11=currow.find('td:eq(10)').text();
        var  col12=currow.find('td:eq(11)').text();
        var  col13=currow.find('td:eq(12)').text();
        var  col14=currow.find('td:eq(13)').text();
        var  col15=currow.find('td:eq(14)').text();
        
        var  col17=currow.find('td:eq(16)').text(); */
        
       /*  $("#sid").val(col1);
        $("#sid").attr("disabled", "disabled"); 
        $("#region").val(col2);
        $("#region").attr("disabled", "disabled"); 
        $("#project_type").val(col3);
        $("#project_type").attr("disabled", "disabled"); 
        $("#serial_no").val(col4);
        $("#serial_no").attr("disabled", "disabled"); 
        $("#date").val(col5);
        $("#date").attr("disabled", "disabled"); 
        $("#query_no").val(col6);
        $("#query_no").attr("disabled", "disabled"); 
        $("#quert_categories").val(col7);
        $("#quert_categories").attr("disabled", "disabled");  */
        $("#query_description").val(col8);
        $("#query_description").attr("disabled", "disabled"); 
        $("#serial").val(col9);
        $("#clarification").val(col10);
      /*   $("#result").val(col1);
        $("#explain1").val(col12);
        $("#phase").val(col13);
        $("#version").val(col14);
        $("#responsible").val(col15);
        $("#responsible").attr("disabled", "disabled"); 
        $("#status").val(col16);
        $("#sw_responsible").val(col17); */
    });

    $("#update").on('click',function(){
        var obj={"clarification": $("#clarification").val(),
        "result": $("#result").val(),"explain1": $("#explain1").val()}
              
        $.ajax({
            type:"post",
            url:"/update_query_details",
            contentType:"application/json",
            data:JSON.stringify(obj),
            dataType:"json",
            success:function(results){
                var result =JSON.parse(JSON.stringify(results))
                    if(result['result']=='Success'){ 
                        window.location.replace('/new_view_details_by_sid')
                    }
                    else{
                        alert(result['result'])
                    }
                }
            });
        });

        $('.table tbody').on('click','.btnn',function(){
            
            var currow =$(this).closest('tr');
            var  col1=currow.find('td:eq(0)').text();
            var  col4=currow.find('td:eq(3)').text();
            $("#sample").val(col1);
            $("#sample1").val(col4);
        });

        $("#yesDelete").on('click',function(){

            var obj={"sid":$("#sample").val(),"serial_no":$("#sample1").val(),}

            
            $.ajax({
                type:"post",
                url:"/delete_query_details",
                contentType:"application/json",
                data:JSON.stringify(obj),
                dataType:"json",
                success:function(results){
                    var result =JSON.parse(JSON.stringify(results))
                        if(result['result']=='Success'){
                            window.location.replace('/new_view_details_by_sid')                                  
                        }
                        else{
                            alert(result['result'])
                        }
                
                },
                error: function (jqXHR, exception) {
                    var msg = '';
                    if (jqXHR.status === 0) {
                        msg = 'Not connect.\n Verify Network.';
                    } else if (jqXHR.status == 404) {
                        msg = 'Requested page not found. [404]';
                    } else if (jqXHR.status == 500) {
                        msg = 'Internal Server Error [500].';
                    } else if (exception === 'parsererror') {
                        msg = 'Requested JSON parse failed.';
                    } else if (exception === 'timeout') {
                        msg = 'Time out error.';
                    } else if (exception === 'abort') {
                        msg = 'Ajax request aborted.';
                    } else {
                        msg = 'Uncaught Error.\n' + jqXHR.responseText;
                    }
                    alert(msg);
                } 
            });
        });

               
    $('#createapi').on('click', function () {
        var address="http:127.0.0.1:5000/QA_Query_details/"            
        var sid = $('#customershowbychitid tr:nth-child(1) td:nth-child(1)').text()
        var api=address+""+sid
        $("#api_textbox").val(api);
        document.getElementById("API").innerHTML = api;
    });

    $("#createexcel").click(function () {
        $("#datatocsvtable").tableToCSV({
            separator:',',
            newline:'\n',
            quoteFields:true,
            filename:sid

        });
    });

    $("#send").on("click",function(){

        $("#myModal").modal({action:'show', backdrop: 'static', keyboard: false});      
        $(".content-wrapper").addClass("after_modal_appended");
        $('.modal-backdrop').appendTo('.content-wrapper');   
        $('body').removeClass("modal-open");
        $('body').css("padding-right",""); 
    });

    $("#send_email").on('click',function(){
        var obj={"username":$("#username").val(),"password":$("#password").val(),"recieve_email":$("#reciever_mails").val()}
           
            $.ajax({
                type:"post",
                url:"/send_email",
                contentType:"application/json",
                data:JSON.stringify(obj),
                dataType:"json",
                success:function(results){
                    var result =JSON.parse(JSON.stringify(results))
                        if(result['result']=='Success'){
                            alert("Send Email Successfully")
                        }
                        else{
                            alert(result['result'])
                        }
                
                },
                error: function (jqXHR, exception) {
                    var msg = '';
                    if (jqXHR.status === 0) {
                        msg = 'Not connect.\n Verify Network.';
                    } else if (jqXHR.status == 404) {
                        msg = 'Requested page not found. [404]';
                    } else if (jqXHR.status == 500) {
                        msg = 'Internal Server Error [500].';
                    } else if (exception === 'parsererror') {
                        msg = 'Requested JSON parse failed.';
                    } else if (exception === 'timeout') {
                        msg = 'Time out error.';
                    } else if (exception === 'abort') {
                        msg = 'Ajax request aborted.';
                    } else {
                        msg = 'Uncaught Error.\n' + jqXHR.responseText;
                    }
                    alert(msg);
                } 
            });
        
    });
});
