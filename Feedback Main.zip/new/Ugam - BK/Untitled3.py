 try:
        global username
        global password
        data=request.get_json()
        #print("user data ",data)
        username = data["username"]
        password= data["password"]
        #print(username)
        #print(password)
        db = pyodbc.connect(r'Driver={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=C:\Mani\new\Ugam\User.accdb;')
        #db = mysql.connector.connect(user='root',passwd='',host='localhost',database='mani')
        mycursor = db.cursor()
        sql = "select username , password, role from admin where username =?"
        val = username
        mycursor.execute(sql, val)
        a = mycursor.fetchone()
        db.commit()
        db.close()
		vasr=""
        #if sha256_crypt.verify(data["username"],a[0]) and sha256_crypt.verify(data["password"],a[1])==True:
		if role == "programmer":
			if (len(username)>0 and len(password)>0) and (username.upper() == a[0].upper() and password==a[1] and a[2]=="Team Lead"): 
				session["logged_in"] = True
				session.permanent = True
				username = a[0]
				var = "Success"
				return jsonify({"result":var})
			   # print("nallavane")
			else:
			   # print("endata dei")
				return jsonify({"result":"Failiure"})
		elif role == "Team lead":
			if (len(username)>0 and len(password)>0) and (username.upper() == a[0].upper() and password==a[1] and a[2]=="Team Lead"): 
				session["logged_in"] = True
				session.permanent = True
				username = a[0]
				var = "Success_ad"
				return jsonify({"result":var})
			   # print("nallavane")
			else:
			   # print("endata dei")
				return jsonify({"result":"Failiure"})


