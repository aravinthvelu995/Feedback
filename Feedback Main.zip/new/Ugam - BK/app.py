from flask import Flask,request,render_template,jsonify,redirect,url_for,session,app
import simplejson as json
import mysql.connector
import os
from functools import wraps
import datetime
import random
import socket
from datetime import timedelta
import requests
import csv
import calendar
import pyodbc
import getpass
import logging
from logging.handlers import RotatingFileHandler
app=Flask(__name__)
app.secret_key = "kl2j343j5#$%#%34534%#$%$%^&**&*^*$%ERTertertert@#$@$frewer$@#$@#$"
app.config['PERMANENT_SESSION_LIFETIME'] =  timedelta(minutes=540)
APP_ROOT=os.path.dirname(os.path.abspath(__file__))

username=""

@app.route("/ugam_MG_login")
def index():
    try:
        if session["logged_in"]:
            return render_template("main_page/mainpage.html")
        else:
            return render_template("index.html")
    except Exception as e:
        foo()
        return render_template("index.html")

@app.route("/ugam_MG_login_ad")
def index_ad():
    try:
        if session["logged_in_1"]:
            return render_template("main_page/mainpage_ad.html")
        elif session["logged_in_SW"]:
            return render_template("table_view/table_view_SW.html")
        else:
            return render_template("index_ad.html")
    except Exception as e:
        foo()
        return render_template("index_ad.html")

def login_required(f):
    @wraps(f)
    def wrap(*args, **kwargs):
        if 'logged_in':
            return f(*args, **kwargs)
        else:
            return  render_template("index.html")
    return wrap

@app.route("/logout")
@login_required
def logout():
    session.clear()
    username=""
    return  render_template("index.html")

@app.route("/logout_ad")
@login_required
def logout_ad():
    session.clear()
    username=""
    return  render_template("index_ad.html")

@app.route("/login", methods=['post'])
def login():
    try:
        global username
        global password
        data=request.get_json()
        username = data["username"]
        password= data["password"]
        db=mysql.connector.connect(user="root",passwd="",host="localhost",database="mani")#db = pyodbc.connect(r'Driver={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=C:\Mani\new\Ugam\User.accdb;')
        mycursor = db.cursor()
        sql = "SELECT username , password, role FROM admin WHERE username ='%s'"%(username)
        mycursor.execute(sql)
        a = mycursor.fetchone()
        db.commit()
        db.close()
#        print(len(data))
        if len(data)==3:
            if (len(username)>0 and len(password)>0) and (username.upper() == a[0].upper() and password ==a[1] and (a[2]=="Programmer" or a[2]=="Team Lead")) : 
                session["logged_in_1"] = False
                session["logged_in_SW"] = False
                session["logged_in"] = True
                session["username"] = a[0]
                session.permanent = True
                return jsonify({"result":"PSuccess"})
            else:
                return jsonify({"result":"Failiure"})
        else:
            if (len(username)>0 and len(password)>0) and (username.upper() == a[0].upper() and password==a[1] and a[2]=="Team Lead"): 
                session["logged_in_1"] = True
                session["logged_in_SW"] = False
                session["logged_in"] = False
                session.permanent = True
                session["username"] = a[0]
                return jsonify({"result":"Success"})
            if (len(username)>0 and len(password)>0) and (username.upper() == a[0].upper() and password==a[1] and a[2]=="SWTeam Lead"):
                session["logged_in_1"] = False
                session["logged_in_SW"] = True
                print(session["logged_in_SW"])
                session.permanent = True
                session["username"] = a[0]
                return jsonify({"result":"SWSuccess"})
    except Exception as e:
        return jsonify({"result":e})
        return str(e)

@app.route('/')
def foo():
    name = getpass.getuser()
    hostname = socket.gethostbyname(socket.gethostname())
    app.logger.warning('A warning occurred (System Loging name: %s) (System IP %s)',name, str(hostname))
    app.logger.error('An error occurred (System Loging name: %s) (System IP %s)',name, str(hostname))
    app.logger.info('Info (System Loging name: %s) (System IP %s)',name, str(hostname))
    return "foo"

@app.route("/register",methods=['post'])
def register():
    try:
        data = request.get_json()
#        print(data)
        db = mysql.connector.connect(user='root',passwd='',host='localhost',database='mani')#db = pyodbc.connect(r'Driver={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=C:\Mani\new\Ugam\User.accdb;')
        mycursor=db.cursor()
        sql="INSERT INTO admin (emp_id,username, password,role) VALUES ('%s', '%s', '%s', '%s')"%(data["emp_id"],data["emp_name"], data["emp_pass"],data["role"])
        mycursor.execute(sql)
        db.commit()
        db.close()
        return jsonify({"result":"Success"})
    except Exception as e:
        print(e)
        return jsonify({"result":str(e)})

view_programmer=[]
def programmer_view():
        global view_programmer
        db = mysql.connector.connect(user='root',passwd='',host='localhost',database='mani')#db = pyodbc.connect(r'Driver={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=C:\Mani\new\Ugam\User.accdb;')
        mycursor=db.cursor()
        sql="SELECT * FROM admin"
        mycursor.execute(sql)
        view_programmer=mycursor.fetchall()
        db.commit()
        db.close()
        return view_programmer

@app.route("/update_programmer_details",methods=['POST'])
def update_programmer_details():
    try:
        data=request.get_json()
        db = mysql.connector.connect(user='root',passwd='',host='localhost',database='mani')#db = pyodbc.connect(r'Driver={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=C:\Mani\new\Ugam\User.accdb;')
        mycursor=db.cursor()
        sql="UPDATE admin SET username='%s', password= '%s', role='%s' WHERE ID='%s'"%(data['u_emp_name'],data["u_emp_pass"],data["u_emp_role"],data["serial_no"])
        mycursor.execute(sql)
        db.commit()
        db.close()
        return jsonify({"result":"Success"});
    except Exception as e:
        foo()
        return jsonify({"result":str(e)})

@app.route("/delete_programmer_details",methods=["post"])
def delete_programmer_details():
    try:
        data=request.get_json()
        db = mysql.connector.connect(user='root',passwd='',host='localhost',database='mani')#db = pyodbc.connect(r'Driver={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=C:\Mani\new\Ugam\User.accdb;')
        mycursor=db.cursor()
        sql="DELETE FROM admin WHERE ID='%s'"%(data["serial_no"])
        mycursor.execute(sql)
        db.commit()
        db.close()
        return jsonify({"result":"Success"})
    except Exception as e:
        foo()
        return jsonify({"result":str(e)})

@app.route("/calculation_m", methods =['GET','POST'])
def calculation_m():
    data=request.get_json()
    if request.method == 'POST':
        if len(data["month"]) >0:
            c_year = data["month"][:4]
            c_month = data["month"][5:9]
            c_filter= "Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec".split()[int(c_month)-1] +"-"+ c_year
    else:
        now = datetime.datetime.now()
        last_month = now.month if now.month > 1 else 12
        last_year = now.year if now.month > 1 else now.year - 1
        c_filter = "%"+str(last_year)
    db = mysql.connector.connect(user='root',passwd='',host='localhost',database='mani')#db = pyodbc.connect(r'Driver={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=C:\Mani\new\Ugam\QA_Querysheet.accdb;')
    mycursor = db.cursor()
    if session["logged_in"]:
        if request.method == 'POST':
            sql ="SELECT phase, clarification, result, status,type FROM query_sheet WHERE qa_responsible ='%s' AND acm='%s'"%(session["username"], c_filter)
        else:
            sql ="SELECT phase, clarification, result, status,type FROM query_sheet WHERE qa_responsible ='%s' AND acm LIKE '%s'"%(session["username"], c_filter)
    elif session["logged_in_1"]:
        if request.method == 'POST':
            if len(data["month"])>0:
                sql ="SELECT phase, clarification, result, status,type FROM query_sheet WHERE acm='%s'" %(c_filter)
            if len(data["region"])>1:
                sql ="SELECT phase, clarification, result, status,type FROM query_sheet WHERE region='%s'"%(data["region"])
            if len(data["programmer"])>1:
                sql ="SELECT phase, clarification, result, status,type FROM query_sheet WHERE qa_responsible='%s'"%(data["programmer"])
            if len(data["region"])>1 and len(data["month"])>0:
                sql ="SELECT phase, clarification, result, status,type FROM query_sheet WHERE region='%s' AND acm='%s'"%(data["region"], c_filter)
            if len(data["programmer"])>1 and len(data["month"])>0:
                sql ="SELECT phase, clarification, result, status,type FROM query_sheet WHERE qa_responsible='%s' AND acm='%s'"%(data["programmer"], c_filter)
            if len(data["programmer"])>1 and len(data["region"])>1:
                sql ="SELECT phase, clarification, result, status,type FROM query_sheet WHERE qa_responsible='%s' AND region='%s'"%(data["programmer"], data["region"])
            if len(data["programmer"])>1 and len(data["region"])>1 and len(data["month"])>0:
                sql ="SELECT phase, clarification, result, status,type FROM query_sheet WHERE qa_responsible='%s' AND region='%s' AND acm='%s' "%(data["programmer"], data["region"],c_filter)
        else:
            sql ="SELECT phase, clarification, result, status,type FROM query_sheet WHERE acm LIKE '%s'"%(c_filter)
    mycursor.execute(sql)
    a = mycursor.fetchall()
    db.commit()
    db.close()
    error_acc_rating,suggition_acc_rating, Marker_acc_rating, logic_acc_rating, pm_acc_rating, client_acc_rating=0,0,0,0,0,0
    error_rej_rating, suggition_rej_rating,Marker_rej_rating, logic_rej_rating, pm_rej_rating, client_rej_rating=0,0,0,0,0,0
    error_cs_rating, suggition_cs_rating,Marker_cs_rating, logic_cs_rating, pm_cs_rating, client_cs_rating, open_count=0,0,0,0,0,0,0
    for i in a:
        if i[4] == "Ugam" and i[3] =="Open":open_count = open_count + 1
        if i[4] == "Ugam" and i[0] == "First link delivery" and i[3] =="Close":
            if i[2] == "Accepted":
                if (i[1]  == "Error"):
                    error_acc_rating = error_acc_rating +1
                if (i[1]  == "Suggestion"):
                    suggition_acc_rating = suggition_acc_rating +1
                if (i[1]  == "Question - Marker"):
                    Marker_acc_rating = Marker_acc_rating +1
                if (i[1]  == "Question - Logical"):
                    logic_acc_rating = logic_acc_rating +1
                if (i[1]  == "PM Confirmation Required"):
                    pm_acc_rating = pm_acc_rating +1
                if (i[1]  == "Clarification sheet point"):
                    client_acc_rating = client_acc_rating +1
            if (i[2] == "Rejected"):
                if (i[1]  == "Error"):
                    error_rej_rating = error_rej_rating +1
                if (i[1]  == "Suggestion"):
                    suggition_rej_rating = suggition_rej_rating +1
                if (i[1]  == "Question - Marker"):
                    Marker_rej_rating = Marker_rej_rating +1
                if (i[1]  == "Question - Logical"):
                    logic_rej_rating = logic_rej_rating +1
                if (i[1]  == "PM Confirmation Required"):
                    pm_rej_rating = pm_rej_rating +1
                if (i[1]  == "Clarification sheet point"):
                    client_rej_rating = client_rej_rating +1
            if (i[2] == "Client / Spec"):
                if (i[1]  == "Error"):
                    error_cs_rating = error_cs_rating +1
                if (i[1]  == "Suggestion"):
                    suggition_cs_rating = suggition_cs_rating +1
                if (i[1]  == "Question - Marker"):
                    Marker_cs_rating = Marker_cs_rating +1
                if (i[1]  == "Question - Logical"):
                    logic_cs_rating = logic_cs_rating +1
                if (i[1]  == "PM Confirmation Required"):
                    pm_cs_rating = pm_cs_rating +1
                if (i[1]  == "Clarification sheet point"):
                    client_cs_rating = client_cs_rating +1
    bar_error_rating, bar_suggition_rating, bar_Marker_rating, bar_logic_rating, bar_pm_rating, bar_client_rating, error_doughnut, sugition_doughnut, Marker_doughnut, logic_doughnut, pm_rating, client_doughnut, bar_chart, tt = 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
    total_result, error_acc, error_rej, error_cs, suggition, Marker, logic, pm, client =0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0
    bar_error_rating = error_acc_rating + error_rej_rating + error_cs_rating
    bar_suggition_rating = suggition_acc_rating + suggition_rej_rating + suggition_cs_rating
    bar_Marker_rating = Marker_acc_rating + Marker_rej_rating + Marker_cs_rating
    bar_logic_rating = logic_acc_rating + logic_rej_rating + logic_cs_rating
    bar_pm_rating = pm_acc_rating + pm_rej_rating + pm_cs_rating
    bar_client_rating = client_acc_rating + client_rej_rating + client_cs_rating
    tt = bar_error_rating +  bar_suggition_rating + bar_Marker_rating + bar_logic_rating + bar_pm_rating + bar_client_rating
    if tt > 0:
        error_acc = round((error_acc_rating / tt) * 100)
        error_rej = round((error_rej_rating / tt) * 100)
        error_cs = round((error_cs_rating / tt) * 100)
        suggition= round((bar_suggition_rating / tt) * 100)
        Marker = round((bar_Marker_rating / tt) * 100)
        logic = round((bar_logic_rating / tt) * 100)
        pm = round((bar_pm_rating / tt) * 100)
        client = round((bar_client_rating / tt) * 100)
    bar_chart = [{'error_acc':error_acc}, {'error_rej':error_rej}, {'error_cs':error_cs},{'suggition':suggition},{'Marker':Marker}, {'logic':logic},{'pm':pm},{'client':client}, {'open':open_count}]
    if bar_error_rating>0:
        error_acc_rating     = (error_acc_rating/bar_error_rating) * 100
        error_rej_rating     = (error_rej_rating/bar_error_rating) * 100
        error_cs_rating      = (error_cs_rating/bar_error_rating) * 100
    if bar_suggition_rating>0:
        suggition_acc_rating     = (suggition_acc_rating  / bar_suggition_rating) * 100
        suggition_rej_rating     = (suggition_rej_rating /  bar_suggition_rating) * 100
        suggition_cs_rating      = (suggition_cs_rating / bar_suggition_rating) * 100
    if bar_Marker_rating>0:
        Marker_acc_rating     = (Marker_acc_rating  / bar_Marker_rating) * 100
        Marker_rej_rating     = (Marker_rej_rating /  bar_Marker_rating) * 100
        Marker_cs_rating      = (Marker_cs_rating / bar_Marker_rating) * 100 
    if bar_logic_rating>0:
        logic_acc_rating     = (logic_acc_rating  / bar_logic_rating) * 100
        logic_rej_rating     = (logic_rej_rating /  bar_logic_rating) * 100
        logic_cs_rating      = (logic_cs_rating / bar_logic_rating) * 100
    if bar_pm_rating>0:
        pm_acc_rating     = (pm_acc_rating  / bar_pm_rating) * 100
        pm_rej_rating     = (pm_rej_rating /  bar_pm_rating) * 100
        pm_cs_rating      = (pm_cs_rating / bar_pm_rating) * 100
    if bar_client_rating>0:
        client_acc_rating     = (client_acc_rating  / bar_client_rating) * 100
        client_rej_rating     = (client_rej_rating /  bar_client_rating) * 100
        client_cs_rating      = (client_cs_rating / bar_client_rating) * 100
    error_doughnut    = [{'error_acc_rating':error_acc_rating},{'error_rej_rating':error_rej_rating},{'error_cs_rating':error_cs_rating}]
    sugition_doughnut = [{'suggition_acc_rating':suggition_acc_rating},{'suggition_rej_rating':suggition_rej_rating},{'suggition_cs_rating':suggition_cs_rating}]
    Marker_doughnut   = [{'Marker_acc_rating':Marker_acc_rating},{'Marker_rej_rating':Marker_rej_rating},{'Marker_cs_rating':Marker_cs_rating}]
    logic_doughnut    = [{'logic_acc_rating':logic_acc_rating},{'logic_rej_rating':logic_rej_rating},{'logic_cs_rating':logic_cs_rating}]
    pm_rating         = [{'pm_acc_rating':pm_acc_rating},{'pm_rej_rating':pm_rej_rating},{'pm_cs_rating':pm_cs_rating}]    
    client_doughnut   = [{'client_acc_rating':client_acc_rating},{'client_rej_rating':client_rej_rating},{'client_cs_rating':client_cs_rating}]
    total_result = [bar_chart,error_doughnut,sugition_doughnut, Marker_doughnut, logic_doughnut, pm_rating,client_doughnut]
    return jsonify({'result': total_result})

@app.route("/mainpage",methods=['GET'])
def mainpage():
    try:
        if session["logged_in"]:
            return render_template("main_page/mainpage.html", data = result)
        else:
            return render_template("index.html")
    except Exception as e:
        foo()
        return redirect(url_for("index"))

@app.route("/mainpage_ad",methods=['GET', 'POST'])
def mainpage_ad():
    try:
        if session["logged_in_1"]:
            result = programmer_view()
            return render_template("main_page/mainpage_ad.html", data = result)
        else:
            return render_template("index_ad.html")
    except Exception as e:
        foo()
        return redirect(url_for("index_ad"))

@app.route("/programmer_ad")
def programmer_ad():
    try:
        if session["logged_in_1"]:
            return render_template("query_table/programer_ad.html")
        else:
            return render_template("index_ad.html")
    except KeyError:    
        foo()
        return redirect(url_for("index_ad"))

@app.route("/view")
def view():
    try:
        if session["logged_in_1"]:
            result = programmer_view()
            return render_template("view_details/programmer_details.html",data=result)
        else:
            return render_template("index_ad.html")
    except KeyError:    
        foo()
        return redirect(url_for("index_ad"))

@app.route("/table_view" )
def table_view():
    try:
        if session["logged_in"]:
            return render_template("table_view/table_view.html")
        else:
            return render_template("index.html")
    except KeyError:
        foo()
        return redirect(url_for("index"))

@app.route("/table_view_AD" )
def table_view_AD():
    try:
        if session["logged_in_1"]:
            return render_template("table_view/table_view_AD.html")
        if session["logged_in_SW"]:
            return render_template("table_view/table_view_SW.html")
        else:
            return render_template("index_ad.html")
    except Exception as e:
        foo()
        return redirect(url_for("index_ad"))


@app.route("/create_api")
def create_api():
    try:
        if session["logged_in"]:
            return render_template("createapi.html")
        else:
            return render_template("index.html")
    except KeyError:
        foo()
        return redirect(url_for("index"))

@app.route("/query_table")
def quer_table():
    try:
        if session["logged_in"]:
            result = programmer_view()
#            print(result)
            return render_template("query_table/query_table.html", data= result)
        else:
            return render_template("index.html")
    except KeyError:
            foo()
            return redirect(url_for("index"))

details, RDG,z =[], {}, []
@app.route("/RDG_limt", methods=['post'])
def RDG_limit():
    try:
        data=request.get_json()
        details = []
        print(data)
        db = mysql.connector.connect(user='root',passwd='',host='localhost',database='mani')#db = pyodbc.connect(r'Driver={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=C:\Mani\new\Ugam\User.accdb;')
        mycursor = db.cursor()
        sql = "SELECT sid,project_number, region, type, rdg_limitation, rdg_version, qa_limitation FROM query_sheet WHERE sid='%s'"%(data["sid"])
        mycursor.execute(sql)
        details = mycursor.fetchall()
        db.commit()
        db.close()
        RDG, z={}, []
        for i in details:
            RDG = dict(enumerate(i))
            z.append(RDG)
        if len(z)>0:
            return jsonify({"results":z})
    except Exception as e:
        return jsonify({"results":str(e)})

@app.route("/add_query", methods=['post'])
def add_query():
    try:
        data=request.get_json()
        db = mysql.connector.connect(user='root',passwd='',host='localhost',database='mani')#db = pyodbc.connect(r'Driver={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=C:\Mani\new\Ugam\User.accdb;')
        mycursor=db.cursor()
        date = datetime.datetime.now()
        year  = date.year
        month = date.month
        for month_idx in range(1, 13):
            if month_idx == month:
                month = calendar.month_abbr[month_idx]
        acm = str(month)+"-"+str(year)
        sql = "INSERT INTO query_sheet (sid, region, type, query_no, query_categories, query_description, serial, clarification,result,explain1,phase,rdg_version, qa_responsible, status, sw_responsible, acm, project_number, rdg_limitation, qa_limitation) VALUES ('%s', '%s', '%s', '%s', '%s', '%s','%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s')" %(data["sid"],data["region"],data["project_type"], data["q_no"],data["q_category"],data["q_description"],data["sample_id"],data["clarification"],data["result"], " " ,data["phase"],data["rdg_version"],session["username"],data["status"],data["sw_responsible"],acm, data["project_number"], data["SW_RDG1"], data["QA_RDG1"])
        mycursor.execute(sql)
        sql = "UPDATE  query_sheet SET project_number = '%s', region='%s' WHERE sid='%s'"%(data["project_number"], data["region"], data["sid"])
        mycursor.execute(sql)
        db.commit()
        db.close()
        return jsonify({"results":"Success"})
    except Exception as e:
        foo()
        return jsonify({"results":str(e)})

details=[]
@app.route("/view_details_by_sid", methods=['post'])
def view_details_by_sid():
    try:
        global details
        data=request.get_json()
        db = mysql.connector.connect(user='root',passwd='',host='localhost',database='mani')#db = pyodbc.connect(r'Driver={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=C:\Mani\new\Ugam\User.accdb;')
        mycursor=db.cursor()
        sql="SELECT * FROM query_sheet WHERE sid='%s'"%(data["sid"])
        mycursor.execute(sql)
        details=mycursor.fetchall()
        db.commit()
        db.close()
        if len(details)>0:
            return jsonify({"result":details})
    except Exception as e:
        foo()
        return jsonify({"result":str(e)})

details=[]
@app.route("/view_details_by_sid_ad", methods=['post'])
def view_details_by_sid_ad():
    try:
        global details
        data=request.get_json()
        print(data)
        db = mysql.connector.connect(user='root',passwd='',host='localhost',database='mani')#db = pyodbc.connect(r'Driver={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=C:\Mani\new\Ugam\User.accdb;')
        mycursor=db.cursor()
        if len(data["sid"])>0:
            if len(data["sid"])>15:
                val1 =data["sid"]
                val2 =val1[:15]+"%"
                sql="SELECT * FROM query_sheet WHERE project_number LIKE '%s'"%(val2)
            else:
                sql="SELECT * FROM query_sheet WHERE project_number='%s'"%(data["sid"])
        if len(data["region"])>0:
            sql="SELECT * FROM query_sheet WHERE region='%s'"%(data["region"] )
        if len(data["start"])>0:
            sql="SELECT * FROM query_sheet WHERE  date>='%s' AND date<='%s'"%(str(data["start"]), (str(data["end"]+" 23:59:59.998")))
        if len(data["start"])>0 and len(data["end"])>0 and len(data["region"])>0:
            sql="SELECT * FROM query_sheet WHERE  date>='%s' AND date<='%s' AND region='%s'"%( str(data["start"]), (str(data["end"]+" 23:59:59.998")), data["region"])
        if len(data["sid"])>0 and len(data["start"])>0 and len(data["end"])>0 and len(data["region"])>0:
            sql="SELECT * FROM query_sheet WHERE project_number='%s'  AND date>='%s' AND date<='%s' AND region='%s'"%(data["sid"],  str(data["start"]), (str(data["end"]+" 23:59:59.998")), data["region"])
        mycursor.execute(sql)
        details=mycursor.fetchall()
        db.commit()
        db.close()
        if len(details)>0:
            return jsonify({"result":details})
    except Exception as e:
#        print(e)
        foo()
        return jsonify({"result":str(e)})

details=[]
@app.route("/QA_Query_details/<int:sid>")
def get_details_by_sid(sid):
    try:
        global details
        db = mysql.connector.connect(user='root',passwd='',host='localhost',database='mani')#db = pyodbc.connect(r'Driver={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=C:\Mani\new\Ugam\User.accdb;')
        mycursor=db.cursor()
        sql="SELECT * FROM query_sheet WHERE sid='%s'"%(str(sid))
        mycursor.execute(sql)
        details=mycursor.fetchall()
        #print(details)
        return render_template("api_show_html_table/api_show_html_table.html",data=details)
    except Exception as e:
        foo()
        return jsonify({"result":str(e)})

@app.route("/view_details")
def view_details():
    try:
        if session["logged_in"]:
            data1 = programmer_view()
            return render_template("view_details/view_details.html",data=details, result = data1)
        else:
            return render_template("index.html")
    except KeyError:
        foo()
        return redirect(url_for("index"))

@app.route("/view_details_ad")
def view_details_ad():
    try:
        if session["logged_in_1"]:
            view = programmer_view()
            return render_template("view_details/view_details_AD.html",data=details, result=view)
        if session["logged_in_SW"]:
            return render_template("view_details/view_details_SW.html",data=details)
        else:
            return render_template("index_ad.html")
    except KeyError:
        foo()
        return redirect(url_for("index_ad"))

update_sid =""
@app.route("/new_view_details_by_sid")
def new_view_details_by_sid():
    try:
        if session["logged_in"] or session["logged_in_1"]:
            try:
                global update_sid
                db = mysql.connector.connect(user='root',passwd='',host='localhost',database='mani')#db = pyodbc.connect(r'Driver={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=C:\Mani\new\Ugam\User.accdb;')
                mycursor=db.cursor()
                sql="SELECT * FROM query_sheet WHERE sid='%s'"%(update_sid)
                mycursor.execute(sql)
                details=mycursor.fetchall()
                view = programmer_view()
                if session["logged_in_1"]:
                    return render_template("view_details/view_details_AD.html",data=details, result=view)
                elif session["logged_in"]:
                    return render_template("view_details/view_details.html",data=details, result =view)
                elif not session["logged_in"] :
                    return render_template("index.html")
                elif not session["logged_in_1"]:
                    return render_template("index_ad.html")
            except Exception as e:
                return jsonify({"result":str(e)})
    except KeyError:
        foo()
        return redirect(url_for("index"))

@app.route("/update_query_details",methods=["post"])
def update_query_details():
    try:
        global update_sid
        data=request.get_json()
#        if data["status"]=="Open":
        explain1 = data["explain1"] + "("
        explain2 = session["username"]+"):\t"
        response = data["explain2"]
        new = "\n"
        explain = explain1 + explain2+response+new
        db = mysql.connector.connect(user='root',passwd='',host='localhost',database='mani')#db = pyodbc.connect(r'Driver={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=C:\Mani\new\Ugam\User.accdb;')
        mycursor=db.cursor()
        if len(data)==15:
            sql='''UPDATE query_sheet SET  sid='%s', query_no='%s', query_categories='%s', query_description='%s', serial='%s', clarification='%s', result='%s', explain1='%s', phase='%s', rdg_version='%s', qa_responsible='%s', status='%s', sw_responsible='%s' WHERE s_no='%s' '''%(data["sid"], data["query_no"], data["quert_categories"], data["query_description"], data["serial"], data["clarification"], data["result"], explain, data["phase"], data["version"], data["responsible"], data["status"], data["sw_responsible"], data["serial_no"])
        elif len(data)>15:
            sql='''UPDATE query_sheet SET  sid='%s', project_number='%s', region='%s', type='%s', query_no='%s', query_categories='%s', query_description='%s', serial='%s', clarification='%s', result='%s', explain1='%s', phase='%s', rdg_version='%s', qa_responsible='%s', status='%s', sw_responsible='%s' WHERE s_no='%s' '''%(data["sid"], data["project_number"], data["region"], data["project_type"], data["query_no"], data["quert_categories"], data["query_description"], data["serial"], data["clarification"], data["result"], explain, data["phase"], data["version"], data["responsible"], data["status"], data["sw_responsible"], data["serial_no"])
        update_sid=data["sid"]
        mycursor.execute(sql)
        if data["status"] == "Close":
            now = datetime.datetime.now()
            data_date = "("+session["username"]+"):\t"+str(now)+"\t"
            sql1='''UPDATE query_sheet SET  close_data='%s'  WHERE s_no='%s' '''%(data_date, data["serial_no"])
            mycursor.execute(sql1)
        db.commit()
        db.close()
        return jsonify({"result":"Success"})
    except Exception as e:
        foo()
        return jsonify({"result":str(e)})

@app.route("/updateSW_query_details",methods=["post"])
def updateSW_query_details():
    try:
        global update_sid
#        name = getpass.getuser()
        data=request.get_json()
        frist = data["explain1"]
        new = "\n"
        second = data["explain2"]
        ex = frist + new + second + new
        db = mysql.connector.connect(user='root',passwd='',host='localhost',database='mani')#db = pyodbc.connect(r'Driver={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=C:\Mani\new\Ugam\User.accdb;')
        mycursor=db.cursor()
        sql='''UPDATE query_sheet SET sid= '%s', clarification='%s', result='%s', explain1='%s', sw_responsible='%s' WHERE s_no='%s' '''%(data["sid"],data["clarification"],data["result"],ex,data["sw_responsible"],data["serial_no"])
        update_sid=data["sid"]
        mycursor.execute(sql)
        db.commit()
        db.close()
        return jsonify({"result":"Success"})
    except Exception as e:
        foo()
        return jsonify({"result":str(e)})

@app.route("/delete_query_details",methods=["post"])
def delete_query_details():
    try:
        data=request.get_json()
        global update_sid
        update_sid =data["sid"]
        print(data["sid"], data["serial_no"])
        db = mysql.connector.connect(user='root',passwd='',host='localhost',database='mani')#db = pyodbc.connect(r'Driver={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=C:\Mani\new\Ugam\User.accdb;')
        mycursor=db.cursor()
        sql="DELETE FROM query_sheet WHERE s_no='%s'"%(data["serial_no"])
        mycursor.execute(sql)
        db.commit()
        db.close()
        return jsonify({"result":"Success"})
    except Exception as e:
        foo()
        return jsonify({"result":str(e)})

@app.route("/update_status", methods=['post'])
def update_status():
	try:
		data = request.get_json()
		print(data)
		date = "("+session["username"]+"):  " + str(datetime.datetime.now())
		db = mysql.connector.connect(user='root',passwd='',host='localhost',database='mani')#db = pyodbc.connect(r'Driver={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=C:\Mani\new\Ugam\User.accdb;')
		mycursor=db.cursor()
#		sql = " SELECT sid, note from query_sheet WHERE sid='%s'"%(data['sid'])
#		mycursor.execute(sql)
#		a = mycursor.fetchone()
#		ans = a[1]+"("+session["username"]+"): " + data['note']+"\n"
#		ans = "("+session["username"]+"): " + data['note']+"\n"
#		print(ans)
#		mani = db.cursor()
		if (data["study_status"] == 'PM / Clarification pending'):
			sql='''UPDATE query_sheet SET study_status="%s", PM="%s" WHERE sid="%s"'''  %(data['study_status'], date, data["sid"])
		elif (data["study_status"] == 'RDG sign off'):
			sql='''UPDATE query_sheet SET study_status="%s", RDG="%s" WHERE sid="%s"''' %(data['study_status'], date, data["sid"])
		elif (data["study_status"] == 'Live sign off'):
			sql='''UPDATE query_sheet SET study_status="%s", live="%s" WHERE sid="%s"'''%(data['study_status'], date, data["sid"])
		elif (data["study_status"] == 'FDC sign off'):
			sql='''UPDATE query_sheet SET study_status="%s", FDC="%s" WHERE sid="%s"''' %(data['study_status'], date, data["sid"])
		mycursor.execute(sql)
		db.commit()
		db.close()
		return jsonify({"results":"Success"})
	except Exception as e:
		foo()
		print(e)
		return jsonify({"results":str(e)})
mani, mani_1= [], []
@app.route("/study_status", methods=['post'])
def study_status():
	try:
		global mani
		global mani_1
		data = request.get_json()
		print(data)
		db = mysql.connector.connect(user='root',passwd='',host='localhost',database='mani')#db = pyodbc.connect(r'Driver={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=C:\Mani\new\Ugam\User.accdb;')
		mycursor=db.cursor()
		if session["logged_in"]:
			s_s = 'Live sign off'
			sql	= " SELECT sid, study_status, project_number, region from query_sheet WHERE region ='%s' AND study_status = '%s'"%(data['BU'], s_s)
			mycursor.execute(sql)
			mani = mycursor.fetchall()
			mani_1 = []
			for i in mani:
				if i not in mani_1:
					mani_1.append(i)
			print(mani_1)
		elif session["logged_in_1"]:
			if len(data['BU'])>1: #and len(data['study_status'])>1:
				sql	= " SELECT sid, study_status, project_number, region, PM, RDG, Live, FDC from query_sheet WHERE region ='%s'"%(data['BU'])
#			elif len(data['BU'])>1:
#				sql	= " SELECT sid, study_status, project_number, region, PM, RDG, Live, FDC from query_sheet WHERE region ='%s'"%(data['BU'])
			elif len(data['study_status'])>1:
				sql	= " SELECT sid, study_status, project_number, region, PM, RDG, Live, FDC from query_sheet"
			mycursor.execute(sql)
			mani = mycursor.fetchall()
			mani_1 = []
			for i in mani:
				if data['study_status'] == 'PM / Clarification pending' and len(i[4])>0:
					if i not in mani_1:
						mani_1.append(i)
				elif data['study_status'] == 'RDG sign off' and len(i[5])>0:
					if i not in mani_1:
						mani_1.append(i)
				elif data['study_status'] == 'Live sign off' and len(i[6])>0:
					if i not in mani_1:
						mani_1.append(i)
				elif data['study_status'] == 'FDC sign off' and len(i[7])>0:
					if i not in mani_1:
						mani_1.append(i)
				elif data['study_status'] == '':
					if i not in mani_1:
						mani_1.append(i)

		db.commit()
		db.close()
		if len(mani_1)>0:
			return jsonify({"result":mani_1})

	except Exception as e:
		return jsonify({"result":str(e)})

@app.route("/study_view")
def study_view():
	try:
		if session["logged_in"]:
			return render_template("table_view/study_view.html")
		elif session["logged_in_1"]:
			return render_template("table_view/study_view_AD.html")
		else:
			return render_template("index.html")
	except KeyError:
		return redirect(url_for("index"))

@app.route("/study_status_view")
def study_status_view():
	try:
		if session["logged_in"]:
			return render_template("view_details/study_status.html",data=mani_1)
		elif session["logged_in_1"]:
			return render_template("view_details/study_status_AD.html",data=mani_1)
		else:
			return render_template("index.html")
	except KeyError:
		return redirect(url_for("index"))

if __name__== '__main__':
    formatter = logging.Formatter("[%(asctime)s] {%(pathname)s:%(lineno)d} %(levelname)s - %(message)s")
    handler = RotatingFileHandler("Mani_Ugam.log", maxBytes=10000000, backupCount=5)
    handler.setLevel(logging.DEBUG)
    handler.setFormatter(formatter)
    app.logger.addHandler(handler)
    app.run(host='10.16.6.76', port=8080, debug=True)#app.run(debug=True)