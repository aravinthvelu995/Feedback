$(document).ready(function () {
   var col15;
    $('#sidebarCollapse').on('click', function () {
        $('#sidebar').toggleClass('active');
    });
    $("#showdropdown").on('click', function () {
        window.location.replace("/logout")
    });
    $("#search").on("click", function() {
                var value = $(this).val();
                   $("#customershowbychitid1 tr").filter(function() {
                   $(this).toggle($(this).text().indexOf(value) > -1)
                });
    });

$(window).on("load resize ", function() {
  var scrollWidth = $('.tbl-content').width() - $('.tbl-content table').width();
  $('.tbl-header').css({'padding-right':scrollWidth});
}).resize();

    $('.table tbody').on('click','.btns',function(){
        var currow =$(this).closest('tr');
        var  col1=currow.find('td:eq(0)').text();
        var  col2=currow.find('td:eq(1)').text();
        var  col3=currow.find('td:eq(2)').text();
        var  col4=currow.find('td:eq(3)').text();
        var  col5=currow.find('td:eq(4)').text();
        var  col6=currow.find('td:eq(5)').text();
        var  col7=currow.find('td:eq(6)').text();
        var  col8=currow.find('td:eq(7)').text();
        var  col9=currow.find('td:eq(8)').text();
        var  col10=currow.find('td:eq(9)').text();
        var  col11=currow.find( 'td:eq(10)').text();
        var  col12=currow.find('td:eq(11)').text();
        var  col13=currow.find('td:eq(12)').text();
        var  col14=currow.find('td:eq(13)').text();
        col15=currow.find('td:eq(14)').text();
        var  col16=currow.find('td:eq(15)').text();
        var  col17=currow.find('td:eq(16)').text();
        var  col18=currow.find('td:eq(17)').text();    
        projec_number=currow.find('td:eq(20)').text();    
		if (col15 == "Open"){
			$("#serial_no").val(col1);
			$("#serial_no").attr("disabled", "disabled");
			$("#sid").val(col2);
			$("#sid").attr("disabled", "disabled");
			$("#query_no").val(col4);
			$("#query_no").attr("disabled", "disabled"); 
			$("#quert_categories").val(col6);
//			$("#quert_categories").attr("disabled", "disabled"); 		
			$("#query_description").val(col7);
			$("#query_description").attr("disabled", "disabled");
			$("#serial").val(col8);
			$("#clarification").val(col9);
			$("#clarification").attr("disabled", "disabled"); 
			$("#result").val(col10);    
			$("#explain1").val(col11);
			$("#explain1").attr("disabled", "disabled"); 
			$("#phase").val(col12);
			$("#version").val(col13);
			$("#responsible").val(col14);
			$("#status").val(col15);
			$("#responsible").attr("disabled", "disabled");
			$("#sw_responsible").val(col16);
		   if (col15 == "Close"){
				$("#explain2").attr("disabled", "disabled"); 
			}
	}
	if (col15 == "Close"){
			$("#serial_no").val(col1);
			$("#serial_no").attr("disabled", "disabled");
			$("#sid").val(col2);
			$("#sid").attr("disabled", "disabled");
			$("#query_no").val(col4);		
			$("#query_no").attr("disabled", "disabled"); 
			$("#quert_categories").val(col6);
			$("#quert_categories").attr("disabled", "disabled"); 		
			$("#query_description").val(col7);
			$("#query_description").attr("disabled", "disabled");
			$("#serial").val(col8);
			$("#serial").attr("disabled", "disabled");
			$("#clarification").val(col9);
			$("#clarification").attr("disabled", "disabled"); 
			$("#result").val(col10);    
			$("#result").attr("disabled", "disabled");
			$("#explain1").val(col11);
			$("#explain1").attr("disabled", "disabled"); 
			$("#phase").val(col12);
			$("#phase").attr("disabled", "disabled");
			$("#version").val(col13);
			$("#version").attr("disabled", "disabled");
			$("#responsible").val(col14);
			$("#responsible").attr("disabled", "disabled");
			$("#status").val(col15);				
			$("#sw_responsible").val(col16);
			$("#sw_responsible").attr("disabled", "disabled");
		   if (col15 == "Close"){
				$("#explain2").attr("disabled", "disabled"); 
			}
	}
      if (col11 != ""){
		$("#delete").attr("disabled" , "disabled" );
	  } 
    });

	$("#update").on('click',function(){
		var coll15 = document.getElementById("status").value;
	if 	(col15 == "Open"){
		var  ex = document.getElementById("explain2").value;
		if (ex.trim() == "") {
			document.getElementById('ex').innerHTML = "please enter the responseText";
		}
		
		if 	(ex.length > 1) { 
			var obj={"sid":$("#sid").val(),
			"serial_no":$("#serial_no").val(),        
			"query_no": $("#query_no").val(),
			"quert_categories":$("#quert_categories").val(),
			"query_description":$("#query_description").val(),
			"serial":$("#serial").val(),
			"clarification": $("#clarification").val(),
			"result": $("#result").val(),
			"explain1":$("#explain1").val(),
			"explain2":ex,
			"phase": $("#phase").val(),
			"version": $("#version").val(),
			"responsible": $("#responsible").val(),
			"status": $("#status").val(),
			"sw_responsible": $("#sw_responsible").val()}

			$.ajax({
				type:"post",
				url:"/update_query_details",
				contentType:"application/json",
				data:JSON.stringify(obj),
				dataType:"json",
				success:function(results){
					var result =JSON.parse(JSON.stringify(results))
						if(result['result']=='Success'){ 
							window.location.replace('/new_view_details_by_sid')
						}
						else{
							alert(result['result'])
						}
					}
				});


				var form_data =new FormData($('#upload-file')[0])
				$.ajax({
                        type: 'POST',
                        url: '/uploadexcel',
                        data: form_data,
                        contentType: false,
                        cache: false,
                        processData: false,
                        async: false,
                        success: function(data) {
                        alert(data)
                        },  
                    });
		}
	}
	if 	(col15 == "Close"){
			var example1 = $("#explain1").val();
			var obj={"sid":$("#sid").val(),
			"serial_no":$("#serial_no").val(),        
			"query_no": $("#query_no").val(),
			"quert_categories":$("#quert_categories").val(),
			"query_description":$("#query_description").val(),
			"serial":$("#serial").val(),
			"clarification": $("#clarification").val(),
			"result": $("#result").val(),
			"explain1": example1.trim(),
			"explain2":"had open query",
			"phase": $("#phase").val(),
			"version": $("#version").val(),
			"responsible": $("#responsible").val(),
			"status": $("#status").val(),
			"sw_responsible": $("#sw_responsible").val()}
			$.ajax({
				type:"post",
				url:"/update_query_details",
				contentType:"application/json",
				data:JSON.stringify(obj),
				dataType:"json",
				success:function(results){
					var result =JSON.parse(JSON.stringify(results))
						if(result['result']=='Success'){ 
							window.location.replace('/new_view_details_by_sid')
						}
						else{
							alert(result['result'])
						}
					}
				});
	}
        });

        $('.table tbody').on('click','.btnn',function(){
            var currow =$(this).closest('tr');
            var  col1=currow.find('td:eq(1)').text();
            var  col4=currow.find('td:eq(0)').text();
            $("#sid").val(col1);
            $("#serial_no").val(col4);
        });

        $("#yesDelete").on('click',function(){
            var obj={"sid":$("#sid").val(),"serial_no":$("#serial_no").val(),}
            $.ajax({
                type:"post",
                url:"/delete_query_details",
                contentType:"application/json",
                data:JSON.stringify(obj),
                dataType:"json",
                success:function(results){
                    var result =JSON.parse(JSON.stringify(results))
                        if(result['result']=='Success'){
                            window.location.replace('/new_view_details_by_sid')
                        }
                        else{
                            alert(result['result'])
                        }
                }
				});
        });

    $('#createapi').on('click', function () {
        var address="http://10.16.6.76:8080/QA_Query_details/"
        var sid = $('#customershowbychitid tr:nth-child(1) td:nth-child(1)').text();
        var api=address+""+sid
        $("#api_textbox").val(api);
        document.getElementById("API").innerHTML = api;
    });

 $("#Excel_Sheet").click(function () {
	 var project_number = $('#customershowbychitid tr:nth-child(0) td:nth-child(2)').text();
					 $("#datatocsvtable").tableToCSV({
						separator:',',
						newline:'\n',
						 quoteFields:true,
                        filename:$('#customershowbychitid tr:nth-child(0) td:nth-child(2)').text()
                    });
        });

$("#add_status").on('click',function(){
	var  SID = $('#customershowbychitid tr:nth-child(1) td:nth-child(1)').text();
		var  ex = document.getElementById("study_status").value;
//		if (ex.trim() == "") {
//			document.getElementById('ex_note').innerHTML = "please enter the Note";
//		}
		
		if(ex != "0") { 
			var obj={"sid":SID,
			"study_status":$("#study_status").val(),
//			"note":$("#note").val(),
			}
		
			$.ajax({
					type:"post",
					url:"/update_status",
					contentType:"application/json",
					data:JSON.stringify(obj),
					dataType:"json",
					success:function(result){
						var answer =JSON.parse(JSON.stringify(result))
							if(answer['result']=='Success'){ 
								swal ( "Status Updated Successfully... " ,  'Done.' ,  "success" )
							}
							else{
								alert(answer['result'])
							}
						},
                error: function (jqXHR, exception) {
                    var msg = '';
                    if (jqXHR.status === 0) {
                        msg = 'Not connect.\n Verify Network.';
                    } else if (jqXHR.status == 404) {
                        msg = 'Requested page not found. [404]';
                    } else if (jqXHR.status == 500) {
                        msg = 'Invalite SID';
                    } else if (exception === 'parsererror') {
                        msg = 'Requested JSON parse failed.';
                    } else if (exception === 'timeout') {
                        msg = 'Time out error.';
                    } else if (exception === 'abort') {
                        msg = 'Ajax request aborted.';
                    } else {
                        msg = 'Uncaught Error.\n' + jqXHR.responseText;
                    }
                    alert(msg);
                }
				});
		}
	else{
		alert("Please select fillter");
	}

	});
});