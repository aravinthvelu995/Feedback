$(document).ready(function () {

    function getSelectValue(){
							
        var  SV=document.getElementById("q_category").value;
        var Inp;
        Inp="";
        //console.log(SV);
        //console.log(Inp);	
        if (SV == "Skip/Logic- Missing data(With filter)"){
                Inp="We see ### respondent are going blank at QXXX even though theyqualify below condition.(Filter as per Qre) kindly check;";
        }
        if (SV=="Skip-Logic -Missing data(Ask All)"){	
                Inp="We see ### respondent are going blank at QXXX even though there is no filter for this question. kindly check";
        }
        if (SV =="Skip/Logic-Extra data"){
                Inp="We see ### respondent are having data at QXXX even though they do not qualify to answer this question as per below condition.(Condition as per Qre)";
        }
        if (SV == "Script/Questionaire Mismatch"){
                Inp="We see ### respondent are having data at this QXXX which is out of range.Range should be Min to Max as per condition xxx given in Questionnaire.  (Condition as per Qre) Kindly check.";
        }
        if (SV == "Incoreect Termination - Should not have termed"){
                Inp="We see ### respondent who should terminate at question QXXX as per below but are not terminatating at this question. (TERM CONDITION as per Qre) Kindly check.";
        }
        if (SV == "Incorrect Termination - Should have termed"){
                Inp = "We see ### respondent who do not qualify below condition are terminating here. (TERM CONDITIONN as per Qre) Kindly let us know the reson for this?";
        }
        if (SV == "Skip/Logic - Missing data (OE)"){
                Inp = "a. We see ### respondent going blank here even though there is no filter b.We see ### respondent going blank here even though they qualify spefic condition (Condition as per Qre) kindly check";
        }
        if (SV == "Quota - extra data"){
                Inp = "We see ###respondent who do not  qualify in Cell XXX of this quota but  still are getting marked in that cell.Could you please let us know the reason for this?  EX: Give 1 e.g with cell logic";
        }
        if (SV == "Quota -Missing data"){
                Inp = "We see ### respondents who qualify in Cell XXX of this quota but still are not getting marked in that cell. Could you please let know the reason for this?  Ex. Given 1 e.g with cell logic";
        }
        if (SV == "Screening Table Mismatch"){
                Inp = "We see ### respondents who should terminate at question QXXX as per below condition but are termination at question QXXX. could you please let us know the reson for this?   TREM CONDITION";
        }
        if (SV == "OverQuota"){
                Inp = "Case 1: We see respondents are gotting marked as overquota at cell XXX of Quota QXXX.    we checked rhe target for that cell in OSF is already yet MET    Case 2: We see respondents are not gotting marked as overquota at cell XXX of Quota QXXX.    we checked rhe target or that cell in OSF is already yet MET ";
        }
        if (SV == "Incorrect calculation"){
                Inp = "We see this marker is holding invalid value. Ex. given 1 e.g with logic.";
        }
        if (SV == "Missing attribute / responses"){
                Inp = "We see this question is having an option XXX in Questionnaire but the response is missing in MDD";
        }
        if (SV == "Missing question"){
                Inp = "We see this question is present in Questionnaire but it is missing in MDD";
        }
        if (SV == "Randomizzation issues"){
                Inp = "We see as per Questionnaire, responses / attributes needs to be randomized but there is no ran / rot keyword in MDD.  Colud you please check and confirm; if its randomized? ";
        }
        if (SV == "Standard"){
                Inp = "please update XXX ";
        }
        if (SV == "Incorrect question type"){
                Inp = "We see this question should be single/ multi/ numeric/ openend as per the questionnaire but it is not made of that type in MDD. Kindly check.";
        }
        if (SV == "Incorrect text"){
                Inp = "we see textual Mismatch at this question. Text in MDD = XXX   Text in Questionnaire = XXX";
        }
        if (SV == "Least fill counts"){
                Inp = "We see least fill/ random counts are not matching . Ex. Given some e.g. of particulare brands";
        }		
        document.getElementById('q_description').value = Inp; 
    }


    $('#sidebarCollapse').on('click', function () {
        $('#sidebar').toggleClass('active');
    });

    $("#showdropdown").on('click', function () {
        window.location.replace("/logout")
    });
    
    $("#add_query").click(function(){
        var num=/^[0-9]+$/;
        var val="";
        var pl="0";
        var d=0;
        var q_d1= "XXX";
        var q_d2= "QXXX";
        var q_d3= "###";
        s1= document.getElementById("sid").value.length;
		console.log(s1)
		if (s1 != 6){
			alert("SID should be 6 digit ")
			
		}
        if (d == 0) {
            var obj={"sid":$("#sid").val(), "region":$("#region").val(), "project_type":$("#project_type").val(),
            "qno":$("#q_no").val(), "q_category":$("#q_category").val(), "q_description":$("#q_description").val(),
            "sample_id":$("#sample_id").val(), "clarification":$("#clarification").val(), "result":$("#result").val(),
            "explain":$("#explain").val(),"phase":$("#phase").val(),"rdg_version":$("#rdg_version").val(),"qa_responsible":$("#qa_responsible").val(),
            "status":$("#status").val(),"sw_responsible":$("#sw_responsible").val(),}
            $.ajax({
                type:'post',
                url:'/add_query',
                contentType:'application/json',
                data:JSON.stringify(obj),
                dataType:'json',
                success:function(results){  
                    var answer =JSON.parse(JSON.stringify(results))
                        if(answer['result']=='Success'){                    
                            alert("Data Inserted Successfully")                              
                        }
                        else{
                            alert(answer['result']) 
                        }

                },
                error: function (jqXHR, exception) {
                    var msg = '';
                    if (jqXHR.status === 0) {
                        msg = 'Not connect.\n Verify Network.';
                    } else if (jqXHR.status == 404) {
                        msg = 'Requested page not found. [404]';
                    } else if (jqXHR.status == 500) {
                        msg = 'Internal Server Error [500].';
                    } else if (exception === 'parsererror') {
                        msg = 'Requested JSON parse failed.';
                    } else if (exception === 'timeout') {
                        msg = 'Time out error.';
                    } else if (exception === 'abort') {
                        msg = 'Ajax request aborted.';
                    } else {
                        msg = 'Uncaught Error.\n' + jqXHR.responseText;
                    }
                    alert(msg);
                }

            });
        }
                
    });

    $("#view_query").click(function(){
        var obj={"sid":$("#sid").val()}
        $.ajax({
                type:'post',
                url:'/view_details_by_sid',
                contentType:'application/json',
                data:JSON.stringify(obj),
                dataType:'json',
                success:function(results){  
                    var answer =JSON.parse(JSON.stringify(results))
                        localStorage.setItem( 'result', JSON.stringify(answer['result']) );
                        console.log( JSON.parse( localStorage.getItem( 'result' ) ) );
                        window.location.replace("/view_details")

                    },
                    error: function (jqXHR, exception) {
                        var msg = '';
                        if (jqXHR.status === 0) {
                            msg = 'Not connect.\n Verify Network.';
                        } else if (jqXHR.status == 404) {
                            msg = 'Requested page not found. [404]';
                        } else if (jqXHR.status == 500) {
                            msg = 'Internal Server Error [500].';
                        } else if (exception === 'parsererror') {
                            msg = 'Requested JSON parse failed.';
                        } else if (exception === 'timeout') {
                            msg = 'Time out error.';
                        } else if (exception === 'abort') {
                            msg = 'Ajax request aborted.';
                        } else {
                            msg = 'Uncaught Error.\n' + jqXHR.responseText;
                        }
                        alert(msg);
                    }
                    
                });

    });

});