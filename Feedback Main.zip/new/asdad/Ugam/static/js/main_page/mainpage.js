$(document).ready(function () {

    $('#sidebarCollapse').on('click', function () {
        $('#sidebar').toggleClass('active');
    });

    $("#showdropdown").on('click', function () {
        window.location.replace("/logout")
    });


    $.ajax({
        type: "GET",
        url: "/bargetJson",
        success: function(result)
        {
            var values=result["result"]
            len =values.length
            var list_of_data= []
            var list_of_label = []
            for (i=0;i<len;i++){
                list_of_label.push(values[i]["label"])
                list_of_data.push(values[i]["y"])
            }
            new Chart(document.getElementById("Overall"), {
            type: 'bar',
            data: {
            labels: list_of_label,
            datasets: [
                {
                label: "Population (millions)",
                backgroundColor: ["#3e95cd", "#8e5ea2","#3cba9f","#e8c3b9","#c45850"],
                data: list_of_data  
                }
            ]
            },
            options: {
            legend: { display: false },
            title: {
                display: true,
                text: 'Total results'
            }
            }
        });
        },
        error: function (jqXHR, exception) {
            var msg = '';
            if (jqXHR.status === 0) {
                msg = 'Not connect.\n Verify Network.';
            } else if (jqXHR.status == 404) {
                msg = 'Requested page not found. [404]';
            } else if (jqXHR.status == 500) {
                msg = 'Internal Server Error [500].';
            } else if (exception === 'parsererror') {
                msg = 'Requested JSON parse failed.';
            } else if (exception === 'timeout') {
                msg = 'Time out error.';
            } else if (exception === 'abort') {
                msg = 'Ajax request aborted.';
            } else {
                msg = 'Uncaught Error.\n' + jqXHR.responseText;
            }
            alert(msg);
        }
    });          


    $.ajax({
        type: "GET",
        url: "/errorgetJson",
        success: function(result)
        {
            var values=result["result"]
            len =values.length
            var list_of_data= []
            var list_of_label = []
            for (i=0;i<len;i++){
                list_of_label.push(values[i]["label"])
                list_of_data.push(values[i]["y"])
            }
            new Chart(document.getElementById("Error"), {
                type: 'doughnut',
                data: {
                        labels: list_of_label,
                datasets: [{
                    label: "Population (millions)",
                    backgroundColor: ["#3e95cd", "#8e5ea2","#3cba9f","#e8c3b9","#c45850"],
                    data: list_of_data  
                    }]
                },
                options: {
                    title: {
                    display: true,
                    text: 'Error Get Json'
                    }
                }
            });
        },
        error: function (jqXHR, exception) {
            var msg = '';
            if (jqXHR.status === 0) {
                msg = 'Not connect.\n Verify Network.';
            } else if (jqXHR.status == 404) {
                msg = 'Requested page not found. [404]';
            } else if (jqXHR.status == 500) {
                msg = 'Internal Server Error [500].';
            } else if (exception === 'parsererror') {
                msg = 'Requested JSON parse failed.';
            } else if (exception === 'timeout') {
                msg = 'Time out error.';
            } else if (exception === 'abort') {
                msg = 'Ajax request aborted.';
            } else {
                msg = 'Uncaught Error.\n' + jqXHR.responseText;
            }
            alert(msg);
        }
    });


    $.ajax({
        type: "GET",
        url: "/suggitiongetJson",
        success: function(result)
        {
            var values=result["result"]
            len =values.length
            var list_of_data= []
            var list_of_label = []
            for (i=0;i<len;i++){
                list_of_label.push(values[i]["label"])
                list_of_data.push(values[i]["y"])
            }
            new Chart(document.getElementById("suggestion"), {
                type: 'doughnut',
                data: {
                        labels: list_of_label,
                datasets: [{
                    label: "Population (millions)",
                    backgroundColor: ["#3e95cd", "#8e5ea2","#3cba9f","#e8c3b9","#c45850"],
                    data: list_of_data
                    }]
                },
                options: {
                    title: {
                    display: true,
                    text:'Suggestion Get Json'
                    }
                }
            });
        },
        error: function (jqXHR, exception) {
            var msg = '';
            if (jqXHR.status === 0) {
                msg = 'Not connect.\n Verify Network.';
            } else if (jqXHR.status == 404) {
                msg = 'Requested page not found. [404]';
            } else if (jqXHR.status == 500) {
                msg = 'Internal Server Error [500].';
            } else if (exception === 'parsererror') {
                msg = 'Requested JSON parse failed.';
            } else if (exception === 'timeout') {
                msg = 'Time out error.';
            } else if (exception === 'abort') {
                msg = 'Ajax request aborted.';
            } else {
                msg = 'Uncaught Error.\n' + jqXHR.responseText;
            }
            alert(msg);
        }
    });


    $.ajax({
        type: "GET",
        url: "/markergetJson",
        success: function(result)
        {
            var values=result["result"]
            len =values.length
            var list_of_data= []
            var list_of_label = []
            for (i=0;i<len;i++){
                list_of_label.push(values[i]["label"])
                list_of_data.push(values[i]["y"])
            }
            new Chart(document.getElementById("Marker"), {
                type: 'doughnut',
                data: {
                        labels: list_of_label,
                datasets: [{
                    label: "Population (millions)",
                    backgroundColor: ["#3e95cd", "#8e5ea2","#3cba9f","#e8c3b9","#c45850"],
                    data: list_of_data
                    }]
                },
                options: {
                    title: {
                    display: true,
                    text:'Suggestion Get Json'
                    }
                }
            });
        },
        error: function (jqXHR, exception) {
            var msg = '';
            if (jqXHR.status === 0) {
                msg = 'Not connect.\n Verify Network.';
            } else if (jqXHR.status == 404) {
                msg = 'Requested page not found. [404]';
            } else if (jqXHR.status == 500) {
                msg = 'Internal Server Error [500].';
            } else if (exception === 'parsererror') {
                msg = 'Requested JSON parse failed.';
            } else if (exception === 'timeout') {
                msg = 'Time out error.';
            } else if (exception === 'abort') {
                msg = 'Ajax request aborted.';
            } else {
                msg = 'Uncaught Error.\n' + jqXHR.responseText;
            }
            alert(msg);
        }
        
    });


    $.ajax({
        type: "GET",
        url: "/logicgetJson",
        success: function(result)
        {
            var values=result["result"]
            len =values.length
            var list_of_data= []
            var list_of_label = []
            for (i=0;i<len;i++){
                list_of_label.push(values[i]["label"])
                list_of_data.push(values[i]["y"])
            }
            new Chart(document.getElementById("Q_logic"), {
                type: 'doughnut',
                data: {
                        labels: list_of_label,
                datasets: [{
                    label: "Population (millions)",
                    backgroundColor: ["#3e95cd", "#8e5ea2","#3cba9f","#e8c3b9","#c45850"],
                    data: list_of_data
                    }]
                },
                options: {
                    title: {
                    display: true,
                    text:'Suggestion Get Json'
                    }
                }
            });
        },
        error: function (jqXHR, exception) {
            var msg = '';
            if (jqXHR.status === 0) {
                msg = 'Not connect.\n Verify Network.';
            } else if (jqXHR.status == 404) {
                msg = 'Requested page not found. [404]';
            } else if (jqXHR.status == 500) {
                msg = 'Internal Server Error [500].';
            } else if (exception === 'parsererror') {
                msg = 'Requested JSON parse failed.';
            } else if (exception === 'timeout') {
                msg = 'Time out error.';
            } else if (exception === 'abort') {
                msg = 'Ajax request aborted.';
            } else {
                msg = 'Uncaught Error.\n' + jqXHR.responseText;
            }
            alert(msg);
        }
    });


    $.ajax({
        type: "GET",
        url: "/clientgetJson",
        success: function(result)
        {
            var values=result["result"]
            len =values.length
            var list_of_data= []
            var list_of_label = []
            for (i=0;i<len;i++){
                list_of_label.push(values[i]["label"])
                list_of_data.push(values[i]["y"])
            }
            new Chart(document.getElementById("client"), {
                type: 'doughnut',
                data: {
                        labels: list_of_label,
                datasets: [{
                    label: "Population (millions)",
                    backgroundColor: ["#3e95cd", "#8e5ea2","#3cba9f","#e8c3b9","#c45850"],
                    data: list_of_data
                    }]
                },
                options: {
                    title: {
                    display: true,
                    text:'Suggestion Get Json'
                    }
                }
            });

        },            error: function (jqXHR, exception) {
            var msg = '';
            if (jqXHR.status === 0) {
                msg = 'Not connect.\n Verify Network.';
            } else if (jqXHR.status == 404) {
                msg = 'Requested page not found. [404]';
            } else if (jqXHR.status == 500) {
                msg = 'Internal Server Error [500].';
            } else if (exception === 'parsererror') {
                msg = 'Requested JSON parse failed.';
            } else if (exception === 'timeout') {
                msg = 'Time out error.';
            } else if (exception === 'abort') {
                msg = 'Ajax request aborted.';
            } else {
                msg = 'Uncaught Error.\n' + jqXHR.responseText;
            }
            alert(msg);
        }
    
    });
    
});