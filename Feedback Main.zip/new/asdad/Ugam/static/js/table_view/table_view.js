$(document).ready(function () {
    $('#sidebarCollapse').on('click', function () {
        $('#sidebar').toggleClass('active');
    });
    $("#showdropdown").on('click', function () {
        window.location.replace("/logout")
    });
    
    $("#add_query").click(function(){
        var num=/^[0-9]+$/;
        var val="";
        var pl="0";
        var d=0;
        var q_d1= "XXX";
        var q_d2= "QXXX";
        var q_d3= "###";
        s1= document.getElementById("sid")
        if (d == 0) {
            var obj={"sid":$("#sid").val(), "region":$("#region").val(), "project_type":$("#project_type").val(),
            "qno":$("#q_no").val(), "q_category":$("#q_category").val(), "q_description":$("#q_description").val(),
            "sample_id":$("#sample_id").val(), "clarification":$("#clarification").val(), "result":$("#result").val(),
            "explain":$("#explain").val(),"phase":$("#phase").val(),"rdg_version":$("#rdg_version").val(),"qa_responsible":$("#qa_responsible").val(),
            "status":$("#status").val(),"sw_responsinle":$("#sw_responsinle").val(),}
        

                    $.ajax({
                        type:'post',
                        url:'/add_query',
                        contentType:'application/json',
                        data:JSON.stringify(obj),
                        dataType:'json',
                        success:function(results){  
                            var answer =JSON.parse(JSON.stringify(results))
                                if(answer['result']=='Success'){                    
                                    alert("Data Inserted Successfully")                              
                                }
                                else{
                                    alert(answer['result']) 
                                }

                        },
                        error: function (jqXHR, exception) {
                            var msg = '';
                            if (jqXHR.status === 0) {
                                msg = 'Not connect.\n Verify Network.';
                            } else if (jqXHR.status == 404) {
                                msg = 'Requested page not found. [404]';
                            } else if (jqXHR.status == 500) {
                                msg = 'Internal Server Error [500].';
                            } else if (exception === 'parsererror') {
                                msg = 'Requested JSON parse failed.';
                            } else if (exception === 'timeout') {
                                msg = 'Time out error.';
                            } else if (exception === 'abort') {
                                msg = 'Ajax request aborted.';
                            } else {
                                msg = 'Uncaught Error.\n' + jqXHR.responseText;
                            }
                            alert(msg);
                        } 

                    });
            }
                
            });

    $("#view_query").click(function(){
        var obj={"sid":$("#sid").val()}
        $.ajax({
                type:'post',
                url:'/view_details_by_sid',
                contentType:'application/json',
                data:JSON.stringify(obj),
                dataType:'json',
                success:function(results){  
                    var answer =JSON.parse(JSON.stringify(results))
                        localStorage.setItem( 'result', JSON.stringify(answer['result']) );
                        console.log( JSON.parse( localStorage.getItem( 'result' ) ) );
                        window.location.replace("/view_details")

                    },
                    error: function (jqXHR, exception) {
                        var msg = '';
                        if (jqXHR.status === 0) {
                            msg = 'Not connect.\n Verify Network.';
                        } else if (jqXHR.status == 404) {
                            msg = 'Requested page not found. [404]';
                        } else if (jqXHR.status == 500) {
                            msg = 'Internal Server Error [500].';
                        } else if (exception === 'parsererror') {
                            msg = 'Requested JSON parse failed.';
                        } else if (exception === 'timeout') {
                            msg = 'Time out error.';
                        } else if (exception === 'abort') {
                            msg = 'Ajax request aborted.';
                        } else {
                            msg = 'Uncaught Error.\n' + jqXHR.responseText;
                        }
                        alert(msg);
                    } 
                    
                });

    });
});