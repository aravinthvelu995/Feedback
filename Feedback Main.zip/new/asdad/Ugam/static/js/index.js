$(document).ready(function(){

    $("#reset").click(function(){
        $("#username").val("");
        $("#password1").val("");
		
    });

   
    $("#submit").click(function(){
        var obj={"username":$("#username").val(),"password":$("#password1").val()}
		var S1 = 0;
		
		
			$.ajax({
				type:'post',
				url:'/login',
				contentType:'application/json',
				data:JSON.stringify(obj),
				dataType:'json',
				success:function(results){
					var result =JSON.parse(JSON.stringify(results))
					if(result['result']=='Success'){
						
						window.location.replace("/mainpage");
										  
					}
					else{
						$("#result").html("Invalid Login");
					}
				},
				error: function (jqXHR, exception) {
					var msg = '';
					if (jqXHR.status === 0) {
						msg = 'Not connect.\n Verify Network.';
					} else if (jqXHR.status == 404) {
						msg = 'Requested page not found. [404]';
					} else if (jqXHR.status == 500) {
						msg = 'Internal Server Error [500].';
					} else if (exception === 'parsererror') {
						msg = 'Requested JSON parse failed.';
					} else if (exception === 'timeout') {
						msg = 'Time out error.';
					} else if (exception === 'abort') {
						msg = 'Ajax request aborted.';
					} else {
						msg = 'Uncaught Error.\n' + jqXHR.responseText;
					}
					alert(msg);
				}

			});
		

    });

    $(document).keypress(function(event){
        var keycode = (event.keyCode ? event.keyCode : event.which);
        if(keycode == '13'){
            $("#submit").click();
        }
    });

});