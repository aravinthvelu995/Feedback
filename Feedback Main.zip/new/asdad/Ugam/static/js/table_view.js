$(document).ready(function(){
       
    $("#view_query").click(function(){
        var obj={"sid":$("#sid").val()}

        $.ajax({
            type:'post',
            url:'/view_details_by_sid',
            contentType:'application/json',
            data:JSON.stringify(obj),
            dataType:'json',
            success:function(results){
                var result =JSON.parse(JSON.stringify(results))
            if(result['result']=='Success'){
                    
                    window.location.replace("/view_details_by_sid");
                                      
                }
                else{
                    $("#result").html("Invalid SID");
                }    
            }

        });

    });

});