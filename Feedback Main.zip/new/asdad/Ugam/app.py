from flask import Flask,request,render_template,jsonify,redirect,url_for,session,app
import mysql.connector
import simplejson as json
import os
#from passlib.hash import sha256_crypt
from functools import wraps
import datetime
import random
from datetime import timedelta
import requests
import csv
import mysql.connector
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

app=Flask(__name__)
app.secret_key = "kl2j343j5#$%#%34534%#$%$%^&**&*^*$%ERTertertert@#$@$frewer$@#$@#$"
app.config['PERMANENT_SESSION_LIFETIME'] =  timedelta(minutes=30)
APP_ROOT=os.path.dirname(os.path.abspath(__file__))


username=""

"Login Page"
@app.route("/ugam_MG_login")
def index():
    return render_template("index.html")


def login_required(f):
    @wraps(f)
    def wrap(*args, **kwargs):
        if 'logged_in':
            return f(*args, **kwargs)
        else:
            return  render_template("index.html")
    return wrap


@app.route("/logout")
@login_required
def logout():
    session.clear()
    return  render_template("index.html")


@app.route("/login", methods=['post'])
def login():
    try:
        
        global username
        global password
        data=request.get_json()
        username = data["username"]
        password= data["password"]
        print(username)
        print(password)
        db = mysql.connector.connect(user='root',passwd='',host='localhost',database='mani')
        mycursor = db.cursor()
        sql ="select username , password from admin where username ='%s'"%(username)
        mycursor.execute(sql)
        a = mycursor.fetchone()
        print(a)
        #if sha256_crypt.verify(data["username"],a[0]) and sha256_crypt.verify(data["password"],a[1])==True:
        if ((username).upper == a[0].upper and password==a[1]): 
            session["logged_in"] = True
            print("ahsgd hasdga sdg",a)
            session.permanent = True
            return jsonify({"result":"Success"})
        else:
            return jsonify({"result":"Failiure"})
        db.commit()
        db.close()
      
    except mysql.connector.Error as e:
        return str(e)

def calculation():
    global username
    db = mysql.connector.connect(user='root',passwd='',host='localhost',database='mani')
    mycursor = db.cursor()
    sql ="select phase, clarification, result, status from query_sheet where qa_responsible ='%s'" %(username)
    mycursor.execute(sql)
    a = mycursor.fetchall()
    db.commit()
    db.close()
    error_rating,suggition_rating, Marker_rating, logic_rating, client_rating=0,0,0,0,0
    error_rating_1, suggition_rating_1,Marker_rating_1, logic_rating_1, client_rating_1=0,0,0,0,0
    for i in a:
        # print(i[0],i[1],i[2],i[3])
        if ((i[0] == "RDG changes"  or i[0] == "Live" or i[0] == "RDG" )  and  i[1]  == "Error" and i[2] == "Accept" and i[3] =="close" ):
            error_rating = error_rating +1
        if ((i[0] == "RDG changes"  or i[0] == "Live" or i[0] == "RDG" )   and  i[1] == "suggestion" and i[2] == "Accept" and i[3] =="close" ):
            suggition_rating = suggition_rating + 1
        if ((i[0] == "RDG changes"  or i[0] == "Live" or i[0] == "RDG" )   and  i[1] == "Marker" and i[2] == "Accept" and i[3] =="close" ):
            Marker_rating = Marker_rating + 1
        if ((i[0] == "RDG changes"  or i[0] == "Live" or i[0] == "RDG" )   and  i[1] == "logic" and i[2] == "Accept" and i[3] =="close" ):
            logic_rating = logic_rating +1
        if ((i[0] == "RDG changes"  or i[0] == "Live" or i[0] == "RDG" )   and  i[1] == "client" and i[2] == "Accept" and i[3] =="close" ):
            client_rating = client_rating + 1

        if ((i[0] == "RDG changes"  or i[0] == "Live" or i[0] == "RDG" )  and  i[1]  == "Error" and i[2] == "Reject" and i[3] =="close" ):
            error_rating_1 = error_rating +1
        if ((i[0] == "RDG changes"  or i[0] == "Live" or i[0] == "RDG" )   and  i[1] == "suggestion" and i[2] == "Reject" and i[3] =="close" ):
            suggition_rating_1 = suggition_rating + 1
        if ((i[0] == "RDG changes"  or i[0] == "Live" or i[0] == "RDG" )   and  i[1] == "Marker" and i[2] == "Reject" and i[3] =="close" ):
            Marker_rating_1 = Marker_rating + 1
        if ((i[0] == "RDG changes"  or i[0] == "Live" or i[0] == "RDG" )   and  i[1] == "logic" and i[2] == "Reject" and i[3] =="close" ):
            logic_rating_1 = logic_rating +1
        if ((i[0] == "RDG changes"  or i[0] == "Live" or i[0] == "RDG" )   and  i[1] == "client" and i[2] == "Reject" and i[3] =="close" ):
            client_rating_1 = client_rating + 1

    # print(error_rating)
    bar_error_rating = error_rating + error_rating_1
    bar_suggition_rating = suggition_rating + suggition_rating_1
    bar_Marker_rating = Marker_rating + Marker_rating_1
    bar_logic_rating = logic_rating + logic_rating_1
    bar_client_rating = client_rating + client_rating_1
    bar_chart = [{'bar_error_rating':bar_error_rating},{'bar_suggition_rating':bar_suggition_rating},{'bar_Marker_rating':bar_Marker_rating},{'bar_logic_rating':bar_logic_rating},{'bar_client_rating':bar_client_rating}]
    error_doughnut =[{'error_rating':error_rating},{'error_rating_1':error_rating_1}]
    sugition_doughnut =[{'suggition_rating':suggition_rating},{'suggition_rating_1':suggition_rating_1}]
    Marker_doughnut =[{'Marker_rating':Marker_rating},{'Marker_rating_1':Marker_rating_1}]
    logic_doughnut =[{'logic_rating':logic_rating},{'logic_rating_1':logic_rating_1}] 
    client_doughnut =[{'client_rating':client_rating},{'client_rating_1':client_rating_1}] 
    total_result = [bar_chart,error_doughnut,sugition_doughnut, Marker_doughnut, logic_doughnut, client_doughnut]
    return total_result        



@app.route("/mainpage")
def main():
    try:
        if session["logged_in"]:
            return render_template("main_page/mainpage.html")        
    except KeyError:    
        return redirect(url_for("index"))



@app.route("/add_Excel")
def add_Excel():
    try:
        if session["logged_in"]:
            return render_template("add_excel/add_Excel.html")
    except KeyError:
        return redirect(url_for("index"))


@app.route("/bargetJson",methods=['get'])
def bargetJson():
    result = calculation()
    a =[{'y': result[0][0]["bar_error_rating"], 'label': "Error"}, {'y':result[0][1]["bar_suggition_rating"], 'label': "Suggition"}, {'y': result[0][2]["bar_Marker_rating"], 'label': "Marker"}, {'y': result[0][3]["bar_logic_rating"], 'label': "Logic"},{'y': result[0][4]["bar_client_rating"], 'label': "Client"}]
    # a =[{'y':123, 'label': "Error"}, {'y':231, 'label': "Suggition"}, {'y': 342, 'label': "Logic"},{'y': 342, 'label': "Client"}]

    return jsonify({"result":a})

@app.route("/errorgetJson",methods=['get'])
def errorgetJson():
    result = calculation()
    a =[{'y':  result[1][0]["error_rating"], 'label': "Accept"}, {'y':result[1][1]["error_rating_1"], 'label': "Rejected"}]
    # a =[{'y': 80, 'label': "Accept"}, {'y':100, 'label': "Rejected"}]
    return jsonify({"result":a})

@app.route("/suggitiongetJson",methods=['get'])
def suggitiongetJson():
    result = calculation()
    a =[{'y':  result[2][0]["suggition_rating"], 'label': "Accept"}, {'y':result[2][1]["suggition_rating_1"], 'label': "Rejected"}]
    # a =[{'y': 80, 'label': "Accept"}, {'y':100, 'label': "Rejected"}]
    return jsonify({"result":a})

@app.route("/markergetJson",methods=['get'])
def markergetJson():
    result = calculation()
    a =[{'y':  result[3][0]["Marker_rating"], 'label': "Accept"}, {'y':result[3][1]["Marker_rating_1"], 'label': "Rejected"}]
    # a =[{'y': 80, 'label': "Accept"}, {'y':100, 'label': "Rejected"}]
    return jsonify({"result":a})

@app.route("/logicgetJson",methods=['get'])
def logicgetJson():
    result = calculation()
    a =[{'y':  result[4][0]["logic_rating"], 'label': "Accept"}, {'y':result[4][1]["logic_rating_1"], 'label': "Rejected"}]
    # a =[{'y': 80, 'label': "Accept"}, {'y':100, 'label': "Rejected"}]
    return jsonify({"result":a})

@app.route("/clientgetJson",methods=['get'])
def clientgetJson():
    result = calculation()
    a =[{'y':  result[5][0]["client_rating"], 'label': "Accept"}, {'y':result[5][1]["client_rating_1"], 'label': "Rejected"}]
    # a =[{'y': 80, 'label': "Accept"}, {'y':100, 'label': "Rejected"}]
    return jsonify({"result":a})


@app.route("/uploadexcel",methods=['post'])
def uploadexcel():
    db = mysql.connector.connect(user="root", passwd="", host="localhost", database="mani")
    mycursor = db.cursor()
    target=os.path.join(APP_ROOT,'image/')
    if not os.path.isdir(target):
        os.mkdir(target)
    for file in request.files.getlist("file"):
        filename =file.filename        
        newfilename=str(datetime.datetime.now().time())+str(random.randint(0,100))
        filtername="".join(separate for separate in newfilename if separate.isalnum())
        finalname=filtername+'.'+filename.split(".")[-1]
        destination="".join([target,finalname])
        file.save(destination)
        container =[]
        with open(destination,'r') as book:
            csv_reader  = csv.reader(book)
            db=mysql.connector.connect(user="root",passwd="",host="localhost",database="mani")
            mycursor=db.cursor()
            for line in csv_reader:
                container.append(line)
            for i in container[1:]:
                sql = "UPDATE query_sheet SET clarification=%s,result=%s,explain1=%s WHERE sid=%s and s_no=%s"
                val = (i[9],i[10],i[12],i[0],i[3])
                mycursor.execute(sql,val)
            db.commit()
            db.close()
    return jsonify({"results":"Success"})

@app.route("/table_view" )
def table_view():
    try:
        if session["logged_in"]:
            return render_template("table_view/table_view.html")
    except KeyError:
        return redirect(url_for("index"))

@app.route("/create_api")
def create_api():
    try:
        if session["logged_in"]:
            return render_template("createapi.html")
    except KeyError:
        return redirect(url_for("index"))


@app.route("/query_table")
def quer_table():
    try:
        if session["logged_in"]:
            return render_template("query_table/query_table.html")
    except KeyError:
            return redirect(url_for("index"))


@app.route("/add_query", methods=['post'])
def add_query():
    try:
        data=request.get_json()
        db=mysql.connector.connect(user="root",passwd="",host="localhost",database="mani")
        mycursor=db.cursor()
        sql = "INSERT INTO query_sheet (sid, region, type, query_no, query_categories, query_description, serial, clarification, result, explain1, phase, rdg_version, qa_responsible, status, sw_responsible) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"
        val=(data["sid"],data["region"],data["project_type"],data["qno"],data["q_category"],data["q_description"],data["sample_id"],data["clarification"],data["result"],data["explain"],data["phase"],data["rdg_version"],data['qa_responsible'],data["status"],data["sw_responsible"])
        mycursor.execute(sql,val)
        db.commit()
        db.close()
        date=datetime.datetime.now().date()
        return jsonify({"results":"Success"})
    except Exception as e:
        print(e)
        return jsonify({"results":str(e)})


details=[]
@app.route("/view_details_by_sid", methods=['post'])
def view_details_by_sid():
    try:
        global details
        # details=request.args.get('user')  < Get query Parameter using> 
        data=request.get_json()
        db=mysql.connector.connect(user="root",passwd="",host="localhost",database="mani")
        mycursor=db.cursor()
        #sql="select s_no, date,query_no, query_categories, query_description, serial, clarification, result, explain1, explain2, phase, rdg_version, qa_responsible, status, sw_responsible from query_sheet where sid='%s'"%(data["sid"])
        sql="select * from query_sheet where sid='%s'"%(data["sid"])
        mycursor.execute(sql)
        details=mycursor.fetchall()
        db.commit()
        db.close()
        return jsonify({"result":details})
        
    except Exception as e:
        return jsonify({"result":str(e)})


details=[]
@app.route("/get_details_by_sid/<int:sid>")
def get_details_by_sid(sid):
    try:
        global details
        # details=request.args.get('user')  < Get query Parameter using>
        db=mysql.connector.connect(user="root",passwd="",host="localhost",database="mani")
        mycursor=db.cursor()
        sql="select * from query_sheet where sid='%s'"%(sid)
        mycursor.execute(sql)
        details=mycursor.fetchall()
        return render_template("api_show_html_table/api_show_html_table.html",data=details)
        
    except Exception as e:
        return jsonify({"result":str(e)})


@app.route("/view_details")
def view_details():
    try:
        if session["logged_in"]:
            return render_template("view_details/view_details.html",data=details)
    except KeyError:
        return redirect(url_for("index"))



update_sid =""
@app.route("/new_view_details_by_sid")
def new_view_details_by_sid():
    try:
        if session["logged_in"]:
            try:
                global update_sid
                # details=request.args.get('user')  < Get query Parameter using>
                db=mysql.connector.connect(user="root",passwd="",host="localhost",database="mani")
                mycursor=db.cursor()
                #sql="select s_no, date,query_no, query_categories, query_description, serial, clarification, result, explain1,  phase, rdg_version, qa_responsible, status, sw_responsible from query_sheet where sid='%s'"%(update_sid)
                sql="select * from query_sheet where sid='%s'"%(update_sid)
                mycursor.execute(sql)
                details=mycursor.fetchall()
                return render_template("view_details/view_details.html",data=details)
                
            except Exception as e:
                return jsonify({"result":str(e)})
            
    except KeyError:
        return redirect(url_for("index"))
   

@app.route("/update_query_details",methods=["post"])
def update_query_details():
    try:
        global update_sid
        data=request.get_json()
        db=mysql.connector.connect(user="root",passwd="",host="localhost",database="mani")
        mycursor=db.cursor()
        sql='''update query_sheet set region='%s', type='%s',
            date='%s', query_no='%s', query_categories='%s', query_description='%s', serial='%s',
            clarification='%s', result='%s', explain1='%s',  phase='%s',
            rdg_version='%s', qa_responsible='%s', status='%s', sw_responsible='%s'
            where sid='%s' and s_no="%s" '''%(data["region"],data["project_type"],data["date"],
            data["query_no"],data["quert_categories"],data["query_description"],data["serial"],
            data["clarification"],data["result"],data["explain1"],data["phase"],
            data["version"],data["responsible"],data["status"],data["sw_responsible"],data["sid"],data["serial_no"])
        #update_sid=%(data["sid"])
        mycursor.execute(sql)

        db.commit()
        db.close()
        return jsonify({"result":"Success"});
    except mysql.connector.Error as e:
        return jsonify({"result":str(e)});

@app.route("/delete_query_details",methods=["post"])
def delete_query_details():
    try:
        data=request.get_json()
        global update_sid
        update_sid =data["sid"]
        db=mysql.connector.connect(user="root",passwd="",host="localhost",database="mani")
        mycursor=db.cursor()
        sql="delete from query_sheet where sid='%s' and s_no='%s' "%(data["sid"],data["serial_no"])
        mycursor.execute(sql)
        db.commit()
        db.close()
        return jsonify({"result":"Success"});
    except mysql.connector.Error as e:
        return jsonify({"result":str(e)})


@app.route("/send_email", methods=['post'])
def send_email():
    try:
        data=request.get_json()
        me = data["username"]
        you = data["recieve_email"].split(',')
        for i in you:
            msg = MIMEMultipart('alternative')
            msg['Subject'] = "Link"
            msg['From'] = me
            msg['To'] = i
            text = "Hi!\nHow are you?\nHere is the link you wanted:\nhttp://192.168.0.5:8000/superuser/material-out-template/"
            server = smtplib.SMTP('smtp.gmail.com',587)
            server.starttls()
            server.login(me,data["password"])
            server.sendmail(me,i,text)
        server.quit()
        return jsonify({"result":"Success"});
    except Exception as e:
        return jsonify({"result":str(e)});

if __name__== '__main__':
    app.run(debug=True)
    app.run(port=5000)
    
